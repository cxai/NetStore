﻿(function () {
    "use strict";

    checkmarx.CxPortal.directive('downloadFile', [function () {

        return {
            template:   '<div class="download-file-link" ng-click="downloadFile()">'
                            +'<button id="download-file-button" class="download-file-button">{{buttonText}}</button>'
                        +'</div>',
            scope: {
                downloadLink: '@',
                buttonText: '@',
                fileName: '@',
                fileType: '@'
            },
            controller: ['$rootScope', '$scope', 'ajaxService', 'FileSaver', function ($rootScope, $scope, ajaxService, FileSaver) {

                var file;

                $scope.downloadFile = function () {
                    ajaxService.get($scope.downloadLink).then(function (result) {
                        $rootScope.$broadcast('download-file-success');

                        file = new window.Blob(([result.data]), {
                            type: $scope.fileType
                        });

                        FileSaver.saveAs(file, $scope.fileName);
                    }).catch(function () {
                        $rootScope.$broadcast('download-file-error');
                    })
                }
            }]
        };
    }]);
})();