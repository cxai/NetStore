﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('osaAnalyseDataService', ['ajaxService', 'osaAjaxService', 'apiBaseURLService',
        function (ajaxService, osaAjaxService, apiBaseURLService) {

            var _runOSAmethodName = "opensourcesummary";

            function getRunOSAUrl(projectId) {

                return apiBaseURLService.getAPIBaseURL() + '/projects/' + projectId + '/scans';
            }

            function getScanRequestOSAUrl() {

                return apiBaseURLService.getAPIBaseURL() + '/osa/scans';
            }

            function getOSAScansUrl(projectId) {

                return apiBaseURLService.getAPIBaseURL() + '/osa/scans?projectId=' + projectId;
            }

            function buildConfig() {

                return {
                    headers: {
                        'Content-Type': undefined
                    }
                };
            }

            function uploadFile(data) {

                return osaAjaxService.post(getScanRequestOSAUrl(), data, buildConfig());
            }

            function analyse(data) {

                var url = getScanRequestOSAUrl();

                return osaAjaxService.post(url, data, buildConfig());
            }

            function getOSAScanStatus(guid) {

                var url = apiBaseURLService.getAPIBaseURL() + '/osa/scans/' + guid;

                return ajaxService.get(url);
            }

            function getOSAQueueScanList(projectId) {

                return ajaxService.get(getRunOSAUrl(projectId));
            }

            function getOSAScanList(projectId) {

                return ajaxService.get(getOSAScansUrl(projectId));
            }

            return {
                analyse: analyse,
                uploadFile: uploadFile,
                getOSAScanStatus: getOSAScanStatus,
                getOSAQueueScanList: getOSAQueueScanList,
                getOSAScanList: getOSAScanList
            };

        }]);

})();