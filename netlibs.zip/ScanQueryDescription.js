﻿var isExpanded = true;
var sourceText = document.getElementById("txtSource")
var editor = CodeMirror.fromTextArea(sourceText, {
    lineNumbers: true,
    readOnly: true,
    matchBrackets: true,
    highlightSelectionMatches: true,
    mode: "text/x-csharp"
});


function expandCollapse(button) {
    var sourceContainer = document.getElementById("codeContainer");
    var iframe = document.getElementById("ifQueryDescription");
    if (isExpanded)
    {
        sourceContainer.style.display = "none";
        button.value = "+";
        iframe.classList.remove("sourceCodeExpanded");
    }
    else
    {
        sourceContainer.style.display = "block";
        button.value = "-";
        iframe.classList.add("sourceCodeExpanded");
    }
    isExpanded = !isExpanded;
};