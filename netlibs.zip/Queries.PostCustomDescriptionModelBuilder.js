﻿/// <reference path="app.js" />

(function () {
    "use strict";

    checkmarx.Queries.factory('Queries.PostCustomDescriptionModelBuilder', [function () {

        function build() {

            
        }
        
        return {
            build: build
        };

    }]);

})();