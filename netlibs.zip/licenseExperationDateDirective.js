﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxPortal.directive('licenseExperationDate', ['ajaxService', 'siteGlobalVariablesProvider', '$translate',
        function (ajaxService, globalVariables, $translate) {

        var expirationDateTranslation = null;
        var expirationDateText = null;
        var webServiceURL = 'api/license/getlicenseexpirationdate';
        var isSetIntervalRun = false;
        var oneDayInMiliseconds = 86400000;
        var responsedExpirationDate = null;

        return {
            template: '<span class="license-experation-date">'
                        + '<span>{{expirationDate}}</span>'
                        + '<span>{{date | dateByLocaleFilter}}</span>'
                    + '</span>',
            replace: true,
            controller: ['$scope', '$element', function ($scope, $element) {

                var element = $(".license-experation-date").children()[0];

                function initTranslations() {

                    expirationDateTranslation = $translate.instant('EXPIRES');
                }

                function loadLicenseDetailsSuccess(response) {

                    if (response && response.data.isSuccesfull) {

                        if (response.data.shouldDisplayExpirationDate) {

                            responsedExpirationDate = response.data.licenseExpirationDate;
                            initTranslations();
                            printExpirationDate();
                            initSetInterval();
                        }
                    }
                }

                function LoadLicenseExpirationDate() {

                    ajaxService.get(webServiceURL).then(loadLicenseDetailsSuccess);
                }

                function initSetInterval() {

                    if (!isSetIntervalRun) {

                        setInterval(function () {
                            init();
                            isSetIntervalRun = true;
                        }, oneDayInMiliseconds);
                    }
                }

                function printExpirationDate() {

                    $scope.date = new Date(parseInt(responsedExpirationDate));
                    expirationDateText = expirationDateTranslation + ': ';

                    if (element) {
                        $scope.expirationDate = expirationDateText;
                    }
                }

                function init() {
                    LoadLicenseExpirationDate();
                }

                if (globalVariables.basicVariables().isAdmin) {
                    init();
                }
            }]
        };

    }]);

})();