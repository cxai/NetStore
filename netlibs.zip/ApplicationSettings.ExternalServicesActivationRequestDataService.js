﻿(function () {
    'use strict';

    checkmarx.ApplicationSettings.factory('ApplicationSettings.ExternalServicesActivationRequestDataService',
        ['CxPortal.AjaxServiceWithNotification',
        'apiBaseURLService',
        function (
            ajaxServiceWithNotification,
            apiBaseURLService) {

            function get() {
                var url = apiBaseURLService.getAPIVirtualDirectory() + '/License/ActivationRequestData';
                return ajaxServiceWithNotification.get(url);
            }

            return {
                get: get
            };
        }]);
})();