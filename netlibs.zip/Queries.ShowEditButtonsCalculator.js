﻿(function () {
    "use strict";

    checkmarx.Queries.factory('Queries.CustomDescriptionButtonsCalculator', [
        'siteGlobalVariablesProvider',
        'queryDescriptionType',
        'customDescriptionCommandMode',
        function (siteGlobalVariablesProvider, queryDescriptionType, customDescriptionCommandMode) {

            var _isCustomDescriptionExists;

            function isEnabledAndAuthorized(isAuthorized) {

                return isAuthorized && siteGlobalVariablesProvider.importUpdateCustomQueryEnabled();
            }

            function shouldDisplayButtons(selectedDescriptionTypeId, descriptions) {

                return selectedDescriptionTypeId == queryDescriptionType.customDescription
                            || !_isCustomDescriptionExists;
            }

            function getButtonType(descriptions) {

                return _isCustomDescriptionExists ? customDescriptionCommandMode.update : customDescriptionCommandMode.import;
            }

            function isCustomDescriptionExists(descriptions) {

                for (var i = 0; i < descriptions.length; i++) {

                    if (descriptions[i].queryTypeId == queryDescriptionType.customDescription) {
                        return true;
                    }
                }

                return false;
            }

            function calculate(showEditButtonInputData) {

                _isCustomDescriptionExists = isCustomDescriptionExists(showEditButtonInputData.descriptions);

                var showEditButton = {
                    show: false,
                    buttonType: 0
                };

                if (isEnabledAndAuthorized(showEditButtonInputData.isAuthorized)) {

                    if (shouldDisplayButtons(showEditButtonInputData.selectedDescriptionTypeId, showEditButtonInputData.descriptions)) {

                        showEditButton.show = true;
                        showEditButton.buttonType = getButtonType(showEditButtonInputData.descriptions);
                    }
                }

                return showEditButton;
            }

            return {
                calculate: calculate
            };

        }]);

})();