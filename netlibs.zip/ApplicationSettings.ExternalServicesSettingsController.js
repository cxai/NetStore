﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ApplicationSettings.controller('ApplicationSettings.ExternalServicesSettingsController', [
        '$scope',
        '$rootScope',
        'CxPortal.LicenseEnvironmentDataService',
        'httpStatusCodes',
        'CxPortal.NotificationService',
        'CxPortal.AuthorizationServiceConfigurationDataService',
        'ApplicationSettings.ExternalServicesActivationRequestDataService',
        'Common.HttpService',
        'siteGlobalVariablesProvider',
        '$q',
        '$timeout',
        '$translate',
        function ($scope,
            $rootScope,
            licenseEnvironmentDataService,
            httpStatusCodes,
            notificationService,
            authorizationServiceConfigurationDataService,
            externalServicesActivationRequestDataService,
            httpService,
            globalVariables,
            $q,
            $timeout,
            $translate) {

            var authorizationServiceBaseUrl = null;
            var authorizationServiceTimer;
            init();

            $scope.createTrust = function () {
                $scope.isActivationInProgress = true;
                if ($scope.externalServisesLicenseDataExists) {
                    licenseEnvironmentDataService.sendDeleteRequest().then(function () {
                        activate();
                    });
                }
                else {
                    activate();
                }

            }

            $scope.reactivate = function () {
                $scope.closeReactivationDialog();
                $scope.isActivationInProgress = true;
                licenseEnvironmentDataService.sendDeleteRequest().then(function () {
                    activate();
                });
            }

           

            $scope.closeActivationSuccessDialog = function () {
                $rootScope.$broadcast('dialog-close-' + $scope.activationSuccessDialogId);
            }

            function updateEnvironmentId(environmentId, emailActivationValidationSend) {
                $scope.emailForActivation = emailActivationValidationSend;
                licenseEnvironmentDataService.patch({ EnvironmentId: environmentId }).then(function () {
                    openActivationSuccessDialog();
                    loadData();
                });
            }
            
            function init() {
                $scope.isExternalServicesActive = false;
                $scope.activationSuccessDialogId = "activationSuccessDialog";
                
                $scope.dialogSetup = {
                    modal: true,
                    width: 391,
                    resizable: false,
                    show: {
                        effect: "fade", duration: 300
                    },
                    hide: {
                        effect: "fade", duration: 200
                    }
                };

                loadData();
                
                authorizationServiceConfigurationDataService.get().then(function (configurationData) {
                    authorizationServiceBaseUrl = configurationData.authorizationServiceBaseUrl;
                })

                registerMessageEventHandler();
            }
            
            function registerMessageEventHandler() {
                if (window.addEventListener) {
                    window.addEventListener("message", handleActivationResult, false)
                } else {
                    window.attachEvent("onmessage", handleActivationResult)
                }
            }

            function handleActivationResult(e) {
                if ($scope.isActivationInProgress) {
                    $timeout.cancel(authorizationServiceTimer);
                    $scope.isActivationInProgress = false;
                    if (e.origin == authorizationServiceBaseUrl) {
                        if (e.data.success) {
                            updateEnvironmentId(e.data.environmentID, e.data.email); 
                        }
                        else {
                            notificationService.error($translate.instant('ACTIVATION_REQUEST_ERROR') + ' ' +
                                $translate.instant('ERROR_CODE') + ': ' + e.data.code);
                            loadData();
                        }
                    }
                    else {
                        notificationService.error($translate.instant('ACTIVATION_REQUEST_ERROR'));
                        loadData();
                    }
                }
            }

            function loadData() {
                $scope.isExternalServicesActive = false;
                licenseEnvironmentDataService.get().then(function(licenseData) {
                    $scope.externalServisesLicenseDataExists = true;
                    $scope.environmentId = licenseData.data.environmentId;
                    $scope.publicKey = licenseData.data.publicKey;
                    if ($scope.environmentId) {
                        $scope.isExternalServicesActive = true;
                    }
                })
                .catch(function (ex) {
                    if (ex.status !== httpStatusCodes.notFound) {
                        notificationService.error((ex.data && ex.data.messageDetails) || "");
                    }
                }).finally(function () {
                    $scope.isDataLoaded = true;
                });
            }

            function activate() {
                licenseEnvironmentDataService.post().then(function () {
                    
                    externalServicesActivationRequestDataService.get().then(function (result) {

                        var activatePayLoad = { signedData: result.data };

                        httpService.postByIframeTargetedForm(result.sendUrl, activatePayLoad);
                        var authorizationServiceTimeoutInMilliseconds = globalVariables.getAuthorizationServiceTimeout() * 1000;
                        authorizationServiceTimer = $timeout(function () {
                            $scope.isActivationInProgress = false;
                            loadData();
                            notificationService.error($translate.instant('AUTHORIZATION_SERVER_TIMEOUT'));
                        }, authorizationServiceTimeoutInMilliseconds);
                    })
                    .catch(function (ex) {
                        $scope.isActivationInProgress = false;
                    });
                })
                .catch(function (ex) {
                    $scope.isActivationInProgress = false;
                });
            }

            function openActivationSuccessDialog() {
                $rootScope.$broadcast('dialog-open-' + $scope.activationSuccessDialogId);
            }

        }]);
})();