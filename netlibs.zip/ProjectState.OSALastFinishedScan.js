﻿
(function () {
    "use strict";

    checkmarx.ProjectState.factory('ProjectState.OSALastFinishedScan', ['ProjectState.OSAScanProcessStatus', function (OSAScanProcessStatus) {

        function get(scans) {

            if (scans.length < 1) {
                return scans;
            }

            var scans = scans.filter(function (scan) {

                return scan.state.id == OSAScanProcessStatus.finished;
            });

            return scans[0];
        }

        return {
            get: get
        };
    }]);

})();