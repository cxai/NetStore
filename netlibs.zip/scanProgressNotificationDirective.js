﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.directive('scanProgressNotification', [function () {

        return {
            template: '<div class="scan-progress-notification {{scanStatus}}" ng-if="showNotification">'
                        + '<scan-progress-notification-text scan-status-text="{{scanStatusText}}"></scan-progress-notification-text>'
                        + '<div class="close-icon {{scanStatus}}" ng-click="closeNotification()" ng-if="showCloseButton"></div>'
                    + '</div>',
            controller: ['$scope',
                '$rootScope',
                '$stateParams',
                'runSASTDataService',
                'scanRequestCalculatorService',
                'publicScanRequestsDataService',
                'userPreferencesService',
                'modalService',
                'sourceLocationType',
                'scanRequestRefreshPageCalculator',
                'Common.Timer',
                'showHideSASTNotificationsService',
                'scanRequestGeneralStages',
                'notificationService',
                function ($scope,
                    $rootScope,
                    $stateParams,
                    runSASTDataService,
                    scanRequestCalculatorService,
                    publicScanRequestsDataService,
                    userPreferencesService,
                    modalService,
                    sourceLocationType,
                    scanRequestRefreshPageCalculator,
                    timer,
                    showHideSASTNotificationsService,
                    scanRequestGeneralStages,
                    notificationService) {
                    
                    var modal = null;
                    var projectId = $stateParams.id;
                    var projectScanType = null;
                    var projectSourceLocationType = null;
                    var sastScanRequestsProcessor = new timer(10000);

                    $scope.currentScanId = 0;
                    $scope.currentScanGeneralStageId = 0;

                    $scope.$on('RunScanClicked', function (event, scanType) {

                        projectScanType = scanType;
                        runSASTDataService.getProjectSourceLocationType(projectId, projectScanType).then(function (result) {

                            if (result.data) {

                                if (result.data.scanLocation == sourceLocationType.local) {

                                    modal = modalService.openModalHTMLTemplate('<iframe frameborder="0" width="415" height="165" src="/CxWebClient/popLocalSource.aspx?opener=app"></iframe>', 'scan-request-modal');

                                    modal.result.then(function () {
                                        window.closeModalAfterCancel();
                                    });

                                    projectSourceLocationType = sourceLocationType.local;
                                }
                                else {
                                    projectSourceLocationType = result.data.scanLocation;
                                    runProject();
                                }
                            }
                        });
                    });

                    $scope.$on('$destroy', function () {
                        sastScanRequestsProcessor.stop();
                        sastScanRequestsProcessor = null;
                    });

                    function resetScanButtons() {

                        $rootScope.isRunFullScanButtonDisabled = false;
                        $rootScope.isRunIncrementalScanButtonDisabled = false;
                        $rootScope.runState = false;
                    }

                    function runProject() {

                        runSASTDataService.runProject(projectId, projectScanType, projectSourceLocationType).then(function (result) {

                            sastScanRequestsProcessor.stop();
                            runProcess();
                            resetScanButtons();
                            $rootScope.runState = true;

                            if (result.data.isSuccesfull === true) {
                                $rootScope.$broadcast('openSASTScanHasSentToQueueModal', projectScanType);
                            }
                            else {
                                notificationService.error(result.data.errorMessage);
                            }
                        });
                    }

                    window.closeModalAfterCancel = function () {

                        modal.close();
                        resetScanButtons();
                    };

                    window.closeModalAndRun = function () {
                        
                        modal.close();
                        runProject();
                    };

                    $scope.closeNotification = function () {

                        $scope.showNotification = false;
                        userPreferencesService.hideSASTIsRunningNotifications($scope.currentScanId);
                    };

                    function resetSetup() {

                        $scope.showNotification = false;
                        $scope.showCloseButton = false;
                    }

                    function setUpNotification(setUp) {

                        $scope.showNotification = setUp.showNotification;
                        $scope.showCloseButton = setUp.showCloseButton;
                        $scope.scanStatus = setUp.scanStatus;
                        $scope.scanStatusText = setUp.scanStatusText;
                        $scope.currentScanGeneralStageId = setUp.scanStatusId;
                    }

                    function updateRunState(scanStatusId) {

                        if (scanRequestGeneralStages.progress == scanStatusId) {
                            $rootScope.runState = true;
                        }
                        else {
                            $rootScope.runState = false;
                        }
                    }

                    function getScanRequests() {

                        publicScanRequestsDataService.getScanRequests(projectId).then(function (scanRequests) {

                            if (scanRequests.data && scanRequests.data.length > 0) {

                                var setUp = scanRequestCalculatorService.getScanRequestStatus(scanRequests.data);
                                setUpNotification(setUp);
                                scanRequestRefreshPageCalculator.calcualte(setUp.scanId, setUp.scanStatusId);
                                $scope.currentScanId = setUp.scanId;
                                updateRunState(setUp.scanStatusId);

                                if (showHideSASTNotificationsService.shouldShowSASTNotification($scope.currentScanId)) {
                                    $scope.showNotification = true;
                                }
                                else {
                                    $scope.showNotification = false;
                                }
                            }
                        });
                    }

                    function runProcess() {

                        getScanRequests();
                        sastScanRequestsProcessor.start(getScanRequests);
                    }

                    resetSetup();
                    runProcess();
                }]
        };
    }]);

})();