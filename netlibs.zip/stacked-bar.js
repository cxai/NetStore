var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        // Directive controller implementation
        var StackedBarDirective = (function (_super) {
            __extends(StackedBarDirective, _super);
            // Constructor (including dependencies that will be inserted automatically by angular)
            function StackedBarDirective(netService, scope, element, $timeout, $window) {
                var _this = this;
                _super.call(this, netService, scope);
                this.element = element;
                this.$timeout = $timeout;
                this.$window = $window;
                var parent = this.element.parents('.widget-content');
                //check if the widget-body has changed
                this.registerWatch(this.scope, function () { return parent.height(); }, function (nv) {
                    if (nv > 0 && nv != _this.currentHeight) {
                        _this.currentHeight = nv;
                        if (!!_this.widgetData) {
                            if (!_this.timeoutInstance) {
                                _this.timeoutInstance = _this.$timeout(function () {
                                    _this.createChart();
                                    _this.$timeout.cancel(_this.timeoutInstance);
                                    _this.timeoutInstance = null;
                                }, 100);
                            }
                        }
                    }
                });
                //check if the config data from the server is exist or has changed
                this.registerWatch(this.scope, function () { return _this.widgetData; }, function (nv) {
                    if (!_this.timeoutInstance) {
                        _this.timeoutInstance = _this.$timeout(function () {
                            _this.createChart();
                            _this.$timeout.cancel(_this.timeoutInstance);
                            _this.timeoutInstance = null;
                        }, 100);
                    }
                });
                this.scope.$on("$destroy", function () {
                    if (_this.timeoutInstance) {
                        _this.$timeout.cancel(_this.timeoutInstance);
                        _this.timeoutInstance = undefined;
                    }
                });
            }
            StackedBarDirective.prototype.createChart = function () {
                var fontColor = 'rgb(100,114,121)';
                var fontSize = '1.4rem';
                var chartElement = this.element;
                var that = this;
                var categories = that.widgetData.data.chart.xAxis.categories || [];
                chartElement.highcharts({
                    credits: false,
                    legend: { enabled: false },
                    exporting: { enabled: false },
                    chart: {
                        type: 'column',
                        events: {
                            redraw: function () {
                                var width = this.plotBox.width;
                                width = width / Math.max(1, categories.length) - 40;
                                angular.element(chartElement).find('.highcharts-xaxis-labels span').css({ 'overflow': 'hidden', 'text-overflow': 'ellipsis', 'max-width': width + 'px' });
                            }
                        },
                        animation: true
                    },
                    colors: that.widgetData.config.colors || [],
                    title: {
                        text: ''
                    },
                    xAxis: {
                        categories: categories,
                        labels: {
                            useHTML: true,
                            formatter: function () {
                                if (this.value.navigateUrl) {
                                    var shortLabel = this.value.label && this.value.label.length > 30
                                        ? this.value.label.substring(0, 30) + '...'
                                        : this.value.label;
                                    return '<a style="text-decoration: underline;" href="' + this.value.navigateUrl + '" title="' + this.value.label + '">' + shortLabel + '</a>';
                                }
                                else {
                                    return '<span>' + this.value + '</span>';
                                }
                            },
                            style: {
                                fontFamily: 'Roboto Condensed',
                                fontSize: fontSize,
                                color: fontColor
                            }
                        }
                    },
                    yAxis: {
                        min: that.widgetData.data.chart.yAxis.min || 0,
                        max: that.widgetData.data.chart.yAxis.max || 100,
                        title: {
                            text: this.widgetData.data.chart.yAxis.label || '',
                            style: {
                                fontFamily: 'Roboto Condensed',
                                fontSize: fontSize,
                                color: fontColor
                            }
                        },
                        minorTickInterval: 25,
                        stackLabels: {
                            enabled: true,
                            formatter: function () {
                                return this.total;
                            },
                            style: {
                                fontFamily: 'Roboto Condensed',
                                fontSize: fontSize,
                                color: fontColor
                            }
                        },
                        labels: {
                            formatter: function () {
                                if (!that.widgetData.data.chart.yAxis.max || (this.value <= that.widgetData.data.chart.yAxis.max))
                                    return this.value;
                            },
                            style: {
                                fontFamily: 'Roboto Condensed',
                                fontSize: fontSize,
                                color: fontColor
                            }
                        }
                    },
                    tooltip: {
                        borderColor: 'rgb(203,207,209)',
                        style: {
                            fontFamily: 'Roboto Condensed',
                            color: fontColor
                        },
                        useHTML: true,
                        formatter: function () {
                            var tooltipElement = '<div style="min-width:60px;text-align:center">' +
                                '<div style="font-size:24px;">' + this.y + '</div>' +
                                '<div style="font-size:18px">' + this.series.name + '</div>' +
                                '</div>';
                            return tooltipElement;
                        },
                        positioner: function (boxWidth, boxHeight, point) {
                            return { x: point.plotX + 70, y: point.plotY };
                        },
                    },
                    plotOptions: {
                        series: {
                            pointWidth: 20
                        },
                        column: {
                            stacking: 'normal',
                            dataLabels: {
                                enabled: false,
                                color: 'white',
                                style: {
                                    textShadow: '0 0 3px black',
                                },
                                verticalAlign: 'middle',
                                align: 'left'
                            }
                        }
                    },
                    series: that.widgetData.data.chart.series || []
                }, function (chart) {
                    if (that.widgetData.config.buildGradient) {
                        var gradientStops = [];
                        var graphSize = chart.plotSizeY;
                        var colors = that.widgetData.config.colors || [];
                        colors.forEach(function (color, index, arr) {
                            gradientStops.push([1 / (arr.length - 1) * index, color]);
                        });
                        var originalData = [];
                        //Animation for gradient workaround.
                        chart.series.forEach(function (series, idx, arr) {
                            originalData.push(series.data.map(function (data) {
                                return data.y;
                            }));
                            var zeroData = series.data.map(function (data) {
                                return 0;
                            });
                            series.update({
                                color: {
                                    linearGradient: [0, 0, 0, graphSize],
                                    stops: gradientStops
                                },
                                data: zeroData
                            });
                            series.setData(originalData[idx]);
                        });
                    }
                });
            };
            // Specify the dependencies for this directive    
            StackedBarDirective.$inject = ['#net', '$scope', '$element', '$timeout', '$window'];
            return StackedBarDirective;
        }(Directives.BaseWidget));
        // Directive configuration
        function StackedBarDirectiveSettings() {
            return {
                restrict: 'E',
                replace: true,
                controller: StackedBarDirective,
                controllerAs: 'root',
                templateUrl: '/CxWebClient/pages/dashboard/HighChartWidget',
                bindToController: true,
                scope: {
                    config: '='
                }
            };
        }
        Directives.StackedBarDirectiveSettings = StackedBarDirectiveSettings;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=stacked-bar.js.map