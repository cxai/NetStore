﻿/// <reference path="../../../../app.js" />
/// <reference path="../../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('ProjectState.FinishedScansCalculator', [function () {

        function calculate(oldScanList, newScanList) {
            var finishedScans = [];

            for (var i = 0; i < oldScanList.length; i++) {
                var oldScanId = oldScanList[i].scanId;
                var isScanFound = isListContainsScan(oldScanId, newScanList);
                if (!isScanFound) {
                    finishedScans.push(oldScanId)
                }
            }

            return finishedScans;
        }


        function isListContainsScan(scanId,scansList) {
            for (var i = 0; i < scansList.length; k++) {
                if (scansList[i]["scanId"]) {
                    var newScanId = scansList[i].scanId;
                    if (scanId == newScanId) {
                        return true;
                    }
                }
            }
            return false;
        }

        return {
            calculate: calculate
        };

    }]);
})();