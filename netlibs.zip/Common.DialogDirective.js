﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.Common.directive('dialog', [function () {
        /* the dialog based on jQuery-ui dialog. for setup the dialog and more information: https://jqueryui.com/dialog/ */

        return {
            transclude: true,
            template: '<div id="portal-dialog{{buildDialogIdSuffix()}}" class="generic-dialog">'
                        + '<img id="dialog-close" src="app/common/styles/images/dialog-close-button.png" class="dialog-close-button" />'
                        + '<div ng-transclude></div>'
                    + '</div>',
            scope: {
                dialogSetup: '=',
                dialogId: '=',
                closeDialogCallback: '&closeDialogCallback'
            },
            link: function ($scope, element) {

                $scope.buildDialogIdSuffix = function () {
                    return $scope.dialogId ? '-' + $scope.dialogId : '';
                }

                $scope.$on('dialog-initialize' + $scope.buildDialogIdSuffix(), function (e) {
                    initializeDialog();
                });

                $scope.$on('dialog-open' + $scope.buildDialogIdSuffix(), function (e) {
                    open();
                });

                $scope.$on('dialog-close' + $scope.buildDialogIdSuffix(), function (e) {
                    $scope.closeDialogCallback();
                    close();
                });

                $scope.$on("$destroy", function () {
                    destroy();
                });

                element.find('#dialog-close').on('click', function () {
                    $scope.$broadcast('dialog-close' + $scope.buildDialogIdSuffix());
                });

                function initializeDialog() {
                    $("#portal-dialog" + $scope.buildDialogIdSuffix()).dialog($scope.dialogSetup);
                }

                function open() {

                    initializeDialog();
                    $(".ui-dialog-titlebar").hide();
                    $(".ui-dialog.ui-dialog-content").css('');
                    closeOnOverlayClick();
                }

                function close() {

                    if (isDialogInitialize() && isDialogOpen()) {
                        $("#portal-dialog" + $scope.buildDialogIdSuffix()).dialog('close');
                    }
                }

                function destroy() {
                    if (isDialogInitialize()) {
                        $("#portal-dialog" + $scope.buildDialogIdSuffix()).dialog('destroy');
                    }
                }

                function closeOnOverlayClick() {

                    if ($scope.dialogSetup.shouldCloseByOverlayClick == false) {
                        return;
                    }

                    $(".ui-widget-overlay").click(function () {
                        close();
                    });
                }

                function isDialogInitialize() {
                    return $('#portal-dialog' + $scope.buildDialogIdSuffix()).hasClass('ui-dialog-content');
                }

                function isDialogOpen() {
                    return $('#portal-dialog' + $scope.buildDialogIdSuffix()).dialog("isOpen");
                }
            }
        };
    }]);
})();