﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.Common.factory('Common.ExpirableLocalStorageService', ['localStorageService', function (localStorageService) {

        function setItem(key, item, expiryTimeInMinutes) {

            var cachedItem = buildCachedItem(item, expiryTimeInMinutes);
            localStorageService.setJSONItem(key, cachedItem);
        }

        function getItem(key) {

            var cachedItem = localStorageService.getJSONItem(key);
            if (cachedItem) {
                if (checkCachedItemExpiry(cachedItem)) {
                    return cachedItem.value;
                }
                else {
                    localStorageService.removeItem(key);
                }
            }

            return null;
        }

        function setJSONItem(key, item, expiryTimeInMinutes) {

            setItem(key, JSON.stringify(item), expiryTimeInMinutes);
        }

        function getJSONItem(key) {

            return JSON.parse(getItem(key));
        }

        function buildCachedItem(item, expiryTimeInMinutes) {

            var expiryTime = null;
            if (expiryTimeInMinutes > 0) {
                var oneMinuteInMilliseconds = 60 * 1000;
                var expiryTimeInMilliseconds = expiryTimeInMinutes * oneMinuteInMilliseconds;
                expiryTime = new Date().getTime() + expiryTimeInMilliseconds;
            }

            return { value: item, expiryTime: expiryTime };
        }

        function checkCachedItemExpiry(cachedItem) {
            return !isItemExpirable(cachedItem) || isExpiryTimeValid(cachedItem.expiryTime);
        }

        function isItemExpirable(cachedItem) {
            if (cachedItem.expiryTime) {
                return true;
            }

            return false;
        }

        function isExpiryTimeValid(expiryTime) {
            return new Date().getTime() < expiryTime;
        }

        return {
            setItem: setItem,
            getItem: getItem,
            setJSONItem: setJSONItem,
            getJSONItem: getJSONItem
        };
    }]);

})();