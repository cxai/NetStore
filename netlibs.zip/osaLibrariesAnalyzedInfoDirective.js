﻿(function () {
    "use strict";

    checkmarx.ProjectState.directive('osaLibrariesAnalyzedInfo', function () {

        return {
            template: '<div class="osa-summary-container">'
                        + '<div>'
                            + '<b>{{totlaLibraries}}</b> {{"LIBRARIES_WERE_ANALYZED" | translate}}'
                        + '</div>'
                        + '<div class="score {{vulnerabilityScore}}">'
                            + '{{"VULNERABILITIES_SCORE" | translate}}: {{vulnerabilityScore | vulnerabilitesScoreFilter}}'
                        + '</div>'
                    + '</div>',
            scope: {
                totlaLibraries: '=',
                vulnerabilityScore: '='
            }
        };
    });

})();