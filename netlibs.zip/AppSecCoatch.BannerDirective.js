﻿(function () {
    "use strict";

    checkmarx.CxAcademy.directive('appSecCoatchBanner', [
        'AppSecCoach.DialogIDs',
        'AppSecCoach.OpenLessonLogic',
        function (appSecCoachDialogIDs, openLessonLogic) {

            return {
                template: '<div class="{{cssClass}}" ng-click="clickedOnContainer()">'
                           + '<div class="code-bashing-header-text">{{headerText}} {{queryTitle}}</div>'
                           + '<span class="code-bashing-link-text">{{linkText}} ></span>'
                        + '</div>',
                scope: {
                    linkData: '=',
                    headerText: '=',
                    linkText: '@',
                    cssClass: '@'
                },
                link: function (scope, element, attrs) {

                    scope.appSecCoachLicenseDialogId = appSecCoachDialogIDs.appSecCoachLicenseDialog;
                    scope.appSecCoachLessonIsNotAvailableDialogId = appSecCoachDialogIDs.appSecCoachLessonIsNotAvailableDialog;

                    scope.clickedOnContainer = function () {

                        openLessonLogic.open(scope.linkData);
                    };
                }
            };
        }]);
})();