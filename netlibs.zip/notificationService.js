﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.Common.config(['toastrConfig', function (toastrConfig) {
        /* configure the toastr default options.*/

        angular.extend(toastrConfig, {
            timeOut: 0, /* if set to 0, the toastr will stick */
            autoDismiss: false, /* show only the most recent maxOpened toast(s) */
            containerId: 'toast-container',
            maxOpened: 1, /* 0 means no limit */
            newestOnTop: false,
            positionClass: 'toast-top-right',
            preventDuplicates: false,
            preventOpenDuplicates: true,
            target: 'body',
            progressBar: false,
            closeButton: true
        });
    }]);

    checkmarx.Common.factory('notificationService', ['toastr', function (toastr) {
        /* service for displaying notifications. */
        
        function success(message, options) {
            
            toastr.success(message, options);
        }

        function error(message, options) {

            toastr.error(message, options);
        }

        return {
            success: success,
            error: error
        };
    }]);
})();