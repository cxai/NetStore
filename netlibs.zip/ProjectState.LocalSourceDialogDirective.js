﻿(function () {
    "use strict";

    checkmarx.ProjectState.directive('localSourceDialog',
        [function () {

            return {
                templateUrl: 'app/projectState/views/localSourceDialog.html',
                scope: {
                    localSourceDialogFiles: '=',
                    uploadFunction: '&'
                },
                controller: [
                    '$rootScope',
                    '$scope',
                    '$translate',
                    'Common.FileExtensionValidator',
                    'Common.ClearInputFileService',
                        function ($rootScope, $scope, $translate, fileExtensionValidator, clearInputFileService) {

                    var zipFile = null;

                    resetValidationMessage();
                    $scope.fileValidationMessage = $translate.instant('ONLY_ZIP_FILES_ALLOWED');
                    $scope.OSAFileIsUploding = $translate.instant('OSA_UPLOADING_ZIP_FILE');

                    $scope.dialogSetup = {
                        modal: true,
                        width: 394,
                        resizable: false,
                        shouldCloseByOverlayClick: false,
                        show: {
                            effect: "fade", duration: 300
                        },
                        hide: {
                            effect: "fade", duration: 200
                        }
                    };

                    $rootScope.$watchCollection('localSourceDialogFiles', function (file) {

                        resetValidationMessage();

                        if (file && file.length > 0) {

                            zipFile = file[0];

                            if (!fileExtensionValidator.validate(zipFile.name, '.zip')) {
                                $scope.fileValidationMessage = $translate.instant('ONLY_ZIP_FILES_ALLOWED');
                            }
                        }
                    });

                    var localSourceDialogFileUploaded = $rootScope.$on('local-source-dialog-file-uploaded', function (evt, data) {
                        $scope.cancel();
                    });

                    $scope.$on('$destroy', function () {
                        localSourceDialogFileUploaded();
                    });

                    $scope.closeDialogCallback = function () {
                        zipFile = null;
                        resetValidationMessage();
                        $scope.fileValidation = false;
                        $scope.fileIsUploading = false;
                        resetFileUpload();
                    }

                    $scope.uploadFile = function () {

                        resetValidationMessage();
                        var result = validateZipFile();

                        if (result == true) {
                            $scope.fileIsUploading = true;
                            $rootScope.$broadcast('local-source-dialog-file-start-upload', zipFile);
                        }
                    };

                    $scope.cancel = function () {

                        $scope.closeDialogCallback();
                        $rootScope.$broadcast('dialog-close');
                        
                    };


                    function validateZipFile() {

                        var isValid = true;

                        if (!zipFile) {
                            $scope.fileValidationMessage = $translate.instant('REQUIRED_FIELD');
                            isValid = false;
                        }
                        else if (zipFile && !fileExtensionValidator.validate(zipFile.name, '.zip')) {
                            $scope.fileValidationMessage = $translate.instant('ONLY_ZIP_FILES_ALLOWED');
                            isValid = false;
                        }

                        return isValid;
                    }

                    function resetValidationMessage() {
                        $scope.fileValidationMessage = '';
                    }

                    function resetFileUpload() {

                        clearInputFileService.clear($('#flpOSALocalSourceCode'));
                        $scope.$broadcast('clear-upload-files');
                    }
                }]
            };
        }]);
})();