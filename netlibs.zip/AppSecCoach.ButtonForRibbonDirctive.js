﻿(function () {
    "use strict";

    checkmarx.CxAcademy.directive('appSecCoachButtonForRibbon', ['AppSecCoach.LessonsOpener', 'AppSecCoach.LinkType',
        function (lessonsOpener, linkType) {

        return {
            restrict: 'E',
            template: '<div class="app-sec-coach-button ribbon">'
                            + '<div ng-click="openLesson()">'
                                + '<img src="app/cxAcademy/images/app-sec-coach-icon.png" /><br />'
                                + 'Codebashing'
                            + '</div>'
                        + '</div>',
            link: function (scope, element, attr) {

                scope.openLesson = function () {

                    lessonsOpener.openGeneralLessonsPage(linkType.generalLink);
                };
            }
        };
    }]);
})();