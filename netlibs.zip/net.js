var Checkmarx;
(function (Checkmarx) {
    var Services;
    (function (Services) {
        // The service implementation
        var NetService = (function () {
            // Constructor (including dependencies that will be inserted automatically by angular)
            function NetService($q, $http) {
                this.$q = $q;
                this.$http = $http;
            }
            // Get widget configuration
            NetService.prototype.getTabWidgets = function (tabId) {
                var url = "api/widget/GetTabWidgets/" + tabId;
                return this.$http.get(url).then(function (result) {
                    return result.data;
                });
            };
            // Get specific widget data
            NetService.prototype.getWidgetData = function (widgetDataConfig) {
                var filterRequest = null;
                if (widgetDataConfig.filters) {
                    filterRequest = this.createWidgetDataFilterRequest(widgetDataConfig.filters);
                }
                var url = "api/widget/GetWidgetData/" + widgetDataConfig.id;
                return this.$http.post(url, filterRequest).then(function (result) {
                    return result.data;
                });
            };
            NetService.prototype.getTabWidgetFilters = function (widgetIds) {
                var url = "api/widget/GetWidgetsFilterData";
                return this.$http.post(url, widgetIds).then(function (result) {
                    return result.data;
                });
            };
            NetService.prototype.createWidgetDataFilterRequest = function (filters) {
                var filtersRequestArray = [];
                var filterRequset = null;
                for (var i = 0; i < filters.length; i++) {
                    var widgetFilter = filters[i];
                    var selectedValue = null;
                    selectedValue = [];
                    for (var j = 0; j < widgetFilter.values.length; j++) {
                        if (widgetFilter.values[j].selected) {
                            if (widgetFilter.isMultiValue) {
                                selectedValue.push(widgetFilter.values[j].value);
                            }
                            else {
                                selectedValue = widgetFilter.values[j].value;
                                break;
                            }
                        }
                    }
                    filtersRequestArray.push({ name: widgetFilter.parameterName, value: selectedValue });
                }
                filterRequset = { filters: filtersRequestArray };
                return filterRequset;
            };
            // Specify the dependencies for this directive    
            NetService.$inject = ['$q', '$http'];
            return NetService;
        }());
        Services.NetService = NetService;
    })(Services = Checkmarx.Services || (Checkmarx.Services = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=net.js.map