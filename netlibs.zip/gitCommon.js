﻿var gitAuthenticationMethodTypesEnum = {
    NONE: 0,
    CREDENTIALS: 1,
    TOKEN: 2,
    SSH: 3
}

var repositoryType = {
    TFS: 0,
    SVN: 1,
    CVS: 2,
    GIT: 3,
    Perforce: 4,
    NONE: 5
}

var sourceControlProtocolType = {
    windowsAuthentication: 0,
    SSL: 1,
    SSH: 2,
    passwordServer: 3
}

var gitLsRemoteViewType = {
    TAGS: 0,
    HEADS: 1,
    TAGS_AND_HEADS: 2,
    ALL: 3
}

var repositoryTypeEnum = {
    TFS: 1,
    SVN: 2,
    GIT: 3,
    PERFORCE: 4
};