﻿(function myfunction() {
    'use strict';

    checkmarx.CxAcademy.factory('AppSecCoach.LessonsOpener',
       ['AppSecCoach.LessonsRequestDataService',
       'currentPageNameService',
       'Common.HttpService',
       '$window',
       'AppSecCoach.LinkType',
    function (lessonsRequestDataService, currentPageNameService, httpService, $window, linkTypeValue) {

        var lessonWindow = null;
        var utmMediumExtenstion = "Vulnerability";
        var _linkType = null;

        function openQueryLesson(queryId) {

            openEmptyWindow();

            lessonsRequestDataService.getLessonRequestDataByQueryId(queryId).then(function (requestData) {
                fillLessonsPage(requestData);
            });
        }

        function openGeneralLessonsPage(linkType) {

            _linkType = linkType;
            openEmptyWindow();

            lessonsRequestDataService.getLessonsRequestData().then(function (requestData) {
                fillLessonsPage(requestData);
            });
        }

        function openEmptyWindow() {
            lessonWindow = $window.open();
        }

        function fillLessonsPage(requestData) {

            var url = requestData.url;
            var paramteres = requestData.paramteres;

            paramteres.utm_medium = getUtmMedium();
            url += "?" + $.param(paramteres);
            lessonWindow.location.href = url;
            lessonWindow.opener = null;
        }

        function getUtmMedium() {

            if (_linkType == linkTypeValue.generalLink) {
                return "PortalMenu";
            }

            return currentPageNameService.getCurrentPageName() + utmMediumExtenstion;
        }

        return {
            openQueryLesson: openQueryLesson,
            openGeneralLessonsPage: openGeneralLessonsPage
        };
    }]);
})();