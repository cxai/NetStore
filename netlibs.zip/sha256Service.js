﻿/// <reference path="../../app.js" />
/// <reference path="../../appObjects.js" />

(function () {
    "use strict";

    checkmarx.Common.factory('sha256Service', function () {
        // service for hashing sha1 (256 bits). This service wrap the 'jsSHA' library. Project's website https://github.com/Caligatio/jsSHA.

        var _hashTypeName = "SHA-256";

        var sh1InputOutputType = {
            hex: 'HEX',
            text: 'TEXT',
            b64: 'B64',
            bytes: 'BYTES',
            arrayBuffer: 'ARRAYBUFFER'
        };

        function hash(valToHash) {

            var sha = new jsSHA(_hashTypeName, sh1InputOutputType.text);
            sha.update(valToHash);

            return sha.getHash(sh1InputOutputType.hex);
        }

        return {
            hash : hash
        };

    });

})();