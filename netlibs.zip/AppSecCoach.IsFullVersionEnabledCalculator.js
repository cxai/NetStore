﻿(function () {
    "use strict";

    checkmarx.CxAcademy.factory('AppSecCoach.IsFullVersionEnabledCalculator',
        ['$q',
         'AppSecCoach.SettingsDataService',
         'CxPortal.LicenseEnvironmentDataService',
            function ($q, appSecCoachSettingsDataService, licenseEnvironmentDataService) {

                function calculate() {

                    var deferred = $q.defer();
                    var result = {
                        isFullVersionEnabled : false
                    };

                    appSecCoachSettingsDataService.getAppSecCoachSetting().then(function (settings) {

                        var isFullVersionEnabled = false;
                        if (settings.codebashingIsEnabled && settings.codebashingIsEnabled.toLowerCase() === "true") {
                            isFullVersionEnabled = true;
                        }
                        else if (isEULAConfirmed(settings.isTermsConfirmed)) {
                            isFullVersionEnabled = true;
                        }

                        if (isFullVersionEnabled) {

                            licenseEnvironmentDataService.get().then(function (licenseData) {

                                result.isFullVersionEnabled = isFullVersionEnabled && isExternalServicesActivated(licenseData.data);

                                deferred.resolve(result);
                            })
                            .catch(function (data) {
                                deferred.reject(data);
                            });
                        }
                        else {
                            deferred.resolve(result);
                        }
                    })
                    .catch(function (data) {
                        deferred.reject(data);
                    });;

                    return deferred.promise;
                }

                function isExternalServicesActivated(data) {

                    if (data.environmentId && data.publicKey) {
                        return true;
                    }

                    return false;
                }

                function isEULAConfirmed(isTermsConfirmed) {

                    return (isTermsConfirmed.toLowerCase() === "true");
                }

                return {
                    calculate: calculate
                };

            }]);

})();