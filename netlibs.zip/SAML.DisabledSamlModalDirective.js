﻿
(function () {
    "use strict";

    checkmarx.SAML.directive('disableSamlModal', [function () {

        return {
            template: '<div class="disable-modal-container">'
                        + '<div class="are-you-sure">{{ "ARE_YOU_SURE_SAML_DISABLE" | translate}}</div>'
                        + '<div class="disable-saml-warning">{{ "ARE_YOU_SURE_SAML_DISABLE_WARNING" | translate }}</div>'
                        + '<button class="yes-btn-disable" ng-click="yes()">{{ "YES_DISABLE_SAML" | translate }} </button>'
                        + '<button class="no-btn-disable" ng-click="no()">{{ "NO_BACK_TO_EDIT" | translate }} </button>'
                    + '</div>',
            controller: ['$scope', '$rootScope', function ($scope, $rootScope) {

                $scope.no = function () {
                    $rootScope.$broadcast('no-disable-saml-modal');
                    this.close();
                } 

                $scope.yes = function () {
                    $rootScope.$broadcast('yes-disable-saml-modal');
                    this.close();
                }
            }]

        };

    }]);

})();