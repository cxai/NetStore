﻿(function () {
    "use strict";

    checkmarx.ProjectState.controller('ProjectState.OSAMainController', [
        '$rootScope',
        '$scope',
        '$stateParams',
        '$translate',
        'osaLicenseDataService',
        'osaSummaryResultsDataService',
        'osaNotificationService',
        'modalService',
        'siteGlobalVariablesProvider',
        'projectStatePreloadedData',
        'sourceLocationType',
        'ProjectState.OSAAnalyzerService',
        'httpStatusCodes',
        'Common.Timer',
        'ProjectState.IsScanFinishedCalculator',
        'ProjectState.FinishedScansCalculator',
        'ProjectState.OSAScanProcessStatus',
        'localStorageService',
        'osaCurrentScanLocalStorageKey',
        function (
            $rootScope,
            $scope,
            $stateParams,
            $translate,
            osaLicenseDataService,
            osaSummaryResultsDataService,
            osaNotificationService,
            modalService,
            siteGlobalVariablesProvider,
            projectStatePreloadedData,
            sourceLocationType,
            osanAlyzerService,
            httpStatusCodes,
            timer,
            isScanFinishedCalculator,
            finishedScansCalculator,
            oasScanProcessStatus,
            localStorageService,
            osaCurrentScanLocalStorageKey) {

            var projectId = $stateParams.id;
            var _currentScanList = [];
            $scope.openSourceStatusShowLoading = true;
            $scope.isOsaLicensedLoaded = false;
            $scope.displayLastOSAScanDateTime = false;
            var currentscanLink = null;
            var osaScanRequestsProcessor = new timer(10000);
            var osaScanStatusTimer = new timer(10000);
            
            $rootScope.vulnerabilitesPointsMsg = $translate.instant('VULNERABLE_AND_OUTDATED')
                .replace("{outdatedVulnerabilites}", '? ');

            $scope.getAnalyzeData = function ($event) {
                startOSARunProcess();
            }

            $scope.openSampleImage = function () {
                modalService.openModal('/CxWebClient/app/projectState/views/osaSampleImageModal.html',
                                        null,
                                        'app-modal-osa-sample');
            }
            
            var runOSAAnalysisClickedEvent = $scope.$on('RunOSAAnalysisClicked', function (evt, data) {
                startOSARunProcess();
            });

            var localSourceDialogFileLoaded = $scope.$on('local-source-dialog-file-start-upload', function (event, file) {
                $scope.file = file;
                runOSAAnylize();
            });

            var osaFinishedScanSuccessfullyEvent = $scope.$on('osaFinishedScanSuccessfully', function (evt, shouldDisplayToaster) {
                getOSASummaryData(shouldDisplayToaster);
            });

            $scope.$on('$destroy', function () {
                runOSAAnalysisClickedEvent();
                localSourceDialogFileLoaded();
                osaFinishedScanSuccessfullyEvent();
                osaScanRequestsProcessor.stop();
                osaScanRequestsProcessor = null;
                osaScanStatusTimer.stop();
                osaScanStatusTimer = null;
            });

            function startOSARunProcess() {

                if ($scope.isOsaLicensed) {

                        if (projectStatePreloadedData.osaSourceCodeOrigin() == sourceLocationType.local) {

                            $rootScope.$broadcast('dialog-open');
                        }
                        else {
                            runOSAAnylize();
                        }
                }
            }

            function isOsaLicensed() {
                // get Summary Data when the page is loading if osa is licensed                

                osaLicenseDataService.isOsaLicensed().then(function (isOsaLicensedResponse) {
                    $scope.isOsaLicensed = isOsaLicensedResponse;
                    $scope.isOsaLicensedLoaded = true;

                    if (shouldSpecificOSAScanBeChecked()) {
                        $rootScope.disabledOSAButton = true;
                    }
                    else {
                        $rootScope.disabledOSAButton =
                            !$scope.isOsaLicensed
                                || !siteGlobalVariablesProvider.basicVariables().isScanner;
                    }

                    if ($scope.isOsaLicensed) {

                        osaSummaryResultsDataService.getOSASummaryDataOnLoading(projectId).then(getOSADataSuccess).catch(getOSADataError).finally(showOpenSourceContent);
                    }
                    else
                    {
                        showOpenSourceContent();
                    }
                });
            }

            function showOpenSourceContent()
            {
                $scope.openSourceStatusShowLoading = false;
            }

            function getOSASummaryData(shouldDisplayToaster) {

                osaSummaryResultsDataService.getOSASummaryData(projectId).then(function (result) {

                    getOSADataSuccess(result);
                });
            }

            function generateKey() {
            
                return osaCurrentScanLocalStorageKey.key + '_' + projectId;
            }

            function setCurrentScanData(scanData) {

                var osaCurrentScanData = {
                    scanId: scanData.scanId
                };

                localStorageService.setJSONItem(generateKey(), osaCurrentScanData);
                currentscanLink = scanData.link;
            }

            function runOSAAnylize() {

                osaScanRequestsProcessor.stop();
                $rootScope.disabledOSAButton = true;

                var formData = new FormData();
                formData.append('projectId', projectId);

                if (projectStatePreloadedData.osaSourceCodeOrigin() == sourceLocationType.local) {

                    formData.append('zippedSource', $scope.file);

                    osanAlyzerService.uploadFile(formData).then(uploadFileSuccessCallbac).catch(uploadFileErrorCallbac).finally(analyzeFinallyCallbac);
                }
                else {
                    osanAlyzerService.analyze(formData).then(analyzeSuccessCallbac).catch(analyzeErrorCallbac).finally(analyzeFinallyCallbac);
                }
            }

            function uploadFileSuccessCallbac(result) {

                analyzeSuccessCallbac(result);
                closeUploadFileDialog();
            }

            function analyzeSuccessCallbac(result) {

                setCurrentScanData(result);
                runSpecificOSAScan();
            }

            function analyzeErrorCallbac(error) {

                resetOSAButtonAndAnimation();
                $rootScope.disabledOSAButton = false;

                if (error && error.message) {
                    osaNotificationService.error(error.message);
                }
            }

            function uploadFileErrorCallbac(error) {

                analyzeErrorCallbac(error);
                closeUploadFileDialog();
                $rootScope.disabledOSAButton = false;
            }

            function analyzeFinallyCallbac() {

                runOSAQueuePinger();
            }

            function closeUploadFileDialog() {

                $rootScope.$broadcast('local-source-dialog-file-uploaded');
            }

            function getOSADataSuccess(response) {
                /* set the summary data. */

                $scope.osaSummaryResults = response;
                $scope.totalLibraries = response.totalLibraries;
                $scope.noKnownVulnerabilitesPoints = response.nonVulnerableLibraries;
                $scope.vulnerabilitesPoints = parseInt(response.vulnerableAndOutdated) + parseInt(response.vulnerableAndUpdated);

                $rootScope.vulnerabilitesPointsMsg = $translate.instant('VULNERABLE_AND_OUTDATED')
                                                     .replace("{outdatedVulnerabilites}", parseInt(response.vulnerableAndOutdated));

                $scope.vulnerabilityScore = response.vulnerabilityScore;

                if (response.startAnalyzeTime) {

                    $rootScope.dateTimeData = response.startAnalyzeTime;
                    $scope.displayLastOSAScanDateTime = true;
                }

                $rootScope.NoOSAAnalysisDataYet = false;
                $scope.showOSASummaryInfo = true;
            }

            function openSuccessMessage() {

                osaNotificationService.success($translate.instant('YOUR_ANALYSIS_COMPLETED_SUCCESSFULLY'));
            }

            function getOSADataError() {
                $rootScope.NoOSAAnalysisDataYet = true;
                $scope.showOSASummaryInfo = false;
            }

            function resetOSAButtonAndAnimation() {

                $scope.openSourceAnalyseSpinnerLoading = false;
            }


            function isScanFinished(scanList) {

                var result = isScanFinishedCalculator.calculate(_currentScanList, scanList);
                
                if (result.isAllScansFinished) {
                    $scope.$broadcast('osaFinishedScanSuccessfully');
                }
            }

            function getOSARunningNotificationMessage(scanListLength) {

                if (scanListLength > 1) {
                    $scope.OSARuningNotificationMessage = scanListLength + " " + $translate.instant('X_OSA_SCANS_IS_IN_PROGRESS');
                }
                else {
                    $scope.OSARuningNotificationMessage = $translate.instant('OSA_SCAN_IS_IN_PROGRESS');
                }
            }

            function shouldSpecificOSAScanBeChecked(){

                if (localStorageService.getJSONItem(generateKey())) {
                    return true;
                }

                return false;
            }

            function checkCurrentScanStatus() {

                if (shouldSpecificOSAScanBeChecked()) {

                    osanAlyzerService.getOSAScanStatus(localStorageService.getJSONItem(generateKey()).scanId).then(function (result) {

                        if (result.data.state.id == oasScanProcessStatus.inProgress) {
                            $rootScope.disabledOSAButton = true;
                        }
                        else if (result.data.state.id == oasScanProcessStatus.finished) {
                            osaScanStatusTimer.stop();
                            removeOSACurrentScanFromLocalStorage();
                            openSuccessMessage();
                            $rootScope.disabledOSAButton = !siteGlobalVariablesProvider.basicVariables().isScanner;
                        }
                        else if (result.data.state.id == oasScanProcessStatus.failed) {
                            osaScanStatusTimer.stop();
                            removeOSACurrentScanFromLocalStorage();
                            osaNotificationService.error(result.data.state.failureReason);
                            $rootScope.disabledOSAButton = !siteGlobalVariablesProvider.basicVariables().isScanner;
                            getOSAQueueScanList();
                        }
                    })
                    .catch(function (error) {

                        osaScanStatusTimer.stop();
                        removeOSACurrentScanFromLocalStorage();
                        $rootScope.disabledOSAButton = !siteGlobalVariablesProvider.basicVariables().isScanner;
                    });
                }
            }

            function removeOSACurrentScanFromLocalStorage() {
                localStorageService.removeItem(generateKey());
            }

            function getOSAQueueScanList() {
                osanAlyzerService.getOSAQueueScanList(projectId).then(function (result) {
                    if (result.data) {
                        if (result.data.length > 0) {
                            isScanFinished(result.data);
                            _currentScanList = result.data;
                            getOSARunningNotificationMessage(result.data.length);
                            $scope.openSourceAnalyseSpinnerLoading = true;
                        }
                        else {
                            isScanFinished([]);
                            _currentScanList = [];
                            resetOSAButtonAndAnimation();
                        }
                    }
                });
            }

            function runSpecificOSAScan() {

                if (localStorageService.getJSONItem(generateKey())) {
                    
                    $rootScope.disabledOSAButton = true;
                    checkCurrentScanStatus();
                    osaScanStatusTimer.start(checkCurrentScanStatus);
                }
            }

            function runOSAQueuePinger() {

                getOSAQueueScanList();
                osaScanRequestsProcessor.stop();
                osaScanRequestsProcessor.start(getOSAQueueScanList);
            }


            isOsaLicensed();
            runOSAQueuePinger();
            runSpecificOSAScan();
        }]);

})();
