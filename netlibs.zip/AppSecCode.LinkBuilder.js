﻿(function () {
    "use strict";

    checkmarx.CxAcademy.factory('AppSecCode.LinkBuilder',
        ['linkParameters',
            'sha256Service',
            'currentPageNameService',
            function (linkParameters, sha256Service, currentPageNameService) {

                function hash(toHash) {

                    return sha256Service.hash(toHash);
                }

                function appendQueryStringParameter(url, key, value, lastValue) {

                    return url + key + '=' + value + (!lastValue ? '&': '');
                }

                function getCurrentPageName(queryTitle) {

                    var currentPageName = currentPageNameService.getCurrentPageName();
                    return queryTitle ? (currentPageName + "Vulnerability") : currentPageName;
                }

                function build(languageName, queryTitle, organizationName, utmMedium) {

                    var currentPageName = utmMedium !== undefined ? utmMedium : getCurrentPageName('');

                    var link = linkParameters.baseUrl +
                        '#' +
                        (languageName ? ('/' + languageName.toLowerCase()) : "") +
                        (queryTitle ? ('/' + queryTitle.toLowerCase().replace(" ", "_")) : "") +
                        '?';

                    link = appendQueryStringParameter(link, linkParameters.source, linkParameters.constSource, false);
                    link = appendQueryStringParameter(link, linkParameters.currentPage, currentPageName, false);
                    link = appendQueryStringParameter(link, linkParameters.organizationName, hash(organizationName), true);

                    return link;
                }

                return {
                    build: build
                };
            }]);
})();