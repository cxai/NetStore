﻿(function () {
    "use strict";

    checkmarx.CxAcademy.factory('AppSecCoatch.AcademLessonMatcher',
        [function () {

            function match(queryId, academyLessons) {

                if (academyLessons) {
                    for (var i = 0; i < academyLessons.length; i++) {
                        
                        if (academyLessons[i] == queryId) {

                            return true;
                        }
                    }
                }
                return false;
            }

            return {
                match: match
            };
        }]);
})();