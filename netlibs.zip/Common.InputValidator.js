﻿(function () {
    "use strict";

    checkmarx.Common.factory('Common.InputValidator', ['$translate', 'CxPortal.NotificationService', function ($translate, notificationService) {

        function checkXSS() {
            var startingChars = ['<', '&'];
            var result = false;
            var summaryResult = true;
            var errorFileds = [];

            $("input[type='text'], textarea").each(
                function (index) {

                    var input = $(this).val();
                    var fieldId = $(this).attr('id');
                    input = input.toLowerCase();

                    result = checkHTMLTags(input);
                    if (result == true) {
                        errorFileds.push(fieldId);
                    }
                    else {
                        result = checkASCIITags(input, fieldId);
                        if (result == true) {
                            errorFileds.push(fieldId);
                        }
                    }
                    if (result == true) {
                        summaryResult = false;
                    }
                    else {
                        $(this).css('border-color', '#D7D7D7');
                    }
                }
            )
            if (summaryResult == false) {
                alertError(errorFileds);
                return false;
            }
            return true;
        };

        function cleanAllTextFields() {

            $("input[type='text'], textarea").each(
                function (index) {
                    $(this).css({ border: '1px solid #d7d7d7' });
                }
            )
        };

        function alertError(errorFileds) {
            if (errorFileds.length > 0) {
                for (var i = 0; i < errorFileds.length; i++) {
                    $('#' + errorFileds[i] + '').css('border-color', 'red');
                }
            }
            notificationService.error($translate.instant("ERROR_IN_SOME_FIELDS"));
        };

        function isLetter(str) {
            return str.length === 1 && str.match(/[a-z]/i);
        };

        function checkHTMLTags(input) {
            if (input && input.length > 0) {
                var index = input.indexOf('<');
                if (index >= 0) {
                    var charToCheck = input.charAt(index + 1);
                    if (isLetter(charToCheck) || charToCheck === '!' || charToCheck === '/' || charToCheck === '?') {
                        return true;
                    }
                }
            }
            return false;
        };

        function checkASCIITags(input) {
            if (input && input.length > 0) {
                var index = input.indexOf('&');
                if (index >= 0) {
                    var charToCheck = input.charAt(index + 1);
                    if (charToCheck === '#') {
                        return true;
                    }
                }
            }
            return false;
        };

        return {
            checkHTMLTags: checkHTMLTags,
            checkASCIITags: checkASCIITags
        };

    }]);

})();