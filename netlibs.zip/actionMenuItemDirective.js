﻿(function () {

    "use strict";

    checkmarx.ProjectState.directive('actionMenuItemLink', [
        function () {
            return {
                template: '<a href="{{href}}" target="{{target}}">{{title}}</a>',
                restrict: 'E',
                scope: {
                    title: '@',
                    href: '@',
                    target: '@?'
                }
            }
        }]);

}());