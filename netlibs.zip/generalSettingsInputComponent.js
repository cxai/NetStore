﻿
(function () {
    "use strict";

    checkmarx.ApplicationSettings.component('generalSettingsInput', {
        transclude: true,
        template: '<div class="col-lg-12 form-group" ng-class="{\'has-error\': !$ctrl.isDisabled && $ctrl.isElementInvalid}">'
                        + '<label class="{{$ctrl.className}}-label">{{ $ctrl.lable }}</label>'
                        + '<input type="{{$ctrl.inputType}}" class="{{$ctrl.className}}-input form-control" ng-class="{\'disabled\': $ctrl.isDisabled}"'
                                + 'id="{{$ctrl.name}}" name="{{$ctrl.name}}" ng-model="$ctrl.inputModel" ng-click="$ctrl.inputClickHandler && $ctrl.inputClickHandler()"'
                                + 'placeholder="{{$ctrl.placeholder}}" min="{{$ctrl.min}}" max="{{$ctrl.max}}" ng-required="$ctrl.isRequired" ng-readonly="$ctrl.isReadonly" web-server-address="{{$ctrl.isWebServerAddress}}" check-xss>'
                        + '<ng-transclude></ng-transclude>'
                + '</div>',
        bindings: {
            lable: '@',
            name: '@',
            className: '@',
            inputType: '@',
            inputModel: '=',
            placeholder: '@',
            isDisabled: '<',
            min: '@',
            max: '<',
            isRequired: '=',
            isReadonly: '=',
            isWebServerAddress: '@',
            isElementInvalid: '=',
            inputClickHandler: '&'
        }
    });
})();