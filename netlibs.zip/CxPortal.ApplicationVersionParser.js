﻿(function () {
    "use strict";
    
    checkmarx.CxPortal.factory('CxPortal.ApplicationVersionParser', [function () {

        function parse(str) {

            var numberPattern = /\d+/g;
            var versionNumberArray = null;

            if (str != null) {

                versionNumberArray = str.match(numberPattern);
            }

            if (versionNumberArray != null && versionNumberArray.length > 0) {

                str = versionNumberArray.join('.');
            }
            else {
                str = "";
            }

            return str;
        }

        return {
            parse: parse
        };

    }]);

})();