﻿(function () {
    "use strict";

    checkmarx.CxAcademy.controller('Codebashing.SettingsController', [
        '$scope',
        'AppSecCoach.SettingsDataService',
        '$rootScope',
        'preventPageNavigationService',
        '$translate',
        function ($scope,
            appSecCoachSettingsDataService,
            $rootScope,
            preventPageNavigationService,
            $translate) {
            
            $scope.switchToEditMode = function () {
                $scope.isEditMode = true;
                preventPageNavigationService.registerUnloadEvent(function (event) {
                    event.returnValue = $translate.instant('LEAVING_PAGE_LOSS_OF_CHANGES_WARNING');
                });
            }

            $scope.cancelEditMode = function () {
                loadData();
                switchToViewMode();
            }

            $scope.putCodebashingSetting = function () {
                var putAppSecCoachSettingPromise = appSecCoachSettingsDataService.putAppSecCoachSetting({
                    codebashingIsEnabled: $scope.isCodebashingEnabled
                });
                putAppSecCoachSettingPromise.then(switchToViewMode());
            }

            function switchToViewMode() {
                $scope.isEditMode = false;
                preventPageNavigationService.removeUnloadEvent();
            }
            
            function init() {
                $scope.isEditMode = false;
                $scope.serverState = {};
                loadData();
            }
            
            function loadData() {
                appSecCoachSettingsDataService.getAppSecCoachSetting().then(function (setting) {
                    $scope.isCodebashingEnabled = (setting.codebashingIsEnabled.toLowerCase() === "true");
                });
            }

            init();
    }]);

})();