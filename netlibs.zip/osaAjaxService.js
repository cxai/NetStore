﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('osaAjaxService', [
        'ajaxService',        
        'osaRequestErrorFormatService',
        '$q',
        function (ajaxService, osaRequestErrorFormatService, $q) {
            /* ajax service for OSA related REST requests.
             * note: the additional $q added due to the migration of angular 1.3 to 1.6, that's because succes/error callback function are not supported anymore.
             */

            function displayError(data) {

                osaRequestErrorFormatService.format(data);
            }

            function get(url, config) {

                var deferred = $q.defer();

                ajaxService.get(url, config).then(function (result) {
                    deferred.resolve(result.data);
                })
                .catch(function (result, status, headers, config) {

                    if (result && result.data.errorCode) {
                        displayError(result.data);
                        deferred.reject(result.data);
                    }
                });

                return deferred.promise;
            }

            function post(url, data, config) {

                var deferred = $q.defer();

                ajaxService.post(url, data || {}, config || null).then(function (result) {
                    deferred.resolve(result.data);
                })
                .catch(function (result, status, headers, config) {

                    if (result && result.data.errorCode) {
                        displayError(result.data);
                        deferred.reject(result.data);
                    }
                });

                return deferred.promise;
            }

            return {
                get: get,
                post: post
            };

    }]);
})();