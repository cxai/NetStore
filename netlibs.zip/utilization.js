var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        // Directive controller implementation
        var UtilizationDirective = (function () {
            // Constructor (including dependencies that will be inserted automatically by angular)
            function UtilizationDirective(netService) {
                var _this = this;
                this.netService = netService;
                // Fields
                this.tabWidgetData = null;
                this.widgets = [];
                this.loading = true;
                this.tabId = 1;
                this.loading = true;
                netService.getTabWidgets(this.tabId).
                    then(function (tabWidgetData) {
                    _this.loading = false;
                    _this.tabWidgetData = tabWidgetData;
                    var widgetsIds = _this.getWidgetIds(tabWidgetData);
                    //get the all filters that exists in the tab
                    netService.getTabWidgetFilters(widgetsIds).then(function (tabWidgetsFilters) {
                        for (var i = 0; i < tabWidgetData.widgets.length; i++) {
                            var widgetFilters = _this.findWidgetFiltersById(tabWidgetData.widgets[i].id, tabWidgetsFilters);
                            tabWidgetData.widgets[i].filters = widgetFilters;
                        }
                    });
                });
            }
            UtilizationDirective.prototype.findWidgetFiltersById = function (widgetId, tabWidgetFilters) {
                for (var i = 0; i < tabWidgetFilters.length; i++) {
                    if (tabWidgetFilters[i].widgetId === widgetId) {
                        if (!tabWidgetFilters[i].filters) {
                            tabWidgetFilters[i].filters = [];
                        }
                        return tabWidgetFilters[i].filters;
                    }
                }
                return [];
            };
            UtilizationDirective.prototype.getWidgetIds = function (tabWidgetData) {
                var widgetsIds = [];
                for (var i = 0; i < tabWidgetData.widgets.length; i++) {
                    widgetsIds.push(tabWidgetData.widgets[i].id);
                }
                return widgetsIds;
            };
            // Specify the dependencies for this directive    
            UtilizationDirective.$inject = ['#net'];
            return UtilizationDirective;
        }());
        // Directive configuration
        function UtilizationDirectiveSettings() {
            return {
                restrict: 'E',
                replace: true,
                controller: UtilizationDirective,
                controllerAs: 'root',
                templateUrl: '/CxWebClient/pages/dashboard/utilization',
                scope: {}
            };
        }
        Directives.UtilizationDirectiveSettings = UtilizationDirectiveSettings;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=utilization.js.map