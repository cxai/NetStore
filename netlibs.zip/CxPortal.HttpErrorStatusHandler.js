﻿(function () {
    "use strict";

    checkmarx.CxPortal.factory('CxPortal.HttpErrorStatusHandler', ['$window','portalPageURLs',
        function ($window, portalPageURLs) {
        
        	function redirectToPageNotFound() {
        		$window.location = portalPageURLs.pageNotFound;
        	}
			
            return {
            	redirectToPageNotFound: redirectToPageNotFound
            };
    }]);

})();