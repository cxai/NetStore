﻿(function () {
    "use strict";

    checkmarx.Common.directive("uploadFile", ['$timeout', function ($timeout) {

        return {
            template: '<input ng-disabled="isDisable" ng-class="{ \'not-allowed\': isDisable }"  type="file" title="{{title}}" name="uploadFile" id="{{controlId}}" name="{{name}}" class="generic-file-upload" />',
            scope: {
                files: "=",
                isMultipleSupported: '=',
                filterFiles: '@', /* example: .htm,.html,.xml */
                placeholder: '@',
                cssClass: '@',
                name: '@',
                validatorDirective: '@',
                controlId: '@',
                title: '@',
                isDisable: '='
            },
            link: function (scope, element, attributes) {

                element.find('.generic-file-upload').bind("change", function (changeEvent) {

                    updateFilesOnScope(changeEvent);
                });

                scope.files = [];

                filterFiles();
                supporMultipleFiles();
                setPlaceHolder();
                setCssClass();
                setCustomValidatorDirective();

                scope.$on('clear-upload-files', function () {
                    scope.files = [];
                    $('#' + scope.controlId).val('');
                });

                function updateFilesOnScope(changeEvent) {
                    /* updates the files on current scope.
                       NOTE: always wrap external calls (such from DOM events) with $timeout, for forcing angular call $apply() function,
                       for updating the scope. */

                    $timeout(function () {
                        scope.files = changeEvent.target.files;
                    });
                }

                function filterFiles() {

                    if (scope.filterFiles) {
                        element.find('.generic-file-upload').attr('accept', scope.filterFiles);
                    }
                }

                function supporMultipleFiles() {

                    if (scope.isMultipleSupported) {
                        element.find('.generic-file-upload').attr('multiple', '');
                    }
                }

                function setPlaceHolder() {

                    if (scope.placeholder) {
                        element.find('.generic-file-upload').attr('placeholder', scope.placeholder);
                    }
                }

                function setCssClass() {

                    if (scope.cssClass) {
                        element.find('.generic-file-upload').attr('class', element.find('.generic-file-upload').attr('class') + ' ' + scope.cssClass);
                    }
                }

                function setCustomValidatorDirective() {

                    if (scope.validatorDirective) {
                        element.find('.generic-file-upload').attr(scope.validatorDirective, '');
                    }
                }
            }
        }
    }]);
})();