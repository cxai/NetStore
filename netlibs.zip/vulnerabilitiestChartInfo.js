﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.directive('vulnerabilitiestChartInfo', ['chartColumnDataNames', function (chartColumnDataNames) {

        return {
            template: '<span class="chart-info">'
                        + '{{countNew}} {{"' + chartColumnDataNames.New + '" | translate}}'
                        + '<br />'
                        + '{{countRecurring}} {{"' + chartColumnDataNames.Recurrent + '" | translate}}'
                        + '<br />'
                        + '<span class="solved">{{countSolved}} {{"' + chartColumnDataNames.Solved + '" | translate}}</span>'
                        + '<help-tooltip text="{{tooltipText}}"></help-tooltip>'
                    + '</span>',
            scope: {
                countNew: '@',
                countRecurring: '@',
                countSolved: '@',
                tooltipText: '@'
            }
        };
    }]);

})();