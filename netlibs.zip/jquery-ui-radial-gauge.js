(function (window, undefined) {
    window.Mathf = {
        lerpFloat: function (from, to, percent) {
            from = parseFloat(from);
            to = parseFloat(to);
            percent = parseFloat(percent);
            if (isNaN(from) || isNaN(to) || isNaN(percent)) {
                throw new Error("Not a valid float");
            }
            percent = Math.min(1, Math.max(0, percent));
            return (to - from) * percent + from;
        }
    }
    window.isEmptyString = function (value) {
        return value === undefined || value === null || value.toString() === '';
    }
})(window);
(function (window, undefined) {
    // Required for svg to work. svg attribures are case sensitive.
    $.attrHooks['viewbox'] = {
        set: function (elem, value, name) {
            elem.setAttribute('viewBox', value + '');
            return value;
        }
    };
    $.attrHooks['preserveaspectratio'] = {
        set: function (elem, value, name) {
            elem.setAttribute('preserveAspectRatio', value + '');
            return value;
        }
    };
    $.widget("dima.radialGauge", {
        options: {
            values: [],
            gaugeColors: ['#5d0', '#ee0', '#fb0', '#f70', '#f20'],
            textBackgroundColor: '#f9f9f9',
            textBackgroundStrokeColor: '#eaeaea',
            fontColor: '#000',
            fontFamily: 'Sans-Serif',
            responsive: true,
            hoverable: true,
            animate: false,
            ratioGauge: false
        },

        _defaultSettings: {
            graphCenterX: 500,
            graphCenterY: 400,
            gaugeInnerRadius: 325,
            gaugeOuterRadius: 375,
            textBackgroundRadius: 300,
            textBackgroundStrokeThickness: 3,
            smallFontSize: 70,
            largeFontSize: 140,
            innerTextSpacer: 35,
            outerTextYOffset: 150,
            outerTextSpacer: 14,
            hoveredItemOpacity: 0.8
        },

        _create: function () {
            var that = this;
            that._previousElementState = {};

            if (that.element.is("svg")) {
                that.svg = that.element;
                // When applied to an existing svg, the original attributes are saved so that they can be restored.
                that._previousElementState.height = that.svg.attr('height');
                that._previousElementState.width = that.svg.attr('width');
                that._previousElementState.viewBox = that.svg.attr('viewBox');
                that._previousElementState.aspectRatio = that.svg.attr('preserveAspectRatio');
            }
            else {
                // When applied to an element other than svg, create an svg element but preserve the original content.
                that._previousElementState.html = that.element.html();
                that.svg = $(that._createSvgElement('svg'));
                that.element.html(that.svg);
            }
            // Set a standsrd viewbox and aspect ration settings to preserve proportions of rendered chart.
            that.svg.attr({
                'viewBox': '0 0 1000 1000',
                'preserveAspectRatio': 'xMidYMid meet'
            });
            that._settings = $.extend({}, that._defaultSettings);
            that._setupSize();
            that._createChart();
            that._setupHover();
        },

        _destroy: function () {
            var that = this;

            that._unsubscribeWindowResize();
            if (that._previousElementState.html) {
                that.svg.remove();
                that.element.html(that._previousElementState.html);
            }
            else {
                that._previousElementState.height !== undefined
					? that.svg.attr('height', that._previousElementState.height)
					: that.svg.removeAttr('height');

                that._previousElementState.width !== undefined
					? that.svg.attr('width', that._previousElementState.width)
					: that.svg.removeAttr('width');

                that._previousElementState.viewBox !== undefined
					? that.svg.attr('viewBox', that._previousElementState.viewBox)
					: that.svg.removeAttr('viewBox');

                that._previousElementState.aspectRatio !== undefined
					? that.svg.attr('preserveAspectRatio', that._previousElementState.aspectRatio)
					: that.svg.removeAttr('preserveAspectRatio');
            }
        },

        _setOption: function (key, value) {
            var that = this;
            that._super(key, value);
        },

        _setOptions: function () {
            var that = this;
            that._superApply(arguments);

            var updateGauge = false,
			updateTextStyles = false,
			updateText = false,
			updateResponsiveness = false,
			updateHover = false;

            if (arguments.length === 1) {
                Object.keys(arguments[0]).forEach(function (key, index, arr) {
                    switch (key) {
                        case "values":
                        case "gaugeColors":
                        case "ratioGauge":
                            updateGauge = true;
                            break;
                        case "textBackgroundColor":
                        case "textBackgroundStrokeColor":
                        case "fontColor":
                        case "fontFamily":
                            updateTextStyles = true;
                            break;
                        case "innerText":
                        case "outerText":
                            updateText = true;
                            break;
                        case "responsive":
                            updateResponsiveness = true;
                            break;
                        case "hoverable":
                            updateHover = true;
                            break;
                    }
                });

                if (updateResponsiveness) {
                    that._setupSize();
                }
                if (updateTextStyles) {
                    that._updateTextStyles();
                }
                if (updateText) {
                    that._updateText();
                }
                if (updateGauge) {
                    that._updateGauge();
                }
                if (updateHover) {
                    that._setupHover();
                }
            }
        },

        _createSvgElement: function (tag) {
            return document.createElementNS("http://www.w3.org/2000/svg", tag);
        },

        _setupSize: function () {
            var that = this;
            if (!!that.options.responsive) {
                that._subscribeWindowResize();
                that._fitToParent();
            }
            else {
                that._unsubscribeWindowResize();
                that._fitToOptions();
            }
        },

        _subscribeWindowResize: function () {
            var that = this;
            $(window).on('resize.radialGauge' + that.uuid, function (event) {
                clearTimeout(that._resizeTimeout);
                that._resizeTimeout = setTimeout(function () {
                    clearInterval(that._animationInterval);
                    that._fitToParent();
                }, 100);
            });
        },

        _unsubscribeWindowResize: function () {
            var that = this;
            $(window).off('resize.radialGauge' + that.uuid);
        },

        _fitToParent: function () {
            var that = this,
			container = that.svg.parent(),
			width = container.width(),
			height = container.height();

            that.svg.attr({
                'width': width,
                'height': height
            });
        },

        _fitToOptions: function () {
            var that = this;

            that.options.width !== undefined
				? that.svg.attr('width', that.options.width)
				: that.svg.removeAttr('width');

            that.options.height !== undefined
				? that.svg.attr('height', that.options.height)
				: that.svg.removeAttr('height');
        },

        _setupHover: function () {
            var that = this;
            var hoverCallback = function (event) {
                var path = $(event.target),
					index = path.data('segment-index'),
					color = that.options.gaugeColors[index % that.options.gaugeColors.length],
					hoverColor = $.Color(color).alpha(that._settings.hoveredItemOpacity).toString()
                $(event.target).attr({
                    'fill': hoverColor
                });
            };
            var leaveCallback = function (event) {
                var path = $(event.target),
					index = path.data('segment-index'),
					color = that.options.gaugeColors[index % that.options.gaugeColors.length];
                $(event.target).attr({
                    'fill': color
                });
            }

            if (!!that.options.hoverable) {
                that.gauge.on('mouseenter.radialGauge.' + that.uuid, 'path', hoverCallback);
                that.gauge.on('mouseleave.radialGauge.' + that.uuid, 'path', leaveCallback);
            }
            else {
                that.gauge.off('mouseenter.radialGauge.' + that.uuid, 'path');
                that.gauge.off('mouseleave.radialGauge.' + that.uuid, 'path');
            }
        },

        _createChart: function () {
            var that = this;
            // Mask that creates the hollow space between the text background and the gauge.
            that.gaugeMask = $(that._createSvgElement('mask')).attr({
                'id': 'gauge-mask'
            }).appendTo(that.svg);
            that.gaugeVisibleMask = $(that._createSvgElement('circle')).attr({
                'cx': that._settings.graphCenterX,
                'cy': that._settings.graphCenterY,
                'r': that._settings.gaugeOuterRadius,
                'fill': '#fff'
            }).appendTo(that.gaugeMask);
            that.gaugeHiddenMask = $(that._createSvgElement('circle')).attr({
                'cx': that._settings.graphCenterX,
                'cy': that._settings.graphCenterY,
                'r': that._settings.gaugeInnerRadius,
                'fill': '#000'
            }).appendTo(that.gaugeMask);
            // Common container for all gauge parts to apply the mask to all of them.
            that.gauge = $(that._createSvgElement('g')).attr({
                'mask': 'url(#gauge-mask)'
            }).appendTo(that.svg);

            that.textbg = $(that._createSvgElement('circle')).attr({
                'cx': that._settings.graphCenterX,
                'cy': that._settings.graphCenterY,
                'r': that._settings.textBackgroundRadius
            }).appendTo(that.svg);

            // Container for all 3 parts of the inner text to control positioning.
            that.innerText = $(that._createSvgElement('text')).attr({
                'transform': 'translate(' + that._settings.graphCenterX + ',' + that._settings.graphCenterY + ')',
                'text-anchor': 'middle'
            }).appendTo(that.svg);
            that.innerprefix = $(that._createSvgElement('tspan')).attr({
                'x': 0,
                'y': 0
            }).appendTo(that.innerText);
            that.innervalue = $(that._createSvgElement('tspan')).attr({
                'x': 0,
                'y': 0
            }).appendTo(that.innerText);
            that.innersuffix = $(that._createSvgElement('tspan')).attr({
                'x': 0,
                'y': 0
            }).appendTo(that.innerText);

            // Container for all 3 parts of the outer text to control positioning.
            that.outerText = $(that._createSvgElement('text')).attr({
                'x': that._settings.graphCenterX,
                'y': that._settings.graphCenterY + that._settings.gaugeOuterRadius + that._settings.outerTextYOffset,
                'text-anchor': 'middle'
            }).appendTo(that.svg);
            that.outerprefix = $(that._createSvgElement('tspan')).appendTo(that.outerText);
            that.outerprespacer = $(that._createSvgElement('tspan')).appendTo(that.outerText);
            that.outervalue = $(that._createSvgElement('tspan')).appendTo(that.outerText);
            that.outerpostspacer = $(that._createSvgElement('tspan')).appendTo(that.outerText);
            that.outersuffix = $(that._createSvgElement('tspan')).appendTo(that.outerText);

            that._updateTextStyles();
            that._updateText();
            that._updateGauge();
        },

        _updateTextStyles: function () {
            var that = this;

            that.textbg.attr({
                'fill': that.options.textBackgroundColor,
                'stroke': that.options.textBackgroundStrokeColor,
                'stroke-width': that._settings.textBackgroundStrokeThickness
            });
            // The dominant-baseline attribute is poorly supported. So i'm using 'dy' to emulate central baseline alignment.
            that.innerText.css({
                'fill': that.options.fontColor,
                'font-family': that.options.fontFamily
            });
            that.innerprefix.attr({
                'font-size': that._settings.smallFontSize,
                'dy': that._settings.smallFontSize / 2
            });
            that.innervalue.attr({
                'font-size': that._settings.largeFontSize,
                'dy': that._settings.largeFontSize / 2
            });
            that.innersuffix.attr({
                'font-size': that._settings.smallFontSize,
                'dy': that._settings.smallFontSize / 2
            });
            that.outerText.css({
                'fill': that.options.fontColor,
                'font-family': that.options.fontFamily
            });
            that.outerprefix.attr({
                'font-size': that._settings.smallFontSize
            });
            that.outerprespacer.attr({
                'font-size': that._settings.smallFontSize
            });
            that.outervalue.attr({
                'font-size': that._settings.largeFontSize
            });
            that.outerpostspacer.attr({
                'font-size': that._settings.smallFontSize
            });
            that.outersuffix.attr({
                'font-size': that._settings.smallFontSize
            });
        },

        _updateText: function () {
            var that = this;

            that.innerprefix.text(that.options.innerText && that.options.innerText.prefix);
            that.innervalue.text(that.options.innerText && that.options.innerText.value);
            that.innersuffix.text(that.options.innerText && that.options.innerText.suffix);

            that.outerprefix.text(that.options.outerText && that.options.outerText.prefix);
            that.outervalue.text(that.options.outerText && that.options.outerText.value);
            that.outersuffix.text(that.options.outerText && that.options.outerText.suffix);

            // Offset the positions of text depending on which text is shown to center the text vertically.
            if (that.options.innerText) {
                if (!isEmptyString(that.options.innerText.prefix) && !isEmptyString(that.options.innerText.value) && !isEmptyString(that.options.innerText.suffix)) {
                    that.innerprefix.attr('y', -(that._settings.smallFontSize + that._settings.largeFontSize + that._settings.innerTextSpacer) / 2);
                    that.innervalue.attr('y', 0);
                    that.innersuffix.attr('y', that._settings.smallFontSize / 2 + that._settings.largeFontSize / 2 + that._settings.innerTextSpacer);
                }
                else if (!isEmptyString(that.options.innerText.prefix) && !isEmptyString(that.options.innerText.value)) {
                    that.innerprefix.attr('y', -(that._settings.smallFontSize + that._settings.largeFontSize + that._settings.innerTextSpacer) / 4);
                    that.innervalue.attr('y', (that._settings.smallFontSize + that._settings.largeFontSize + that._settings.innerTextSpacer) / 4);
                }
                else if (!isEmptyString(that.options.innerText.value) && !isEmptyString(that.options.innerText.suffix)) {
                    that.innervalue.attr('y', -(that._settings.smallFontSize + that._settings.largeFontSize + that._settings.innerTextSpacer) / 4);
                    that.innersuffix.attr('y', (that._settings.smallFontSize + that._settings.largeFontSize + that._settings.innerTextSpacer) / 4);
                }
                else if (!isEmptyString(that.options.innerText.prefix) && !isEmptyString(that.options.innerText.suffix)) {
                    that.innerprefix.attr('y', -(that._settings.smallFontSize + that._settings.innerTextSpacer) / 2);
                    that.innersuffix.attr('y', (that._settings.smallFontSize + that._settings.innerTextSpacer) / 2);
                }
            }

            // Add or remove spacing between the parts of the outer text to make sure that the text is evenly spaced.
            if (that.options.outerText) {
                // Chrome seems to have a measuring issue which causes the text to collapse one on top of the other, timeout fixes it.
                setTimeout(function () {
                    if (!isEmptyString(that.options.outerText.prefix) && !isEmptyString(that.options.outerText.value) && !isEmptyString(that.options.outerText.suffix)) {
                        that.outerprespacer.text(' ');
                        that.outerpostspacer.text(' ');
                    }
                    else if (!isEmptyString(that.options.outerText.prefix) && !isEmptyString(that.options.outerText.value)) {
                        that.outerprespacer.text(' ');
                        that.outerpostspacer.text('');
                    }
                    else if (!isEmptyString(that.options.outerText.value) && !isEmptyString(that.options.outerText.suffix)) {
                        that.outerprespacer.text('');
                        that.outerpostspacer.text(' ');
                    }
                    else if (!isEmptyString(that.options.outerText.prefix) && !isEmptyString(that.options.outerText.suffix)) {
                        that.outerprespacer.text(' ');
                        that.outerpostspacer.text('');
                    }
                }, 0);
            }
        },

        _updateGauge: function () {
            var that = this,
				values = that.options.values,
				segments = [],
				total = that.options.values.reduce(function (prev, curr) { return prev + curr; }, 0),
				// Apply proportional scaling in case the values exceed 100% or if ratioGauge is set to true.
				scaledTotal = that.options.values.reduce(function (prev, curr) {
				    var percent = (!!that.options.ratioGauge || total > 100)
						? curr * 100 / total
						: curr;

				    segments.push([prev * 3.6, (prev + percent) * 3.6]);

				    return prev + percent;
				}, 0),
				paths = Array.prototype.slice.call(that.gauge.children('path'), 0);

            // If values were added, create any missing paths.
            while (paths.length < segments.length) {
                var path = $(that._createSvgElement("path")).data('segment-index', paths.length);
                that.gauge.append(path);
                paths.push(path);
            }

            // Used to maintain animation values in case of rapid value changes.
            that._segments = that._segments || [];

            if (!!that.options.animate) {
                var animationDuration = 400,
				stepDuration = 13,
				steps = animationDuration / stepDuration,
				percentPerStep = 1 / steps;

                that._animationPercent = 0;
                clearInterval(that._animationInterval);
                that._animationInterval = setInterval(function () {
                    that._animationPercent = that._animationPercent + percentPerStep;

                    var animatedSegments = [];

                    // Find next animation frame for all segments of the gauge.
                    segments.forEach(function (segment, idx) {
                        var targetSize = segment[1] - segment[0],
							targetPosition = segments.slice(0, idx).reduce(function (prev, curr) { return prev + (curr[1] - curr[0]); }, 0),
							sourceSize = (that._segments.length > idx)
								? that._segments[idx][1] - that._segments[idx][0]
								: 0,
							sourcePosition = ((that._segments.length > idx)
								? that._segments.slice(0, idx)
								: that._segments).reduce(function (prev, curr) { return prev + (curr[1] - curr[0]); }, 0);

                        animatedStart = Mathf.lerpFloat(sourcePosition, targetPosition, that._animationPercent),
                        animatedEnd = Mathf.lerpFloat(sourcePosition + sourceSize, targetPosition + targetSize, that._animationPercent);

                        animatedSegments.push([animatedStart, animatedEnd]);
                    });

                    // Find next animation frame for all segments that are obsolete and need to be scaled down to 0 prior to removal.
                    that._segments.slice(segments.length).forEach(function (segment, idx) {
                        var sourceSize = segment[1] - segment[0],
							sourcePosition = segment[0],
							targetSize = 0,
							targetPosition = segments.reduce(function (prev, curr) { return prev + (curr[1] - curr[0]); }, 0),

							animatedStart = Mathf.lerpFloat(sourcePosition, targetPosition, that._animationPercent),
							animatedEnd = Mathf.lerpFloat(sourcePosition + sourceSize, targetPosition + targetSize, that._animationPercent);

                        animatedSegments.push([animatedStart, animatedEnd]);
                    });

                    // Update visual representation of all segments.
                    animatedSegments.forEach(function (segment, idx) {
                        var color = that.options.gaugeColors[idx % that.options.gaugeColors.length];
                        $(paths[idx]).attr({
                            'fill': color,
                            'd': that._describeArc(that._settings.graphCenterX, that._settings.graphCenterY, that._settings.gaugeOuterRadius, segment[0], segment[1])
                        });
                    });

                    if (that._animationPercent >= 1) {
                        clearInterval(that._animationInterval);
                        // Remove any obsolete paths after the animation is completed.
                        while (paths.length > segments.length) {
                            var path = paths[paths.length - 1];
                            $(path).remove();
                            paths.pop();
                        }

                        that._segments = segments;
                    }
                }, stepDuration);
            }
            else {
                // Update the visual representation of every segment of the gauge.
                segments.forEach(function (segment, idx) {
                    var color = that.options.gaugeColors[idx % that.options.gaugeColors.length];
                    $(paths[idx]).attr({
                        'fill': color,
                        'd': that._describeArc(that._settings.graphCenterX, that._settings.graphCenterY, that._settings.gaugeOuterRadius, segment[0], segment[1])
                    });
                });

                // Remove any obsolete paths in case values were removed.
                while (paths.length > segments.length) {
                    var path = paths[paths.length - 1];
                    $(path).remove();
                    paths.pop();
                }

                that._segments = segments;
            }
        },

        _describeArc: function (x, y, radius, startAngle, endAngle) {
            var that = this,
				// Svg paths cannot render a 360 degree circle, it is reset to 0.
				// A workwround is used, reducing a 360 degree angle by 0.0001 degrees, and completing the rendering with a line.
				// Floating point precision is not perfect, so I'm using a delta comparison instead of an equals operation.
				is360deg = Math.abs(360 - (endAngle - startAngle)) < 0.0001,
				start = that._polarToCartesian(x, y, radius, endAngle - (is360deg ? 0.0001 : 0)),
				end = that._polarToCartesian(x, y, radius, startAngle),
				arcSweep = endAngle - startAngle <= 180 ? "0" : "1";

            return is360deg
				? [
					"M", x, y,
					"L", start.x, start.y,
					"A", radius, radius, 0, arcSweep, 0, end.x, end.y,
					// Close the incomplete circle.
					"L", start.x, start.y,
					"Z"
				].join(" ")
				: [
					"M", x, y,
					"L", start.x, start.y,
					"A", radius, radius, 0, arcSweep, 0, end.x, end.y,
					"Z"
				].join(" ");
        },

        _polarToCartesian: function (centerX, centerY, radius, angleInDegrees) {
            var angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;

            return {
                x: centerX + (radius * Math.cos(angleInRadians)),
                y: centerY + (radius * Math.sin(angleInRadians))
            };
        }
    });
}(window));