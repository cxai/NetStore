﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxPortal.factory('userPreferencesService', ['localStorageService', 'projectsLocalStorageKeys',
        function (localStorageService, projectsLocalStorageKeys) {
           
            var userPreferences = {
                SASTNotificationToHide: [],
                SASTIsRunningModalToHide: [],
                SASTEmptyStateToHide: []
            };

            function getUserPreferences() {

                return localStorageService.getJSONItem(projectsLocalStorageKeys.userPreferences);
            }

            function insertUserPreferences(objectToInsert, key, propertyName) {

                var result = getUserPreferences();

                if (result) {

                    for (var i = 0; i < result[key].length; i++) {

                        if (result[key][i][propertyName] == objectToInsert[propertyName]) {
                            return;
                        }
                    }

                    result[key].push(objectToInsert);
                    localStorageService.setJSONItem(projectsLocalStorageKeys.userPreferences, result);
                }
                else {
                    userPreferences[key].push(objectToInsert);
                    localStorageService.setJSONItem(projectsLocalStorageKeys.userPreferences, userPreferences);
                }
            }

            function hideNoScanModal(projectId) {

                insertUserPreferences({
                    projectId: projectId
                }, "SASTEmptyStateToHide", "projectId");
            }

            function hideSASTIsRunningModal(scanId) {

                insertUserPreferences({
                    scanId: scanId
                }, "SASTIsRunningModalToHide", "scanId");
            }

            function hideSASTIsRunningNotifications(scanId) {

                insertUserPreferences({
                    scanId: scanId
                }, "SASTNotificationToHide", "scanId");
            }

            return {
                hideNoScanModal: hideNoScanModal,
                hideSASTIsRunningModal: hideSASTIsRunningModal,
                hideSASTIsRunningNotifications: hideSASTIsRunningNotifications,
                getUserPreferences: getUserPreferences
            };
    }]);

})();