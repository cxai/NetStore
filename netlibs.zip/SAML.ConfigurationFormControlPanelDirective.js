﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxPortal.directive('configurationFormControlPanel', [function () {

        return {
            restrict: 'E',
            template: '<div class="form-control-panel-container panel-error-message" ng-show="showPanelErrorMessage">{{panelErrorMessage}}</div>'
                    + '<form-control-panel>'
                        + '<button type="button" ng-disabled="disableButtons(SAML)" class="btn btn-default saml-test-btn saml-btn-text" ng-click="cancel(SAML)">{{"CANCEL" | translate}}</button>' //saml-cancel-btn
                        + '<button type="submit" ng-disabled="disableButtons(SAML)" class="btn btn-default saml-save-btn saml-btn-text" ng-click="saveConfiguration(SAML)">{{"SAVE" | translate}}</button>'
                    + '</form-control-panel>',
            controller: ['$scope',
                        'SAML.ConfigurationDataService',
                        '$translate',
                        'modalService',
                        'SAML.ConfigurationValidatorAndNotifier',
                        'SAML.ConfigurationExternalCertificateService',
                        '$q',
                function ($scope, samlConfigurationDataService, $translate, modalService, configurationValidatorAndNotifier, externalCertificateService, $q) {

                    $scope.showPanelErrorMessage = false;
                    $scope.panelErrorMessage = $translate.instant('PANEL_ERROR_MESSAGE');

                    $scope.$on('yes-disable-saml-modal', function () {

                        $scope.savedSAMLFromLoad.isEnabled = false;
                        saveConfiguration($scope.savedSAMLFromLoad);
                    });

                    $scope.saveConfiguration = function (samlConfiguration) {

                        if (!samlConfiguration.isEnabled && $scope.disableClicked) {

                            modalService.openModalHTMLTemplate('<disable-saml-modal></disable-saml-modal>',
                                    'saml-disable-modal');
                        }
                        else {
                                saveConfiguration(samlConfiguration);
                        }
                    };

                    $scope.cancel = function (samlObject) {
                        $scope.showPanelErrorMessage = false;

                        modalService.openModalHTMLTemplate('<cancel-saml-modal></cancel-saml-modal>',
                                'saml-cancel-modal');
                    };

                    $scope.disableButtons = function (SAML) {
                        return $scope.form.$pristine &&
                            (!SAML.idPCertificateFiles || SAML.idPCertificateFiles.length == 0) &&
                            (!SAML.externalCertificateFiles || SAML.externalCertificateFiles.length == 0) &&
                            !SAML.manualUserManagement.defaultTeam.isTouched;
                    }

                    function initializeParameters() {
                        $scope.invalidCertificate = false;
                        $scope.invalidExternalCertificate = false;
                        $scope.showPanelErrorMessage = false;
                        $scope.panelErrorMessage = $translate.instant('PANEL_ERROR_MESSAGE');
                    }

                    function createExternalCertificateData(samlConfiguration) {
                        var formData = new FormData();
                        formData.append("spCertificateFile", samlConfiguration.externalCertificateFiles && samlConfiguration.externalCertificateFiles[0] ? samlConfiguration.externalCertificateFiles[0] : "");
                        formData.append("certificatePassword", samlConfiguration.certificatePassword ? samlConfiguration.certificatePassword : "");
                        return formData;
                    };

                    function getPromises(samlConfiguration, isPost) {
                        var promises = [];

                        if (isPost) {
                            promises.push(samlConfigurationDataService.post(samlConfiguration));
                        } else {
                            promises.push(samlConfigurationDataService.put(samlConfiguration));
                        }

                        if (samlConfiguration.clientSignatureRequired && samlConfiguration.externalCertificateFiles && samlConfiguration.externalCertificateFiles.length > 0) {
                            var data = createExternalCertificateData(samlConfiguration);
                            promises.push(externalCertificateService.post(data));
                        }

                        return promises;
                    };

                    function postConfiguration(samlConfiguration) {

                        var promises = getPromises(samlConfiguration, true);                        

                        $q.all(promises).then(function (result) {
                                configurationValidatorAndNotifier.notifySuccess($scope);
                                $scope.isFirstSave = false;
                        }).catch(function (error) {
                            configurationValidatorAndNotifier.notifyFailure(error.data.messageDetails, $scope);
                        });
                    }

                    function putConfiguration(samlConfiguration) {

                        var promises = getPromises(samlConfiguration, false);

                        $q.all(promises).then(function (result) {
                                configurationValidatorAndNotifier.notifySuccess($scope);
                        }).catch(function (error) {
                            configurationValidatorAndNotifier.notifyFailure(error.data.messageDetails, $scope);
                        });
                    }

                    function saveConfiguration(samlConfiguration) {
                        initializeParameters();
                           
                        if (configurationValidatorAndNotifier.isFormValid(samlConfiguration, $scope)) {

                            if ($scope.isFirstSave) {
                                postConfiguration(samlConfiguration);
                            }
                            else {
                                putConfiguration(samlConfiguration);
                            }
                        }
                        else {
                            $scope.showPanelErrorMessage = true;
                        }
                    };
            }]
        };
    }]);
})();