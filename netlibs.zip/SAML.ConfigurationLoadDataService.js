﻿(function () {
    "use strict";

    checkmarx.SAML.factory('SAML.ConfigurationLoadDataService', ['cxPortalRolesPrivileges', 'cxPortalRoles', function (cxPortalRolesPrivileges, cxPortalRoles) {

        function isScannerAndNotExploitableIsUnchecked(allowedRoleActions) {
            return allowedRoleActions.indexOf(cxPortalRolesPrivileges.allowNotExploitable) < 0;
        }

        function setNotExploitableAsDefaultIfNotScanner(manualUserManagement, allowedRoleActions) {
            if (manualUserManagement.role.id != cxPortalRoles.scanner) {
                manualUserManagement.allowNotExploitable = true;
            }
            else {
                manualUserManagement.allowNotExploitable = !isScannerAndNotExploitableIsUnchecked(allowedRoleActions);
            }
        }

        function setRolePrivileges(manualUserManagement, allowedRoleActions) {
            if (allowedRoleActions) {
                var values = allowedRoleActions.split(',');
                var index;

                for (var i in values) {
                    index = parseInt(i);
                    switch (values[i]) {
                        case cxPortalRolesPrivileges.allowSeverityAndStatusChanges.toString():
                            manualUserManagement.allowSeverityAndStatusChanges = true;
                            break;
                        case cxPortalRolesPrivileges.allowNotExploitable.toString():
                            manualUserManagement.allowNotExploitable = true;
                            break;
                        case cxPortalRolesPrivileges.allowProjectAndScanDelete.toString():
                            manualUserManagement.allowProjectAndScanDelete = true;
                            break;
                    }
                }
            }
            setNotExploitableAsDefaultIfNotScanner(manualUserManagement, allowedRoleActions);
        }

        function loadUserManagementData(scopeIdentityProviderObject, data) {

            scopeIdentityProviderObject.userManagementMethod.value = data.isManualManagement == undefined ? 1 : (data.isManualManagement ? 1 : 0);

            if (data.isManualManagement) {

                if (data.defaultTeamId) {
                    scopeIdentityProviderObject.manualUserManagement.defaultTeam.value = data.defaultTeamId;
                    samlConfigurationExternalService.setSavedOrDefaultValueAndDisableAllNodesThatAreNotTeams();
                }

                if (data.defaultRole) {
                    if (data.defaultRole.toLowerCase() == cxPortalRoles.scanner)
                        scopeIdentityProviderObject.manualUserManagement.role = scopeIdentityProviderObject.manualUserManagement.roles[0];
                    else 
                        scopeIdentityProviderObject.manualUserManagement.role = scopeIdentityProviderObject.manualUserManagement.roles[1];
                }

                setRolePrivileges(scopeIdentityProviderObject.manualUserManagement, data.allowedRoleActions);
            }
        }

        function load(scopeIdentityProviderObject, configurationData, signatureCertificateData) {
            if (configurationData) {
                scopeIdentityProviderObject.isEnabled = configurationData.isEnabled;
                scopeIdentityProviderObject.samlApiName = configurationData.name;
                scopeIdentityProviderObject.identityProvider = configurationData.issuer;
                scopeIdentityProviderObject.loginURL = configurationData.loginUrl;
                scopeIdentityProviderObject.logoutURL = configurationData.logoutUrl;
                scopeIdentityProviderObject.errorURL = configurationData.customErrorUrl;
                scopeIdentityProviderObject.certificateDetails = configurationData.certificateDetails;
                scopeIdentityProviderObject.clientSignatureRequired = configurationData.clientSignatureRequired;

                loadUserManagementData(scopeIdentityProviderObject, configurationData);
            }

            if (signatureCertificateData) {
                scopeIdentityProviderObject.externalCertificateDetails = signatureCertificateData.certificateDetails;
                scopeIdentityProviderObject.certificatePassword = "";
            }
        }

        function duplicateData(object, data) {
            if (data) {
                object.isEnabled = data.isEnabled;
                object.samlApiName = data.samlApiName;
                object.identityProvider = data.identityProvider;
                object.loginURL = data.loginURL;
                object.logoutURL = data.logoutURL;
                object.errorURL = data.errorURL;

                object.clientSignatureRequired = data.clientSignatureRequired;

                object.certificateDetails = data.certificateDetails;
                object.externalCertificateDetails = data.externalCertificateDetails;
                object.certificatePassword = data.certificatePassword;

                object.userManagementMethod = data.userManagementMethod;

                if (!object.manualUserManagement) {
                    object.manualUserManagement = {};
                    object.manualUserManagement.defaultTeam = {};
                }

                object.manualUserManagement.defaultTeam.value = data.manualUserManagement.defaultTeam.value;
                object.manualUserManagement.role = data.manualUserManagement.role;

                object.manualUserManagement.allowSeverityAndStatusChanges = data.manualUserManagement.allowSeverityAndStatusChanges;
                object.manualUserManagement.allowNotExploitable = data.manualUserManagement.allowNotExploitable;
                object.manualUserManagement.allowProjectAndScanDelete = data.manualUserManagement.allowProjectAndScanDelete;
            }
        }

        return {
            load: load,
            duplicateData: duplicateData
        };

    }]);
})();