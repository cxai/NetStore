﻿
(function () {

    "use strict";

    checkmarx.ProjectState.directive('projectStateHeaderProject', function () {
        return {

            templateUrl: "/CxWebClient/app/projectState/views/projectStateHeaderProject.html",
            controller: [
                '$scope',
                '$stateParams',
                '$rootScope',
                'modalService',
                'projectStatePreloadedData',
                function ($scope,
                    $stateParams,
                    $rootScope,
                    modalService,
                    projectStatePreloadedData) {

                    $rootScope.specificView = "project-state-header-project";
                    $scope.id = $stateParams.id;
                    $scope.projectName = projectStatePreloadedData.projectDetails().name;
                    var lastScanData = projectStatePreloadedData.finishedScansLatest();

                    $scope.$on("$destroy", function () {
                        $rootScope.specificView = "";
                    });

                    if (lastScanData) {
                        $scope.scanId = lastScanData.id;
                    }
                    else {
                        $scope.noSastScan = true;
                        $("#openViewerBtn").click(function (event) {
                            event.preventDefault();
                        });
                    }

                    $scope.runOSAClicked = function () {
                        $scope.$broadcast('RunOSAAnalysisClicked');
                    };

                    $scope.openScanSummary = function () {
                        if ($scope.noSastScan != true) {
                            modalService.openModal(null,
                                '<iframe class="scan-summary-iframe" src="/CxWebClient/popScanSummery.aspx?ProjectId=' + $scope.id + '&ScanID=' + $scope.scanId + '"></iframe>',
                                'scan-summary-modal');
                        }
                    };
                }]
        }
    });

}());