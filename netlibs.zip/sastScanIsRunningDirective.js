﻿(function () {
    "use strict";

    checkmarx.ProjectState.directive('sastScanIsRunning', [function () {

        var template = '<div class="modal-sast-scan-is-running">'
                    + ' <div class="sast-scan-is-running-container">'
                    + ' <img src="app/projectState/style/images/sast_in_progress.png" />'
                    + '     <div>'
                    + '         <span>{{\'SCAN_IN_PROGRESS\' | translate}}</span><br />'
                    + '         <a ng-href="/CxWebClient/UserQueue.aspx">{{"SCAN_QUEUE_DETAILS" | translate}} ></a>'
                    + '     </div>'
                    + ' </div>'
                    + '</div>';
        return {
            controller: ['$rootScope', '$scope', '$stateParams', 'modalService', 'userPreferencesService', 'showHideSASTNotificationsService', 'scanRequestGeneralStages',
                function ($rootScope, $scope, $stateParams, modalService, userPreferencesService, showHideSASTNotificationsService, scanRequestGeneralStages) {

                    var modal = null;
                    var projectId = $stateParams.id;

                    function shouldOpenModal() {

                        return $scope.currentScanGeneralStageId == scanRequestGeneralStages.progress &&
                                showHideSASTNotificationsService.shouldShowSASTEmptyStateModal(projectId) && 
                                    showHideSASTNotificationsService.shouldShowSASTIsRunningModal($scope.currentScanId);
                    }

                    function openModal() {

                        if (shouldOpenModal()) {

                            modal = modalService.openModalHTMLTemplate(template, 'sast-scan-is-running');
                            userPreferencesService.hideSASTIsRunningModal($scope.currentScanId);
                        }
                    }

                    $rootScope.$on('openSASTScanIsRunningModal', function () {
                        openModal();
                    });
            }]
        };

    }]);

})();