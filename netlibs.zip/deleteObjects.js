﻿function showDeleteObjectsPopup(errorsList, numOfDeletedObjects, title, text, closeText, confirmText, isScanFlow){
    swal({
        title: title,
        text: text,
        icon: "info",
        dangerMode: true,
        buttons: {
            cancel: {
                text: closeText,
                closeModal: true,
                visible: true
            },
            confirm: {
                text: confirmText,
                closeModal: true,
                visible: true
            }
        }
         }).then(
    function (isConfirm) {
        if (isConfirm) {

            var form = document.createElement("form");
            form.setAttribute("method", "post");
            var url = "DownloadDeleteObjectErrorsFile.aspx";
            if (isScanFlow === true) {
                url += "?isScansFlow=true";
            }
            form.setAttribute("action", url);
            form.setAttribute("target", "_self");

            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", "Errors");
            hiddenField.setAttribute("value", JSON.stringify(errorsList));
            form.appendChild(hiddenField);

            var sessionField = document.createElement("input");
            sessionField.setAttribute("type", "hidden");
            sessionField.setAttribute("name", "SecurityIdentityToken");
            sessionField.setAttribute("value", $('#SecurityIdentityToken').val());
            form.appendChild(sessionField);
               
            document.body.appendChild(form);

            form.submit();
        }
        $(document).trigger('sweetalert-modal-closed');
    });
}