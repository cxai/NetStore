var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        // Directive controller implementation
        var HeatMapWidgetDirective = (function (_super) {
            __extends(HeatMapWidgetDirective, _super);
            // Constructor (including dependencies that will be inserted automatically by angular)
            function HeatMapWidgetDirective(scope, netService) {
                // Call the server to get the widget data
                _super.call(this, netService, scope);
            }
            // Specify the dependencies for this directive    
            HeatMapWidgetDirective.$inject = ['$scope', '#net'];
            return HeatMapWidgetDirective;
        }(Directives.BaseWidget));
        // Directive configuration
        function HeatMapWidgetDirectiveSettings() {
            return {
                restrict: 'E',
                replace: true,
                controller: HeatMapWidgetDirective,
                controllerAs: 'root',
                templateUrl: '/CxWebClient/pages/dashboard/HeatMapWidget',
                bindToController: true,
                scope: {
                    config: '='
                },
                link: function ($scope, $elem, $attr) {
                    $elem.children(".perfect-scroll").on("mouseover", function () {
                        var $this = $(this);
                        $this.perfectScrollbar("update");
                        $this.off("mouseover");
                    });
                    var elapsed = 0;
                    var scrollNowIntoView = function () {
                        var valueCells = angular.element('.perfect-scroll .value-cell');
                        if (valueCells.length > 0 || elapsed > 1000) {
                            var elementsToScroll = valueCells.filter('.selected');
                            elementsToScroll.each(function () { this.scrollIntoView(); });
                        }
                        else {
                            elapsed += 100;
                            setTimeout(scrollNowIntoView, 100);
                        }
                    };
                    scrollNowIntoView();
                }
            };
        }
        Directives.HeatMapWidgetDirectiveSettings = HeatMapWidgetDirectiveSettings;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=heat-map-widget.js.map