﻿(function () {

    checkmarx.Queries.factory('Queries.CustomDescriptionAuthorizationService',
        ['siteGlobalVariablesProvider', function (globalVariables) {

        function isAuthorize() {

            return globalVariables.isAdmin() || globalVariables.isAuditor();
        }

        return {
            isAuthorize: isAuthorize
        };

    }]);

})();