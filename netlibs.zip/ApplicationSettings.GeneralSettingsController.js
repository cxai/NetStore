﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ApplicationSettings.controller('ApplicationSettings.GeneralSettingsController', [
        '$rootScope',
        '$scope',
        '$translate',
        'generalSettingsValues',
        'Common.EncryptionTypes',
        'ApplicationSettings.GeneralSettingsDataIntegrationService',
        'ApplicationSettings.GeneralSettingsDataService',
        'restLicenseService',
        'CxPortal.NotificationService',
        'Common.InputValidator',
        'CxPortal.LanguagesDataService',
        '$q',
        function ($rootScope, $scope, $translate, generalSettingsValues, encryptionTypes, generalSettingsDataIntegrationService,
            generalSettingsDataService, restLicenseService, notificationService, inputValidator, languagesDataService, $q) {

            var maxConcurrentScansMaxValue = 1;
            $scope.maxConcurrentScansMaxValue = 1;

            $scope.longPathSupportDialogName = "longPathSupportDialog";
            $scope.checkmarxKnowledgeCenterURL = generalSettingsValues.checkmarxKnowledgeCenterURL;

            $scope.dialogSetup = {
                modal: true,
                width: 391,
                resizable: false,
                show: {
                    effect: "fade", duration: 300
                },
                hide: {
                    effect: "fade", duration: 200
                }
            };

            $scope.longPathSupportClickHandler = function (isEditMode,isChecked) {
                if (isEditMode && isChecked) {
                    $rootScope.$broadcast('dialog-open-' + $scope.longPathSupportDialogName);
                }
            }

            $scope.continueAndCloseDialog = function () {
                $rootScope.$broadcast('dialog-close-' + $scope.longPathSupportDialogName);
            }

            $scope.switchToEditMode = function () {
                $scope.isEditMode = true;
            };

            $scope.updateSettings = function (generalSettingsForm) {

                var configData = generalSettingsDataIntegrationService.setConfigurationData($scope.configurationData);
                var defaultLanguageId = $scope.configurationData.serverSettings.defaultServerLanguage.lcid;

                $q.all([generalSettingsDataService.put(configData), languagesDataService.putDefaultLanguage(defaultLanguageId)])
                    .then(function () {
                        $scope.isEditMode = false;
                        notificationService.success($translate.instant("SAVED_SUCCESSFULLY"));
                        load();
                    });
            };

            $scope.cancelEditMode = function () {
                $scope.isEditMode = false;
                load();
            };

            $scope.getCurrentWebServerAdress = function () {
                var url = location.href.toLowerCase();
                $scope.configurationData.serverSettings.webServerAddress = url.substr(0, url.indexOf("/cxwebclient"));
            };

            $scope.changePort = function () {
                switch ($scope.configurationData.smtpSettings.encryptionType) {
                    case $translate.instant("TLS"): $scope.configurationData.smtpSettings.port = 587;
                        break;
                    case $translate.instant("SSL"): $scope.configurationData.smtpSettings.port = 465;
                        break;
                    case $translate.instant("None"):
                    default: $scope.configurationData.smtpSettings.port = 25;
                        break;
                }
            };

            $scope.isOsaEnabled = false;

            var load = function () {
                $q.all([generalSettingsDataService.get(), languagesDataService.get()]).then(function (data) {
                    $scope.availableLanguages = data[1];
                    $scope.configurationData = generalSettingsDataIntegrationService.getConfigurationData(data[0],
                                                                                                          $scope.availableLanguages,
                                                                                                          maxConcurrentScansMaxValue);
                });
            };

            var setMaxConcurrentScansMaxValue = function (maxResultFromLicense) {
                $scope.maxConcurrentScansMaxValue = maxResultFromLicense;
            }

            var initializeData = function () {

                $scope.isEditMode = false;
                $scope.encryptionTypes = encryptionTypes;
                $scope.configurationData = {
                    smtpSettings: {},
                    serverSettings: {},
                    osaSettings: {}
                };

                restLicenseService.getLicenseDetails().then(function (result) {
                    maxConcurrentScansMaxValue = result.data.maxConcurrentScans;
                    $scope.isOsaEnabled = result.data.osaEnabled;
                    setMaxConcurrentScansMaxValue(maxConcurrentScansMaxValue);
                });
            };

            new ResizeSensor(document.getElementById('general-main-container'), function () {

                $rootScope.$broadcast('elementLoaded', 'general-main-container');
            });

            initializeData();
            load();

        }]);
})();