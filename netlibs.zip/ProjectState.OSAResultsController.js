﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.controller('ProjectState.OSAResultsController',
    ['$scope',
        '$stateParams',
        '$translate',
        'osaReportDataService',
        'osaSummaryResultsDataService',
        'Common.Timer',
        'ProjectState.OriginType',
        function ($scope,
                $stateParams,
                $translate,
                osaReportDataService,
                osaSummaryResultsDataService,
                timer,
                originType) {

            var projectId = $stateParams.id;
            $scope.showLoading = true;
            $scope.showOSAHTMLReport = false;
            var osaSummaryResultsTimer = new timer(10000);

            function getOSAHTMLData() {

                osaReportDataService.getOSAHTMLData(projectId).then(function (result) {
                    getOSAReportDetailsSuccess(result);
                });
            }

            function getOSAReportDetailsSuccess(result) {

                $scope.showLoading = false;
                $scope.osaReportData = result;
                $scope.showOSAHTMLReport = true;
            }

            
            function checkForNewScan() {
                osaSummaryResultsDataService.getOSASummaryData(projectId).then(function (response) {
                    if ($scope.analyzeDateTime != response.startAnalyzeTime) {
                        $scope.isNewVersionAvailable = true;
                    }
                });
            }

            function getResultTitle(origin) {

                if (origin.toLowerCase() == originType.shared) {
                    return $translate.instant('ANALYZED_FROM_SHARED_LOCATION');
                }
                else if (origin.toLowerCase() == originType.portal) {
                    return $translate.instant('ANALYZED_FROM_PORTAL');
                }
            }

            $scope.$on('$destroy', function () {
                osaSummaryResultsTimer.stop();
            });

            $scope.$watchCollection('osaSummaryResults', function (osaSummaryResults) {

                if (osaSummaryResults != undefined) {

                    $scope.analyzeSource = getResultTitle($scope.osaSummaryResults.origin);
                    $scope.analyzeDateTime = $scope.osaSummaryResults.startAnalyzeTime;
                }
            });

            getOSAHTMLData();
            osaSummaryResultsTimer.start(checkForNewScan);
        }
    ]);
}());
