﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxPortal.factory('CxPortal.BuildNumberService', ['siteGlobalVariablesProvider', 'Common.QueryString',
        function (siteGlobalVariablesProvider, queryStringService) {
            
            function addVersionNumberToUrl(url) {

                var version = siteGlobalVariablesProvider.getBuildVersionNumber();
                return encodeURI(queryStringService.addQueryStringParameter(url, 'v', version));
            }

            return {
                addVersionNumberToUrl: addVersionNumberToUrl
            };

        }]);

})();