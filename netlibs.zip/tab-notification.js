//For now it not in use
var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        var C = Checkmarx.Constants;
        // Directive controller implementation
        var TabNotificationDirective = (function () {
            // Constructor (including dependencies that will be inserted automatically by angular)
            function TabNotificationDirective(scope, element) {
                var _this = this;
                this.scope = scope;
                this.element = element;
                var tabNumber = this.element.attr('tab-notification');
                var tabScope = this.scope.$parent.tabs[tabNumber];
                tabScope.$watch(function () { return tabScope.active; }, function (nv, ov) {
                    _this.scope.$broadcast(C.Events.ToggleContainerEvent, nv);
                });
            }
            // Specify the dependencies for this directive    
            TabNotificationDirective.$inject = ['$scope', '$element'];
            return TabNotificationDirective;
        }());
        // Directive configuration
        function TabNotificationDirectiveSettings() {
            return {
                restrict: 'A',
                replace: true,
                controller: TabNotificationDirective,
                controllerAs: 'root',
                bindToController: true,
            };
        }
        Directives.TabNotificationDirectiveSettings = TabNotificationDirectiveSettings;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=tab-notification.js.map