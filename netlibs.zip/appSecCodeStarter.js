﻿var AppSecCodeStarter = {};

(function (AppSecCodeStarter) {
    "use strict";

    AppSecCodeStarter.openLink = function (queryId) {

        var deferred = $.Deferred();
        var divAppSecCoachTabs = document.getElementById('divAppSecCoachTabs');

        var checkSelector = setInterval(function () {

            if (isDOMReadyForRunningAngularApp(divAppSecCoachTabs)) {
                deferred.resolve();
                clearInterval(checkSelector);
            }

        }, 200);

        deferred.done(function () {
            angular.element(divAppSecCoachTabs).scope().openAppSecCoachLesson(queryId);
        });        
    };

    AppSecCodeStarter.getQueryIdFromSender = function (sender) {

        var deferred = $.Deferred();
        var divAppSecCoachTabs = document.getElementById('divAppSecCoachTabs');

        var checkSelector = setInterval(function () {

            if (isDOMReadyForRunningAngularApp(divAppSecCoachTabs)) {
                deferred.resolve();
                clearInterval(checkSelector);
            }

        }, 200);

        deferred.done(function () {

            if (sender.get_masterTableView() && sender.get_masterTableView().get_selectedItems()[0]) {

                var queryId = sender.get_masterTableView().get_selectedItems()[0].getDataKeyValue("QueryID");
                angular.element(divAppSecCoachTabs).scope().openAppSecCoachLesson(queryId);
            }
            else {
                angular.element(divAppSecCoachTabs).scope().openAppSecCoachLesson(null);
            }
        });
    };

    function isDOMReadyForRunningAngularApp(divAppSecCoachTabs) {

        return angular
                && angular.element(divAppSecCoachTabs)
                    && angular.element(divAppSecCoachTabs).scope();
    }

})(AppSecCodeStarter || (AppSecCodeStarter = {}));