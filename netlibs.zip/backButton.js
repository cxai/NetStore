﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxPortal.directive('backButton', [function () {

        return {
            template: '<span class="{{cssClass}}" ng-click="backButtonClicked()"> < {{ "BACK" | translate}} </span>',
            scope: {
                cssClass: '@'
            },
            controller: ['$scope', '$rootScope', '$state', '$window', function ($scope, $rootScope, $state, $window) {
                
                    $scope.backButtonClicked = function () {
                    if ($rootScope.CxReferrer) {
                        $state.go($rootScope.CxReferrer);
                    }
                    else if (document.referrer || document.referrer != "") {
                        window.location.href = document.referrer;
                    }
                    else {
                        $window.history.back();
                    }
                };
            }]
        };
    }]);
})();