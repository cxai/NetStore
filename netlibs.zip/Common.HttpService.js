﻿(function () {
    "use strict";

    checkmarx.Common.factory('Common.HttpService', [function () {

        function postByIframeTargetedForm(url, data) {

            var iframe = document.createElement("iframe");
            document.body.appendChild(iframe);
            iframe.style.display = "none";

            //Give the frame a name
            var frame_name = "frame_name" + (new Date).getTime();
            iframe.contentWindow.name = frame_name;
            //build the form
            var form = document.createElement("form");
            form.target = frame_name;
            form.action = url;
            form.method = "POST";
            addParametersToForm(form, data);
            document.body.appendChild(form);
            form.submit();
        }

        function postByBlankTargetedForm(url, data) {
            //build the form
            var form = document.createElement("form");
            form.target = "_blank";
            form.action = url;
            form.method = "POST";
            addParametersToForm(form, data);
            document.body.appendChild(form);
            form.submit();
        }

        function addParametersToForm(form, parameters) {
            //loop through all parameters
            if (parameters) {
                for (var key in parameters) {
                    if (parameters.hasOwnProperty(key)) {
                        var input = document.createElement("input");
                        input.type = "hidden";
                        input.name = key;
                        input.value = parameters[key];
                        form.appendChild(input);
                    }
                }
            }
        }

        return {
            postByIframeTargetedForm: postByIframeTargetedForm,
            postByBlankTargetedForm: postByBlankTargetedForm
        };
    }]);
})();