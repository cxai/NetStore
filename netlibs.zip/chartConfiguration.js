﻿(function () {
    "use strict";

    checkmarx.ProjectState.value('chartColumnDataNames', {
        New: 'NEW',
        Recurrent: 'RECURRENT',
        Solved: 'SOLVED',
        PrevScan: 'PREVIOUS'
    });

})();