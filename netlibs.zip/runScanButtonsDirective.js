﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.directive('runScanButtonsDirective', function () {

        return {
            template: '<button class="btn btn-default btn-default-project run-scans" ng-click="runFullScan()" ng-disabled="isRunFullScanButtonDisabled">'
                        + '<img src="app/projectState/style/images/buttonIcons/fullScan.png"/>'
                        + '{{ "FULL_SCAN" | translate}}'
                     + '</button>'
                    + '<button class="btn btn-default btn-default-project run-scans" ng-click="runIncrementalScan()" ng-disabled="isRunIncrementalScanButtonDisabled">'
                        + '<img src="app/projectState/style/images/buttonIcons/incrementalScan.png"/>'
                        + '{{ "INCREMENTAL_SCAN" | translate}}'
                    + '</button>',
            controller: ['$rootScope', '$scope', 'scanTypes', 'siteGlobalVariablesProvider',
                function ($rootScope, $scope, scanTypes, siteGlobalVariablesProvider) {

                $rootScope.isRunFullScanButtonDisabled = $rootScope.isRunIncrementalScanButtonDisabled = !siteGlobalVariablesProvider.basicVariables().isScanner;

                $scope.runFullScan = function () {

                    $rootScope.isRunFullScanButtonDisabled = true;
                    $rootScope.$broadcast('RunScanClicked', scanTypes.full);
                };

                $scope.runIncrementalScan = function () {

                    $rootScope.isRunIncrementalScanButtonDisabled = true;
                    $rootScope.$broadcast('RunScanClicked', scanTypes.incremental);
                };
            }]
        };

    });

})();