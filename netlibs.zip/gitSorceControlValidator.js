﻿var gitSorceControlValidator = {};

(function () {
    "use strict";

    gitSorceControlValidator.validate = function (data) {

        if (data === undefined || data.url === undefined || data.selectedMethod === undefined) {
            return false;
        }

        switch (data.selectedMethod.Id) {

            case gitAuthenticationMethodTypesEnum.NONE:
                return true;

            case gitAuthenticationMethodTypesEnum.CREDENTIALS:
                return validateCredentials(data.selectedMethod.fields);

            case gitAuthenticationMethodTypesEnum.TOKEN:
                return validateToken(data.selectedMethod.fields);

            case gitAuthenticationMethodTypesEnum.SSH:
                return validateSSH(data.selectedMethod.selectedField, data.selectedMethod.fields);
            default:
                return false;
        }
    };

    function validateCredentials(credentials) {
        if (credentials && credentials.userName && credentials.password) {
            return credentials.userName === true && credentials.password === true;
        }
        return false;
    }

    function validateToken(tokenFields) {
        if (tokenFields && tokenFields.token) {
            return tokenFields.token === true;
        }
        return false;
    }

    function validateSSH(sshSelectedField, sshFields) {
        if (!sshSelectedField || !sshFields) {
            return false;
        }

        return validateSSHFields(sshSelectedField,sshFields);
    }

    function validateSSHFields(sshSelectedField,sshFields) {
        if (sshSelectedField.sshText) {
            return sshFields.sshText!=="" ?  true : false;

        } else if (sshSelectedField.sshFile) {
            return sshFields.sshFile !== "" ? true : false;
        }

        return false;
    }

})();