﻿(function () {
    "use strict";

    checkmarx.CxAcademy.factory('AppSecCoach.SettingsDataService', ['CxPortal.AjaxServiceWithNotification', 'apiBaseURLService',
        function (ajaxServiceWithNotification, apiBaseURLService) {

            var url = apiBaseURLService.getAPIVirtualDirectory() + '/configurations/appseccoach';

            function getAppSecCoachSetting() {

                return ajaxServiceWithNotification.get(url);
            }

            function putAppSecCoachSetting(appSecCoachSetting) {

                return ajaxServiceWithNotification.put(url, appSecCoachSetting);
            }

            return {
                getAppSecCoachSetting: getAppSecCoachSetting,
                putAppSecCoachSetting: putAppSecCoachSetting
            };
        }]);
})();