﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('projectLastScanDataService', ['ajaxService', 'apiBaseURLService',
        function (ajaxService, apiBaseURLService) {
            /* data service for loading the last scan. */

            function getLastScan(scanId) {

                var url = apiBaseURLService.getAPIBaseURL() + '/finishedScans/' + scanId + '/results?expand=SummarizeBySeverityAndState';

                return ajaxService.get(url);
            }

            return {
                getLastScan: getLastScan
            };

        }]);

})();