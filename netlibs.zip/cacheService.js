﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.Common.factory('cacheService', ['$cacheFactory', function ($cacheFactory) {

        var cxAppMainCacheKey = '_cxAppMainCache_';
        var cxAppMainCache = {};

        function getAppMainCacheCacheObject() {

            cxAppMainCache = $cacheFactory(cxAppMainCacheKey);
        }

        function put(key, value) {
            /*  inserts a named entry into the Cache object to be retrieved later, 
                and incrementing the size of the cache if the key was not already present in the cache. If behaving like an LRU cache,
                it will also remove stale entries from the set.
                returns the value stored.
            */

            return cxAppMainCache.put(key, value);
        }

        function get(key) {
            /* retrieves named data stored in the Cache object. */

            return cxAppMainCache.get(key);
        }

        function remove(key) {
            /* removes an entry from the Cache object. */

            cxAppMainCache.remove(key);
        }

        function removeAll() {
            /* clears the cache object of any entries. */

            cxAppMainCache.removeAll();
        }

        function destroy() {
            /* destroys the Cache object entirely, removing it from the $cacheFactory set. */

            cxAppMainCache.destroy();
        }

        function info() {
            /* retrieve information regarding a particular Cache. */

            cxAppMainCache.info();
        }

        getAppMainCacheCacheObject();

        return {
            getAppMainCacheCacheObject: getAppMainCacheCacheObject,
            get: get,
            put: put,
            remove: remove,
            removeAll: removeAll,
            destroy: destroy,
            info: info
        };
    }]);

})();