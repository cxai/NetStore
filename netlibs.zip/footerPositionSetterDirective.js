﻿
(function () {
    "use strict";

    checkmarx.CxPortal.component('footerPositionSetter', {
        bindings: {},
        template: '',
        controller: ['$timeout', '$rootScope', function ($timeout, $rootScope) {

            function setFooterPosition(elementID) {

                $timeout(function () {
                    var elementIDString = "#" + elementID;
                    var position = $(elementIDString).position();

                    if (position) {
                        var footerTop = position.top + $(elementIDString).height() + 10;
                        $(".cx-footer").css({ top: footerTop, position: 'absolute', left: '45%' });
                    }
                });
            }

            function resetCxFooter() {
                $(".cx-footer").css({ top: 'auto', position: 'initial', left: 'auto' });
            }

            $rootScope.$on('elementLoaded', function (event, resizedElementId) {
                setFooterPosition(resizedElementId);
            });

            $rootScope.$on('elementDistroyed', function () {
                resetCxFooter();
            });
        }]
    });
})();