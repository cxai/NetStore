﻿(function () {
    "use strict";

    checkmarx.ProjectState.directive('osaDownloadIndicator', function () {

        return {
            template: '<div class="osa-loader-container">'
                        + '<span class="spinner16"></span>'
                        + '<span class="spinnerText">{{text}}</span>'
                    + '</div>',
            scope: {
                text: '='
            }
        };

    });

})();