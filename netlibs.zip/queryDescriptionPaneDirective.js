﻿/// <reference path="app.js" />

(function () {
    "use strict";

    checkmarx.Queries.directive('queryDescriptionPane', [
        'queryDescriptionCalculator',
        '$translate',
        '$rootScope',
        function (queryDescriptionCalculator, $translate, $rootScope) {

        return {
            template: '<div ng-if="showEmptyDescription" class="empty-description-container">{{message}}</div>'
                    + '<loading-spinner ng-show="showLoader"></loading-spinner>'
                    + '<iframe id="ifQueryDescription" ng-show="!empty" frameborder="0" class="{{cssClass}}" '
                        + 'sandbox="allow-same-origin allow-popups"></iframe>',
            scope: {
                cssClass: '@'
            },
            link: function (scope) {

                function printEmptyDescription() {
                    scope.showEmptyDescription = true;
                    scope.shouldShowTabs = false;
                    scope.message = $translate.instant('DESCRIPTION_DOES_NOT_EXIST');
                    setIFrameContent("");
                    scope.showLoader = false;
                }

                function getIFrame() {

                    return document.getElementById("ifQueryDescription");
                }

                function setIFrameContent(content) {
                    var iframe = getIFrame();
                    var iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                    //  document.frames["ifQueryDescription"] to support IE 
                    var iframeDocElement = iframeDoc.documentElement === null ? document.frames["ifQueryDescription"] : iframeDoc.documentElement;
                    if (content) {
                        scope.showLoader = false;
                        iframeDocElement.innerHTML = content;
                        $rootScope.$broadcast('iframe-content-loaded', '#ifQueryDescription');
                    }
                    else {
                        iframeDocElement.innerHTML = "";
                    }
                }

                function setTopAnchor(html) {

                    if (html) {
                        return html.replace(/href="#top"/i, 'href="javascript:parent.$(self).scrollTop(0);void(0)"');
                    }
                    
                    return html;
                }

                scope.$on('queryDescriptionReset', function (event, args) {
                    scope.showEmptyDescription = false;
                    setIFrameContent("");
                    scope.showLoader = true;
                });

                scope.$on('queryDescriptionError', function (event, error) {
                    scope.showEmptyDescription = true;
                    scope.message = error;
                    setIFrameContent("");
                });

                scope.$on('query-description-HTML-loaded', function (event, args) {
                    
                    scope.showEmptyDescription = false;
                    var html = args.html ? args.html : printEmptyDescription();
                    html = setTopAnchor(html);
                    setIFrameContent(html);
                    scope.shouldShowTabs = true;
                });
            }

        };

    }]);

})();