﻿/// <reference path="../values/AppSecCoach.GeneralValues.js" />

(function () {
    "use strict";

    checkmarx.CxAcademy.controller('AppSecCoach.OpenLessonMainController',
        [
            '$rootScope',
            '$scope',
            'AppSecCode.LinkBuilder',
            'restLicenseService',
            'AppSecCoatch.AcademLessonMatcher',
            'AppSecCoach.LinkType',
            '$q',
            'AppSecCoach.DialogIDs',
            'Queries.QueryDescriptionsDataService',
            'AppSecCoach.AcademyLessonsRepositoryFactory',
            function ($rootScope, $scope, linkBuilder, restLicenseService, academLessonMatcher, linkType, $q, appSecCoachDialogIDs, queryDescriptionsDataService, academyLessonsRepositoryFactory) {

                var _organizationName = null;
                
                $scope.openAppSecCoachLesson = function (queryId) {

                    if (_organizationName == null) {
                        loadOrganiztionName().then(function () {
                            runProcess(queryId)
                        });
                    }
                    else {
                        runProcess(queryId);
                    }
                };

                function runProcess(queryId) {

                    var linkData = {
                        linkType: linkType.none,
                        link: linkBuilder.build('', '', _organizationName)
                    };

                    if (queryId) {
                        
                        $rootScope.$broadcast('dialog-close-' + appSecCoachDialogIDs.appSecCoachLicenseDialog);
                        $rootScope.$broadcast('dialog-close-' + appSecCoachDialogIDs.appSecCoachLessonIsNotAvailableDialog);

                        queryDescriptionsDataService.getQueryDescriptions(queryId).then(function (data) {

                            queryId = data.data.rootQueryId;
                            academyLessonsRepositoryFactory.getAcademyLessonsRepository().then(function (repository) {

                                repository.getAcademyLessons().then(function (lessons) {
                                    
                                    var matchResult = academLessonMatcher.match(queryId, lessons);

                                    if (matchResult) {
                                        linkData.linkType = linkType.linkToLesson;
                                        linkData.queryId = queryId;
                                    }

                                    $scope.$evalAsync(function () {
                                        $scope.linkData = linkData;
                                    });
                                });
                            });                            
                        });                        
                    }
                    else {

                        linkData.link = linkBuilder.build('', '', _organizationName);
                        linkData.linkType = linkType.generalLink;
                        
                        $scope.$evalAsync(function () {
                            $scope.linkData = linkData;
                        });
                    }
                }

                function loadOrganiztionName() {

                    var deferred = $q.defer();

                    restLicenseService.getLicenseDetails().then(function (ajaxResult) {

                        var licenseDetails = ajaxResult.data;
                        _organizationName = licenseDetails.organizationName;
                        deferred.resolve(licenseDetails.organizationName);
                    });

                    return deferred.promise;
                }

            }]);
})();