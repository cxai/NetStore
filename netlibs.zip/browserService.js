﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.Common.factory('browserService', [function () {
        /* This service responsible for handling all browser's related info, such as whether it's an IE browser, or more specific, such a version of a browser */

        function getUserAgentNavigator(userAgentName) {
            return navigator.userAgent.toLowerCase().indexOf(userAgentName) > -1;
        };

        function getInternetExplorerVersionAsFloat() {

            var ieVersion, userAgent, regExp;
            ieVersion = -1;

            if (navigator.appName == 'Microsoft Internet Explorer') {

                userAgent = navigator.userAgent;
                regExp = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");

                if (regExp.exec(userAgent) != null) {
                    ieVersion = parseFloat(RegExp.$1);
                }
            }
            else if (navigator.appName == 'Netscape') {

                userAgent = navigator.userAgent;
                regExp = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");

                if (regExp.exec(userAgent) != null) {
                    ieVersion = parseFloat(RegExp.$1);
                }
            }

            return ieVersion;
        };

        function isChrome() {
            return getUserAgentNavigator('chrome');
        }

        function isFireFox() {
            return getUserAgentNavigator('firefox');
        }

        function isIE() {
            return getUserAgentNavigator('msie') || getUserAgentNavigator('msie');
        };

        function isIE8() {

            if (getInternetExplorerVersionAsFloat() == 8.0) {

                return true;
            }

            return false;
        };

        function isIE9() {

            if (getInternetExplorerVersionAsFloat() == 9.0) {

                return true;
            }

            return false;
        };

        function isIE10() {

            if (getInternetExplorerVersionAsFloat() == 10.0) {

                return true;
            }

            return false;
        };

        function isIE11() {

            var version = getInternetExplorerVersionAsFloat();

            if (version >= 11.0 && version < 12.0) {

                return true;
            }

            return false;
        };

        return {
            isChrome: isChrome,
            isFireFox: isFireFox,
            isIE: isIE,
            isIE8: isIE8,
            isIE9: isIE9,
            isIE10: isIE10
        };
    }]);

})();