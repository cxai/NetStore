﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.directive('scanProgressNotificationText', [function () {

        return {
            template: '<div>'
                        + '<span>{{scanStatusText | translate}}</span>'
                        + '<a ng-href="/CxWebClient/UserQueue.aspx">{{"SCAN_QUEUE_DETAILS" | translate}} ></a>'
                    + '</div>',
            replace: true,
            scope: {
                scanStatusText: '@'
            }
        };

    }]);

})();