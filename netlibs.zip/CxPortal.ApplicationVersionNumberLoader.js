﻿(function () {
	"use strict";

	checkmarx.CxPortal.factory('CxPortal.ApplicationVersionNumberLoader', ['siteGlobalVariablesProvider', 'CxPortal.ApplicationVersionParser',
		function (siteGlobalVariablesProvider, applicationVersionParser) {

		function load() {
			
			return applicationVersionParser.parse(siteGlobalVariablesProvider.getAppVersionNumber());
		}

		return {
			load: load
		};

	}]);

})();