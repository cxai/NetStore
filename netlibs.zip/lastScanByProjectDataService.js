﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('lastScanByProjectDataService', ['ajaxService', 'apiBaseURLService',
        function (ajaxService, apiBaseURLService) {
            /* loader for last scan data, by project id.
             * NOTE: return promise.
            */

            function getLastScanByProjectId(projectId) {

                var url = apiBaseURLService.getAPIBaseURL() + '/projects/' + projectId + '/finishedScans/Latest';

                return ajaxService.get(url);
            }

            return {
                getLastScanByProjectId: getLastScanByProjectId
            };

        }]);

})();