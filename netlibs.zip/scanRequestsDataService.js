﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('publicScanRequestsDataService', ['ajaxService', 'apiBaseURLService', '$q', function (ajaxService, apiBaseURLService, $q) {
        /* get the scan requests that are in the scan queue. */

        function filterPublicScanRequests(data) {
            var publicScanRequests = [];
            for (var i = 0; i < data.length; i++) {
                if (data[i].isPublic) {
                    publicScanRequests.push(data[i]);
                }
            }
            return publicScanRequests;
        };

        function getScanRequests(projectId) {
            var deferred = $q.defer();
            var url = apiBaseURLService.getAPIBaseURL() + '/sast/scansQueue?projectId=' + projectId;

            ajaxService.get(url).then(function (response) {
                response.data = filterPublicScanRequests(response.data);
                deferred.resolve(response);
            }).catch(function (result) {
                deferred.reject(result);                
            });
            
            return deferred.promise;
        }

        return {
            getScanRequests: getScanRequests
        };

    }]);

})();