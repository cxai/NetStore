﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('osaSummaryResultsDataService', [
        'ProjectState.OSAScansDataService',
        'ajaxService',
        'osaAjaxService',
        'apiBaseURLService',
        '$q',
        'ProjectState.OSALastFinishedScan',
        function (osaScansDataService, ajaxService, osaAjaxService, apiBaseURLService, $q, osaLastFinishedScan) {

            function getOnLoading(projectId) {

                return get(ajaxService, projectId);
            }

            function getOSASummaryData(projectId) {

                return get(osaAjaxService, projectId);
            }

            function get(ajaxObject, projectId) {

                return osaScansDataService.get(projectId).then(function (scans) {

                    var scan = osaLastFinishedScan.get(scans);

                    return ajaxObject.get(apiBaseURLService.getAPIVirtualDirectory() + '/osa/reports?scanId=' + scan.id + '&reportFormat=json').then(function (summaryResults) {
                        
                        if (summaryResults) {

                            var result = summaryResults.data || summaryResults;
                            result.startAnalyzeTime = scan.startAnalyzeTime;
                            result.origin = scan.origin;

                            return result;
                        }
                    });
                });
            }

            return {
                getOSASummaryDataOnLoading: getOnLoading,
                getOSASummaryData: getOSASummaryData
            };

        }]);

})();