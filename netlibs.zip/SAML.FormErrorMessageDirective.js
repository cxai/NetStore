﻿/// <reference path="../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.SAML.directive('formErrorMessage', [function () {

        return {
            template: '<div class="error-container" ng-show="form.$submitted || formElement.$touched">'
                        + '<div ng-show="elementError">{{errorMessage}}</div>'
                    + '</div>',
            scope: {
                form: '=',
                formElement: '=',
                elementError: '=',
                errorMessage: '@'
            }
        };

    }]);

})();