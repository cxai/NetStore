var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        var BaseController = (function () {
            function BaseController() {
            }
            // for angular 2.0, call to watch in one place
            BaseController.prototype.registerWatch = function (context, watchOnFuntion, onValueChanged, deepWatch) {
                deepWatch = deepWatch || false;
                var unregister = context.$watch(watchOnFuntion, function (nv, ov) {
                    if (!!nv) {
                        onValueChanged(nv, ov);
                    }
                }, deepWatch);
                return unregister;
            };
            return BaseController;
        }());
        Directives.BaseController = BaseController;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=base-controller.js.map