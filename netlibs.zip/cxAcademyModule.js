﻿/// <reference path="../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxAcademy = angular.module('CxAcademy', []);
    
    checkmarx.CxAcademy.value({
        "key": "relativePath"
    });
})();
