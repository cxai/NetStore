var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        // Directive controller implementation
        var CxMenuDirective = (function (_super) {
            __extends(CxMenuDirective, _super);
            // Constructor (including dependencies that will be inserted automatically by angular)
            function CxMenuDirective(scope, netService, window, $state, $rootScope) {
                _super.call(this);
                this.scope = scope;
                this.netService = netService;
                this.window = window;
                this.$state = $state;
                this.$rootScope = $rootScope;
                // init all menus
                $('ul.navbar-nav').each(function () {
                    var $this = $(this);
                    $this.addClass('sm').smartmenus({
                        // these are some good default options that should work for all
                        // you can, of course, tweak these as you like
                        subMenusSubOffsetX: 2,
                        hideTimeout: 0,
                        showTimeout: 0,
                        subMenusSubOffsetY: -6,
                        subIndicatorsPos: 'append',
                        collapsibleShowFunction: null,
                        collapsibleHideFunction: null,
                        rightToLeftSubMenus: $this.hasClass('navbar-right'),
                        bottomToTopSubMenus: $this.closest('.navbar').hasClass('navbar-fixed-bottom')
                    })
                        .find('a.current').parent().addClass('active');
                }).bind({
                    // set/unset proper Bootstrap classes for some menu elements
                    'show.smapi': function (e, menu) {
                        var $menu = $(menu), $scrollArrows = $menu.dataSM('scroll-arrows'), obj = $(this).data('smartmenus');
                        if ($scrollArrows) {
                            // they inherit border-color from body, so we can use its background-color too
                            $scrollArrows.css('background-color', $(document.body).css('background-color'));
                        }
                        $menu.parent().addClass('open' + (obj.isCollapsible() ? ' collapsible' : ''));
                    },
                    'hide.smapi': function (e, menu) {
                        $(menu).parent().removeClass('open collapsible');
                    },
                    // click the parent item to toggle the sub menus (and reset deeper levels and other branches on click)
                    'click.smapi': function (e, item) {
                        var obj = $(this).data('smartmenus');
                        if (obj.isCollapsible()) {
                            var $item = $(item), $sub = $item.parent().dataSM('sub');
                            if ($sub && $sub.dataSM('shown-before') && $sub.is(':visible')) {
                                obj.itemActivate($item);
                                obj.menuHide($sub);
                                return false;
                            }
                        }
                    }
                });
            }
            // Specify the dependencies for this directive
            CxMenuDirective.$inject = ['$scope', '#net', '$window', '$state', '$rootScope'];
            return CxMenuDirective;
        }(Directives.BaseController));
        // Directive configuration
        function CxMenuSettings() {
            return {
                restrict: 'E',
                replace: true,
                controller: CxMenuDirective,
                controllerAs: 'root',
                templateUrl: '/CxWebClient/pages/common/CxMenu',
                bindToController: true,
                scope: {
                    config: '='
                }
            };
        }
        Directives.CxMenuSettings = CxMenuSettings;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=cx-menu.js.map