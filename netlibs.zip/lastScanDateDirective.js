﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.directive('lastScanDate', [
        function () {
            return {
                template: '<span class="last-scan-date">{{publicScanText}} <span ng-show="!isScanExists">{{scanDate}}</span><span ng-show="isScanExists">{{scanDate | dateByLocaleFilter}} {{scanDate | timeByLocaleFilter}})</span></span>',
                controller: ['$state', '$scope', '$stateParams', '$translate',
                    function ($state, $scope, $stateParams, $translate) {
                    
                        var projectId = $stateParams.id;
                        var lastScanData = $state.current.statePreloadedData.finishedScansLatest;

                        if (lastScanData) {

                            $scope.publicScanText = "(" + $translate.instant("PUBLIC_SCAN");
                            $scope.scanDate = lastScanData.startedOn;
                            $scope.isScanExists = true;
                        }
                        else {
                            $scope.scanDate = "(" + $translate.instant("NO_SAST_SCANS_IS_PERFORMED") + ")";
                            $scope.isScanExists = false;
                        }
                }]
            };

        }]);

})();