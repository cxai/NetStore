var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        var C = Checkmarx.Constants;
        // Directive controller implementation
        var ProgressBarsWidgetDirective = (function (_super) {
            __extends(ProgressBarsWidgetDirective, _super);
            // Constructor (including dependencies that will be inserted automatically by angular)
            function ProgressBarsWidgetDirective(scope, netService, $timeout) {
                // Call the server to get the widget data
                _super.call(this, netService, scope);
                this.$timeout = $timeout;
            }
            ProgressBarsWidgetDirective.prototype.initializeData = function (data) {
                var _this = this;
                var tempData = angular.copy(data);
                //we need to initilize the progress to 0 to see the animation of the progress bar
                for (var i = 0; i < tempData.data.items.length; i++) {
                    tempData.data.items[i].progress = 0;
                }
                //fire the DataReceived event to the widget shell for: 1.remove the spinner 2. update the last update time
                this.scope.$emit(C.Events.DataReceived, { lastUpdated: data.data.updatedOn });
                this.widgetData = tempData;
                this.timeoutInstance = this.$timeout(function () {
                    _this.widgetData = data;
                });
                this.scope.$on("$destroy", function () {
                    if (_this.timeoutInstance) {
                        _this.$timeout.cancel(_this.timeoutInstance);
                        _this.timeoutInstance = undefined;
                    }
                });
            };
            // Specify the dependencies for this directive    
            ProgressBarsWidgetDirective.$inject = ['$scope', '#net', '$timeout'];
            return ProgressBarsWidgetDirective;
        }(Directives.BaseWidget));
        // Directive configuration
        function ProgressBarsWidgetDirectiveSettings() {
            return {
                restrict: 'E',
                replace: true,
                controller: ProgressBarsWidgetDirective,
                controllerAs: 'root',
                templateUrl: '/CxWebClient/pages/dashboard/ProgressBarsWidget',
                bindToController: true,
                scope: {
                    config: '='
                }
            };
        }
        Directives.ProgressBarsWidgetDirectiveSettings = ProgressBarsWidgetDirectiveSettings;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=progress-bars-widget.js.map