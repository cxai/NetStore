﻿var gitTestConnectionManager = {};

(function () {

    "use strict";

    var _isFormValid = false;
    var _gitPrivateKeyFileStream = null;
    var _authRadioButton = null;
    var _authenticationMethodToken = null;
    var _serverUrl = null;
    var _userName = null;
    var _userPassword = null;
    var _tokenTextbox = null;
    var _sshFileUploaderfileRadioButton = null;
    var _sshTextAuthTextbox = null;
    var _spnTestConnectionResult = null;
    var _btnTestConnection = null;
    var _imgTestConnectionSpinner = null;
    var _authenticationMethodSSH = null;
    var _btnOK = null;
    var _btnTestConnection = null;

    var _btnTestConnectionId = 'btnTestConnection';
    var _txtServerUrlId = 'txtServerUrl';
    var _sshFileUploaderfileId = 'SSHFileUploaderfile0';
    var _userNameAuthTextboxId = 'userNameAuthTextbox';
    var _passwordAuthTextboxId = 'passwordAuthTextbox';
    var _authenticationMethodNoneId = 'authenticationMethodNone';
    var _authenticationMethodCredentialsId = 'authenticationMethodCredentials';
    var _authenticationMethodTokenId = 'authenticationMethodToken';
    var _authenticationMethodSSHId = 'authenticationMethodSSH';
    var _tokenTextboxId = 'tokenTextbox';
    var _sshTextAuthTextboxId = 'sshTextAuthTextbox';
    var _sshRadioButtonList_0Id = 'sshRadioButtonList_0';
    var _sshRadioButtonList_1Id = 'sshRadioButtonList_1';

    var GIT_KEYWORD = 'GIT';

    function initUIElements() {

        _authRadioButton = $('#' + _authenticationMethodCredentialsId);
        _authenticationMethodToken = $('#' + _authenticationMethodTokenId);
        _serverUrl = $telerik.$("#" + _txtServerUrlId);
        _userName = $telerik.$("#" + _userNameAuthTextboxId);
        _userPassword = $telerik.$("#" + _passwordAuthTextboxId);
        _tokenTextbox = $telerik.$('#' + _tokenTextboxId);
        _sshFileUploaderfileRadioButton = $('#' + _sshFileUploaderfileId);
        _sshTextAuthTextbox = $('#' + _sshTextAuthTextboxId);
        _authenticationMethodSSH = $('#' + _authenticationMethodSSHId);
        _spnTestConnectionResult = $('#spnTestConnectionResult');
        _btnTestConnection = $find(_btnTestConnectionId);
        _imgTestConnectionSpinner = $("#imgTestConnectionSpinner");
        _btnOK = $find("OkButton");


        if (document.getElementById('hdnServerUrl').value === "") {
            _btnTestConnection.set_enabled(false);
        }

       

    }

    function readBlob(opt_startByte, opt_stopByte) {

        var files = document.getElementById(_sshFileUploaderfileId).files;

        if (!files.length) {
            return;
        }

        var file = files[0];
        var start = 0;
        var stop = file.size - 1;

        var reader = new FileReader();

        reader.onloadend = function (evt) {

            if (evt.target.readyState == FileReader.DONE) { // DONE == 2

                _gitPrivateKeyFileStream = evt.target.result;
            }
        };

        var blob = file.slice(start, stop + 1);

        // IE10 extend FileReader
        if (!FileReader.prototype.readAsBinaryString) {

            FileReader.prototype.readAsBinaryString = function (fileData) {
                var binary = "";
                var pt = this;
                var reader = new FileReader();

                reader.onloadend = function (e) {

                    var bytes = new Uint8Array(reader.result);
                    var length = bytes.byteLength;

                    for (var i = 0; i < length; i++) {
                        binary += String.fromCharCode(bytes[i]);
                    }

                    pt.content = binary;
                    _gitPrivateKeyFileStream = binary;
                }

                reader.readAsArrayBuffer(fileData);
            }
        }

        return reader.readAsBinaryString(blob);
    }

    function buildSettingForFormValidation() {

        var validationSettings = {};
        validationSettings.selectedMethod = {};

        if (_serverUrl.val() !== "") {
            validationSettings.url = _serverUrl.val();
        }

        switch (getSelectedGitAuthenticationMethod()) {

            case gitAuthenticationMethodTypesEnum.NONE:
                validationSettings.selectedMethod.Id = gitAuthenticationMethodTypesEnum.NONE;
                break;
            case gitAuthenticationMethodTypesEnum.CREDENTIALS:
                validationSettings.selectedMethod.Id = gitAuthenticationMethodTypesEnum.CREDENTIALS;
                validationSettings.selectedMethod.fields = {};
                validationSettings.selectedMethod.fields.userName = _userName.val() != "";
                validationSettings.selectedMethod.fields.password = _userPassword.val() != "";
                break;
            case gitAuthenticationMethodTypesEnum.TOKEN:
                validationSettings.selectedMethod.Id = gitAuthenticationMethodTypesEnum.TOKEN;
                validationSettings.selectedMethod.fields = {};
                validationSettings.selectedMethod.fields.token = _tokenTextbox.val() != "";
                break;
            case gitAuthenticationMethodTypesEnum.SSH:
                validationSettings.selectedMethod.Id = gitAuthenticationMethodTypesEnum.SSH;
                validationSettings.selectedMethod.fields = {};
                validationSettings.selectedMethod.selectedField = {};
                validationSettings.selectedMethod.fields.sshText = _sshTextAuthTextbox.val();
                validationSettings.selectedMethod.fields.sshFile = document.getElementById(_sshFileUploaderfileId).title;
                validationSettings.selectedMethod.selectedField.sshText = $telerik.$("#"+_sshRadioButtonList_0Id).prop('checked');;
                validationSettings.selectedMethod.selectedField.sshFile = $telerik.$("#" + _sshRadioButtonList_1Id).prop('checked');
                break;
        }

        return validationSettings;
    }

    function formFieldChanged() {
        if (document.getElementById('ddlRepositTypes_Input').value.toUpperCase() != GIT_KEYWORD) {
            return;
        }

        var validationSettings = buildSettingForFormValidation();
        document.getElementById('hdnServerUrl').value = "";
        _btnOK.set_enabled(false);
        _spnTestConnectionResult.text("");

        _btnOK.set_enabled(false);
        _spnTestConnectionResult.text("");

        _isFormValid = gitSorceControlValidator.validate(validationSettings);
      

        if (_isFormValid) {
            _btnTestConnection.set_enabled(true);
           
        }
        else {
            _btnTestConnection.set_enabled(false);
        }
    }

    function registerUIEvents() {

        var deferred = $.Deferred();

        var checkSelector = setInterval(function () {

            if ($('#' + _sshFileUploaderfileId).length
                    && $('#' + _passwordAuthTextboxId).length) {

                deferred.resolve();
            }

        }, 200);

        deferred.done(function () {

            initUIElements();
            $('#' + _sshFileUploaderfileId).change(readBlob);
            $('#' + _txtServerUrlId +
            ', #' + _sshTextAuthTextboxId +
            ', #' + _userNameAuthTextboxId +
            ', #' + _passwordAuthTextboxId +
                ', #' + _tokenTextboxId).keyup(formFieldChanged);

            $('#' + _txtServerUrlId).keydown(formFieldChanged);

            $('#' + _authenticationMethodNoneId +
            ', #' + _authenticationMethodCredentialsId +
            ', #' + _authenticationMethodTokenId +
                ', #' + _authenticationMethodSSHId +
                ', input[name*=\"sshRadioButtonList\"]' +
                ', #' + _sshFileUploaderfileId).change(formFieldChanged);
        });

    }

    function addCredentialsToUrl(url) {

        var authenticationCredentials;
        var prefixString = "://";
        var indexOfUrlFirstCharacterAfterPrefix = url.indexOf(prefixString);
        var userNameAuth = _userName.val();
        var passwordAuth = _userPassword.val();
        var token = _tokenTextbox.val();

        indexOfUrlFirstCharacterAfterPrefix = indexOfUrlFirstCharacterAfterPrefix == -1 ? 0 : indexOfUrlFirstCharacterAfterPrefix + prefixString.length;

        if (_authRadioButton.is(':checked')) {
            authenticationCredentials = userNameAuth + ":" + passwordAuth;
        }
        else {
            authenticationCredentials = token;
        }

        return url.substring(0, indexOfUrlFirstCharacterAfterPrefix)
            + authenticationCredentials
            + "@"
            + url.substring(indexOfUrlFirstCharacterAfterPrefix);
    }

    gitTestConnectionManager.testGitConnection = function (restultTrasnlatedMessages) {

        var settings = {};
        var credentials = {};

        credentials.user = _userName.val();
        credentials.pass = _userPassword.val();

        if (_authRadioButton.is(':checked') || _authenticationMethodToken.is(':checked')) {

            var serverUrlFromHiddenField = document.getElementById('hdnServerUrl').value;

            if (serverUrlFromHiddenField && serverUrlFromHiddenField != "") {

                settings.serverName = serverUrlFromHiddenField;
                credentials.user = null;
                credentials.pass = null;
            }
            else {
                settings.serverName = addCredentialsToUrl(_serverUrl.val());
            }
        }
        else {
            settings.serverName = _serverUrl.val();
        }

        settings.protocol = sourceControlProtocolType.SSH;
        settings.gitLsViewType = gitLsRemoteViewType.TAGS_AND_HEADS;
        settings.useSSL = false;
        settings.userCredentials = credentials;
        settings.repository = repositoryType.GIT;

        if (_authenticationMethodSSH.is(':checked')) {

            settings.protocol = sourceControlProtocolType.SSH;
            settings.sshPublicKey = "";

            if (isSSHFileRadioButtonChecked()) {
                settings.sshPrivateKey = _gitPrivateKeyFileStream;
            }
            else {
                settings.sshPrivateKey = _sshTextAuthTextbox.val();
            }

            settings.useSSH = true;
        }

        _spnTestConnectionResult.removeClass('success');
        _spnTestConnectionResult.removeClass('error');
        _imgTestConnectionSpinner.show();
        _btnTestConnection.set_enabled(false);
        _spnTestConnectionResult.text("");

        gitTestConnectionManager.testConnection(settings).done(function (result) {

            _btnTestConnection.set_enabled(true);
            _imgTestConnectionSpinner.hide();

            if (result.isSuccesfull && result.isSuccesfull === true) {
                _btnOK.set_enabled(true);
                _spnTestConnectionResult.addClass('success');
                _spnTestConnectionResult.text(restultTrasnlatedMessages.success);
            }
            else {
                _spnTestConnectionResult.addClass('error');
                _spnTestConnectionResult.text(restultTrasnlatedMessages.failure);
            }
        })
        .catch(function (error) {
            _spnTestConnectionResult.addClass('error');
            _spnTestConnectionResult.text(result.errorMessage);
        });
    }

    gitTestConnectionManager.testConnection = function (settings) {

        var testConnectionUrl = getLocationOriginURL() + "/cxwebclient/api/git/testconnection";

        return $.ajax({
            type: "POST",
            url: testConnectionUrl,
            data: settings
        });
    };

    registerUIEvents();

})();