﻿(function () {
    "use strict";

    checkmarx.CxPortal.factory('CxPortal.AuthorizationServiceConfigurationDataService', ['CxPortal.AjaxServiceWithNotification', 'apiBaseURLService',
        function (ajaxServiceWithNotification, apiBaseURLService) {

            var url = apiBaseURLService.getAPIVirtualDirectory() + '/configurations/AuthorizationService';

            function get() {
                
                return ajaxServiceWithNotification.get(url);
            }

            return {
                get: get
            };
        }]);
})();