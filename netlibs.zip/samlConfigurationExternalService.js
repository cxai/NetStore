﻿
var samlConfigurationExternalService = {};

(function () {
    "use strict";
    var _teamLevel = 3;
    var _tree;

    samlConfigurationExternalService.group = {
        value: undefined,
        isTouched: false
    };

    samlConfigurationExternalService.addGroupIdWithoutTouchingTheParameter = function (groupId) {

        samlConfigurationExternalService.group.value = groupId;
        angular.element(document.getElementById('saml-view')).scope().$broadcast('hide-default-team-error');
    };

    samlConfigurationExternalService.addGroupId = function (groupId) {
        samlConfigurationExternalService.addGroupIdWithoutTouchingTheParameter(groupId);
        angular.element(document.getElementById('saml-view')).scope().$broadcast('default-team-error-was-touched');
    }

    samlConfigurationExternalService.removeGroupId = function (groupId) {

        samlConfigurationExternalService.group.value = undefined;
        angular.element(document.getElementById('saml-view')).scope().$broadcast('show-default-team-error');
        angular.element(document.getElementById('saml-view')).scope().$broadcast('default-team-error-was-touched');
    };

    samlConfigurationExternalService.onLoad = function (tree) {
        if (tree) {
            _tree = tree;
        }
        samlConfigurationExternalService.setSavedOrDefaultValueAndDisableAllNodesThatAreNotTeams();
        setIframeHeight();
    }

    samlConfigurationExternalService.setSavedOrDefaultValueAndDisableAllNodesThatAreNotTeams = function(){
        var currentNode;
        if (_tree) {
            for (var i = 0; i < _tree.get_allNodes().length; i++) {

                currentNode = _tree.get_allNodes()[i];

                if (currentNode.get_level() < _teamLevel) {
                    currentNode.set_enabled(false);
                }
                else if (samlConfigurationExternalService.group.value && currentNode.get_value() === samlConfigurationExternalService.group.value) {
                    currentNode.set_checked(true);
                }
                else if (currentNode.get_level() == _teamLevel) {

                    if (samlConfigurationExternalService.group.value) {
                        currentNode.set_checked(false);
                    }
                    else {
                        currentNode.set_checked(true);
                        samlConfigurationExternalService.addGroupIdWithoutTouchingTheParameter(currentNode.get_value());
                    }
                }
            }
        }
    }

    function setIframeHeight() {
        document.getElementsByName('defaultTeam')[0].contentWindow.document.getElementById('groupsTree').style.height = "138px";
        document.getElementsByName('defaultTeam')[0].contentWindow.document.getElementById('groupsTree').style.minWidth = "0px";
    }

})();