﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('policyStatusService', [
        '$q',
        'lastScanByProjectLoader',
        '$stateParams',
        'policyViolationStatuses',
        'projectStatuses',
        'projectSeverity',
        function ($q, lastScanByProjectLoader, $stateParams, policyViolationStatuses, projectStatuses, projectSeverity) {
            /* buisness service for calculating project's scan policy status. */

            var scanDataModel = {};

            function getLastScanData() {

                var projectId = $stateParams.id;
                return lastScanByProjectLoader.load(projectId);
            }

            function getStatuses(severityId) {

                var i = 0;

                for (i; i < scanDataModel.resultDistribution.length; i++) {

                    if (scanDataModel.resultDistribution[i].severity.id == severityId) {

                        return scanDataModel.resultDistribution[i].statuses;
                    }
                }

                return [];
            }

            function sumNewAndRecurrentStatuses(statuses) {

                var count = 0;
                var i = 0;

                for (i; i < statuses.length; i++) {

                    if (statuses[i].id == projectStatuses.new || statuses[i].id == projectStatuses.reoccured) {

                        count += statuses[i].count;
                    }
                }

                return count;
            }

            function countOfNewAndRecurrentStatuses(projectSeverityStatus) {

                return sumNewAndRecurrentStatuses(getStatuses(projectSeverityStatus));
            }

            function calculatePolicyStatus() {
                /* calculates the policy status and return policy status as promise.
                   example: statuses 'violated', 'complaint'.
                */

                var deferred = $q.defer();

                getLastScanData().then(function (scanData) {

                    scanDataModel = scanData;
                    var status = null;

                    if (countOfNewAndRecurrentStatuses(projectSeverity.high) > 0) {
                        return deferred.resolve(policyViolationStatuses.violated);
                    }

                    if (countOfNewAndRecurrentStatuses(projectSeverity.medium) > 0) {
                        return deferred.resolve(policyViolationStatuses.violated);
                    }

                    return deferred.resolve(policyViolationStatuses.complaint);
                });

                return deferred.promise;
            }

            return {
                calculatePolicyStatus: calculatePolicyStatus
            };

    }]);

})();