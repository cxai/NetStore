﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxPortal.provider('siteGlobalVariablesProvider', [function () {
        // service for wraping the global site variables.

        //#region run phase API

        function throwError() {

            throw "siteGlobalVariablesProvider: global variable is not defined";
        }

        function getBasicVariables() {

            if (_cxGlobalVariables) {

                return _cxGlobalVariables;
            }

            throwError();
        }

        function currentCulture() {
            return this.basicVariables().currentCulture;
        }

        function isAdmin() {
            return this.basicVariables().isAdmin;
        } 

        function isAuditor() {
            return this.basicVariables().isAuditor;
        }

        function importCustomDescriptionMaxFileSize() {
            return this.basicVariables().importCustomDescriptionMaxFileSize;
        }

        function importUpdateCustomQueryEnabled() {
            return this.basicVariables().importUpdateCustomQueryEnabled;
        }

        function getPortalBaseUrl() {
            return  window.location.protocol + '//' + this.basicVariables().PortalBaseUrl;
        }

        function getAuthorizationServiceTimeout() {
            return this.basicVariables().AuthorizationServiceTimeout;
        }

        function getSecurityIdentityToken() {
            return this.basicVariables().SecurityIdentityToken;
        }

        function getAppVersionNumber() {

            if (_cxGlobalVariables) {

                return this.basicVariables().cxAppVersionNumber;
            }

            throwError();
        }

        function getBuildVersionNumber() {

            if (_cxGlobalVariables) {

                return this.basicVariables().buildVersionNumber;
            }

            throwError();
        }

        this.$get = [function () {

            return {
                basicVariables: getBasicVariables,
                isAdmin: isAdmin,
                isAuditor: isAuditor,
                currentCulture: currentCulture,
                importCustomDescriptionMaxFileSize: importCustomDescriptionMaxFileSize,
                importUpdateCustomQueryEnabled: importUpdateCustomQueryEnabled,
                getPortalBaseUrl: getPortalBaseUrl,
                getAuthorizationServiceTimeout: getAuthorizationServiceTimeout,
                getSecurityIdentityToken: getSecurityIdentityToken,
                getAppVersionNumber: getAppVersionNumber,
                getBuildVersionNumber: getBuildVersionNumber
            };
        }];

        //#endregion

        //#region config phase API

        this.basicVariables = function () {
    
            return getBasicVariables();
        };
        
        //#endregion

    }]);

})();