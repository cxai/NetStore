﻿/// <reference path="../../app.js" />
/// <reference path="../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxAcademy.controller('AppSecCoach.LessonIsNotAvailbleDialogFormController', [
        '$rootScope',
        '$scope',
        'AppSecCoach.DialogIDs',
        'AppSecCoach.LessonsOpener',
        function ($rootScope, $scope, appSecCoachDialogIDs, lessonsOpener) {

            $scope.dialogId = appSecCoachDialogIDs.appSecCoachLessonIsNotAvailableDialog;

            $scope.closeDialog = function () {
                $rootScope.$broadcast('dialog-close-' + $scope.dialogId);
            };

            $scope.enterAppSecCoachClick = function () {
                $scope.closeDialog();
                lessonsOpener.openGeneralLessonsPage();
            };

            $scope.appSecCoachlicenseDialogSetup = {
                modal: true,
                width: 391,
                minHeight: 120,
                resizable: false,
                show: {
                    effect: "fade", duration: 300
                },
                hide: {
                    effect: "fade", duration: 200
                }
            };
        }]);
})();