var Checkmarx;
(function (Checkmarx) {
    var cxDirectives = Checkmarx.Directives;
    var cxServices = Checkmarx.Services;
    checkmarx.service('#net', cxServices.NetService).
        directive('selectBox', cxDirectives.SelectBoxDirectiveSettings).
        directive('multiAutoComplete', cxDirectives.MultiAutoCompleteDirectiveSettings).
        directive('cxMenu', cxDirectives.CxMenuSettings).
        directive('tabNotification', cxDirectives.TabNotificationDirectiveSettings).
        directive('widget', cxDirectives.WidgetDirectiveSettings).
        directive('utilization', cxDirectives.UtilizationDirectiveSettings).
        directive('riskState', cxDirectives.RiskStateDirectiveSettings).
        directive('queueStateWidget', cxDirectives.QueueStateWidgetDirectiveSettings).
        directive('heatMapWidget', cxDirectives.HeatMapWidgetDirectiveSettings).
        directive('progressBarsWidget', cxDirectives.ProgressBarsWidgetDirectiveSettings).
        directive('toggleButton', cxDirectives.ToggleButtonDirectiveSettings).
        directive('radialGauge', cxDirectives.RadialGaugeDirectiveSettings).
        directive('areaChart', cxDirectives.AreaChartDirectiveSettings).
        directive('stackedBar', cxDirectives.StackedBarDirectiveSettings);
})(Checkmarx || (Checkmarx = {}));
;
//# sourceMappingURL=baseModelRegistration.js.map