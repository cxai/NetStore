﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxPortal.directive('helpTooltip', [function () {

        return {
            template: '<span class="custom-tooltip-filter custom-tooltip-filter-down">'
                        + '<img src="app/portal/styles/images/blue-tooltip.png" class="helpIcon" title="">'
                            + '<span class="custom-tooltip-content">'
                                + '<span class="custom-tooltip-text">'
                                    + '<span class="custom-tooltip-inner" ng-bind-html="text">'
                                
                                    + '</span>'
                                + '</span>'
                            + '</span>'
                  + '</span>',
            scope: {
                text: '@'
            }
        };
    }]);
})();