﻿(function () {
    "use strict";

    checkmarx.CxPortal.factory('portalhttpRequestInterceptor', [
        '$q',
        '$window',
        'portalPageURLs',
        'httpStatusCodes',
        'portalCookieNames',
        'portalHeaderNames',
        'siteGlobalVariablesProvider',
        'apiBaseURLService',
        'CxPortal.BuildNumberService',
        '$templateCache',
        'CxPortal.ApplicationVersionNumberLoader',
        function ($q,
                    $window,
                    portalPageURLs,
                    httpStatusCodes,
                    portalCookieNames,
                    portalHeaderNames,
                    siteGlobalVariablesProvider,
                    apiBaseURLService,
                    buildVersionNumberService,
                    $templateCache,
                    ApplicationVersionNumberLoader) {
            /* HTTP interceptor for adding custom HTTP headers. */

            function redirectToLoginPage() {
                $window.location.href = "/CxWebClient/" + portalPageURLs.login;
            }

            function isCxRestApiRequest(url) {
                return (url.indexOf(apiBaseURLService.getAPIVirtualDirectory()) === 0);
            }

            function isHtml(url) {
                return url.match(/\.(html|htm)$/i);
            }
            
            function isCachedTemplate(url) {
                return $templateCache.get(url);
            }

            return {
                request: function ($config) {                    
                    $config.headers[portalHeaderNames.cxOrigin] = 'cx-WebPortal/' + ApplicationVersionNumberLoader.load();
                    $config.headers['Accept-Language'] = siteGlobalVariablesProvider.currentCulture();

                    if (typeof $config.url === 'string') {

                        if (!isCxRestApiRequest($config.url)) {

                            $config.headers['SecurityIdentityToken'] = siteGlobalVariablesProvider.getSecurityIdentityToken();
                            $config.headers['X-Requested-With'] = 'XMLHttpRequest';
                        }

                        if (isHtml($config.url) && !isCachedTemplate($config.url)) {
                            $config.url = buildVersionNumberService.addVersionNumberToUrl($config.url);
                        }
                    }                    
                    
                    return $config;
                },
                responseError: function (response) {

                    if (response && response.status) {

                        if (response.status == httpStatusCodes.unauthorized) {
                            redirectToLoginPage();
                        }
                    }

                    return $q.reject(response);
                }
            };
        }]);

    checkmarx.CxPortal.config(['$httpProvider', function ($httpProvider) {
        /* add custom interceptors. */
        $httpProvider.interceptors.push('portalhttpRequestInterceptor');
    }]);
})();