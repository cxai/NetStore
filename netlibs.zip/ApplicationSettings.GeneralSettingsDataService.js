﻿(function () {
    'use strict';

    checkmarx.ApplicationSettings.factory('ApplicationSettings.GeneralSettingsDataService',
        ['CxPortal.AjaxServiceWithNotification', 'apiBaseURLService', '$q', 'CxPortal.LanguagesDataService',
        function (ajaxServiceWithNotification, apiBaseURLService, $q, languagesDataService) {

            var configurationUrl = apiBaseURLService.getAPIVirtualDirectory() + '/configurations/SystemSettings';
            
            function get() {
                return ajaxServiceWithNotification.get(configurationUrl);
            }

            function put(configData) {
                return ajaxServiceWithNotification.put(configurationUrl, configData);
            }

            return {
                get: get,
                put: put
            };
        }]);
})();