﻿(function () {
    "use strict";

    checkmarx.ProjectState.directive('noSastScanPerformed', [function () {

        var template = '<div class="modal-empty-scan">'
                    +    '<img src="app/projectState/style/images/no_sast_scan.png" />'
                    +    '<div class="no-sast-scans">{{\'NO_SAST_SCANS_IS_PERFORMED\' | translate}}</div>'
                    + '</div>';

        return {
            scope: {},
            controller: ['$rootScope', '$scope', 'modalService', 'userPreferencesService', 'showHideSASTNotificationsService', '$stateParams',
                function ($rootScope, $scope, modalService, userPreferencesService, showHideSASTNotificationsService, $stateParams) {
                    
                var modal = null;
                var projectId = $stateParams.id;

                function openModal() {

                    if (showHideSASTNotificationsService.shouldShowSASTEmptyStateModal(projectId)) {

                        userPreferencesService.hideNoScanModal(projectId);
                        modal = modalService.openModalHTMLTemplate(template, 'empty-scan');
                    }
                }                

                $rootScope.$on('openSASTEmptyStateModal', function () {
                    openModal();
                });
            }]
        };

    }]);

})();