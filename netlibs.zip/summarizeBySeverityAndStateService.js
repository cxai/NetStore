﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('summarizeBySeverityAndStateService', function () {

        function getStatusesOfSeverity(scanDataModel, severityId) {

            var i = 0;

            for (i; i < scanDataModel.resultDistribution.length; i++) {

                if (scanDataModel.resultDistribution[i].severity.id == severityId) {

                    return scanDataModel.resultDistribution[i].statuses;
                }
            }

            return [];
        }

        function getStatusCount(scanDataModel, severityId, statusId) {

            var i = 0;

            var status = getStatusesOfSeverity(scanDataModel, severityId);

            for (var x = 0; x < status.length; x++) {

                if (status[x].id == statusId) {
                    return status[x].count;
                }
            }

            return [];
        }

        return {
            getStatusesOfSeverity: getStatusesOfSeverity,
            getStatusCount: getStatusCount
        };

    });

})();