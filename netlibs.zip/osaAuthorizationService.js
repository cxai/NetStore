﻿(function () {
    "use strict";

    checkmarx.ProjectState.factory('osaAuthorizationService', ['$state', function ($state) {

            function checkAuthorization(isOsaLicensed) {
                if ($state.current.name === "projectState.osa" && !isOsaLicensed) {
                    $state.go("projectState.summary");
                }
            };

            return {
                checkAuthorization: checkAuthorization
            };
        }]);

})();