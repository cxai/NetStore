﻿var EmailMaxCount;
var SingleMailMaxLength;
var EmailsMaxLength;
var EmailsErrorMessage;
var EmailsMaxLengthError;
var EmailMaxCountError;
var SingleMailMaxLengthError;
var InvalidEmailError;

function ReturnEmailsToParent() {
    //create the argument that will be returned to the parent page
    var oArg = new Object();

    if (document.getElementById("Emails").value == "") {
        oArg.Emails = "";
    }
    else {
        oArg.Emails = document.getElementById("Emails").value;
    }

    //get a reference to the current RadWindow
    var oWnd = GetRadWindow();
    
    oWnd.close(oArg);

}

function CloseDialogEventCancel() {
    //create the argument that will be returned to the parent page
    var oArg = new Object();
        
    oArg.Emails = "";

    //get a reference to the current RadWindow
    var oWnd = GetRadWindow();

    oWnd.close(oArg);

}

function AddItem() {
    var listBox = $find("PageListBox");
    var itemText = $get("EmailTextBox").value;
    if (!itemText) {
        return false;
    }

    // validations
    //------------------------------
    if (!CheckEmail(itemText)) {
        error = EmailsErrorMessage;
       top.openInfo(error,null);
        return false;
    }

    if (listBox.get_items().get_count() >= EmailMaxCount)
    {
        error = EmailMaxCountError;
        
        top.openInfo(error,null);
        return false;
    }


    var emails = itemText;
    for (var i = 0; i < listBox.get_items().get_count(); i++) {
        emails += listBox.get_items().getItem(i).get_value() + ";";
    }

    if (emails.length > EmailsMaxLength) {
        error = EmailsMaxLengthError;
        top.openInfo(error,null);
        return false;
    }

    listBox.trackChanges();
    //Instantiate a new client item
    var item = new Telerik.Web.UI.RadListBoxItem();
    item.set_text(itemText);
    item.set_selected(true);

    listBox.get_items().add(item);
    item.scrollIntoView();
    listBox.commitChanges();
    UpdateEmails();
    $get("EmailTextBox").value = "";
    return false;
}

function DeleteItem() {
    var listBox = $find("PageListBox");
    if (listBox.get_items().get_count() < 1) {
        return false;
    }

    var selectedItem = listBox.get_selectedItem();
    if (!selectedItem) {
        return false;
    }

    listBox.deleteItem(selectedItem);
    UpdateEmails();
    return false;
}

function UpdateEmails() {
    var listBox = $find("PageListBox");
    var emails = "";
    for (var i = 0; i < listBox.get_items().get_count(); i++) {
        emails += listBox.get_items().getItem(i).get_value() + ";";
    }
    $get("Emails").value = emails.substring(0, emails.length - 1);
    return false;
}

function CheckEmail(email) {
    EmailsErrorMessage = "";
    if (email.length > SingleMailMaxLength) {
        EmailsErrorMessage = SingleMailMaxLengthError;
        return false;
    }

    if (email.indexOf('\\') > -1) {
        email = email.replace(/\\/g, '\\\\');
    }
    var validMailRegex = "^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)*[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$";
    if (email.match(validMailRegex) != null) {
        return true;
    }

    EmailsErrorMessage = InvalidEmailError;

    return false;
}