﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.Common.filter('timeByUTCFilter', ['siteGlobalVariablesProvider',
        function (globalVariables) {
            /* filter for formatting date and time based on a given locale. */

            return function (dateTime) {

                var locelizedTime = "";

                if (dateTime) {

                    var locale = globalVariables.basicVariables().currentCulture;

                    var date = new Date(dateTime);
                    locelizedTime = date.toLocaleTimeString();
                }

                return locelizedTime;
            };
        }]);

})();