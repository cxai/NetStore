﻿(function () {
    "use strict";

    checkmarx.Queries.factory('Queries.ImportCustomDescriptionValidatorService', [
        '$translate',
        'siteGlobalVariablesProvider',
        'Common.FileExtensionValidator',
        'Common.MegabytesToBytesConvertor',
        function ($translate, siteGlobalVariablesProvider, fileExtensionValidator, megabytesToBytesConvertor) {

            var _validFileExtensions = [".htm", ".html"];

            function getMaxFileSizeInBytes() {

                if (siteGlobalVariablesProvider.importCustomDescriptionMaxFileSize() > 0) {

                    return siteGlobalVariablesProvider.importCustomDescriptionMaxFileSize();
                }

                return _validFileExtensions;
            }

            function isFileExist(file) {

                if (!file) {
                    return false;
                }

                return true;
            }

            function isFileExtensionSupported(fileName) {

                if (!fileExtensionValidator.validate(fileName, _validFileExtensions)) {
                    return false;
                }

                return true;
            }

            function isFileEmpty(file) {

                if (file.size == 0) {
                    return false;
                }

                return true;
            }

            function isFileSizeValid(file) {

                if (file.size >= megabytesToBytesConvertor.convert(getMaxFileSizeInBytes())) {
                    return false;
                }

                return true;
            }

            function getFailedResult(message) {

                return {
                    isValid: false,
                    uploadFileErrorMessage: message
                };
            }

            function validate(file) {

                if (!isFileExist(file)) {
                    return getFailedResult($translate.instant("CUSTOM_DESCRIPTION_NO_FILE_SELECTED"));
                }
                else if (!isFileEmpty(file)) {
                    return getFailedResult($translate.instant("CUSTOM_DESCRIPTION_FILE_IS_EMPTY"));
                }
                else if (!isFileExtensionSupported(file.name)) {
                    return getFailedResult($translate.instant("CUSTOM_DESCRIPTION_FILE_NOT_SUPPORTED"));
                }
                else if (!isFileSizeValid(file)) {
                    return getFailedResult($translate.instant("CUSTOM_DESCRIPTION_FILE_SIZE_EXCEEDS_THE_MAXIMUM_LIMIT"));
                }

                return {
                    isValid: true
                };
            }

            return {
                validate: validate
            };

        }]);

})();