﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.Common.provider('ajaxService', [function () {
           
        this.$get = ['$http', function ($http) {
           
                function get(url, config) {

                    return $http.get(url, config || null);
                }

                function post(url, data, config) {

                    return $http.post(url, data || {}, config || null);
                } 

                function put(url, data, config) {

                    return $http.put(url, data || {}, config || null);
                }
                
                function sendDeleteRequest(url, config) {
                    //The name "delete" could not be used for this function since is a keyword of the language and is invalid to use it for an identifier.

                    return $http.delete(url, config || null);
                }
                
                function patch(url, data) {

                    return $http({ method: 'PATCH', url: url, data: data });
                }    
                
                return {
                    get: get,
                    post: post,
                    put: put,
                    sendDeleteRequest: sendDeleteRequest,
                    patch: patch
                }
            }];
    }]);

})();