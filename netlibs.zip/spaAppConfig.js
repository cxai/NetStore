﻿(function () {
    "use strict";

    checkmarx.config(['$stateProvider',
        '$urlRouterProvider',
        '$translateProvider',
        'siteGlobalVariablesProviderProvider',
        'spaPagesGroups',
        'authorizationNeeded',
        '$compileProvider',
        '$locationProvider',
        '$qProvider',
        function ($stateProvider,
            $urlRouterProvider,
            $translateProvider,
            siteGlobalVariablesProviderProvider,
            spaPagesGroups,
            authorizationNeeded,
            $compileProvider,
            $locationProvider,
            $qProvider) {

            $compileProvider.preAssignBindingsEnabled(true);
            $locationProvider.hashPrefix('');
            $qProvider.errorOnUnhandledRejections(false);

            $translateProvider.translations(siteGlobalVariablesProviderProvider.basicVariables().currentCulture, _translationObject.translations);
            $translateProvider.preferredLanguage(siteGlobalVariablesProviderProvider.basicVariables().currentCulture);
            $translateProvider.useSanitizeValueStrategy(null);

            function summaryOSAConfigController($state, $rootScope, projectDetails, finishedScansLatest, lastScanByProjectModel, loadOSALicense, projectStatePreloadedData, osaAuthorizationService) {

                $rootScope.isOsaLicensed = loadOSALicense;
                projectStatePreloadedData.setProjectDetails(projectDetails.data);
                $state.current.statePreloadedData.finishedScansLatest = finishedScansLatest ? finishedScansLatest.data : null;
                $state.current.statePreloadedData.lastScanByProjectModel = lastScanByProjectModel;
            }

            function summaryOsaProjectName(projectStatePreloadedData) {

                var name = "", preloadedData = projectStatePreloadedData.projectDetails();

                if (preloadedData) {
                    name = preloadedData.name;
                }

                return name;
            }

            $stateProvider.state("dashboard", {
                abstract: true,
                url: "/dashboard",
                templateUrl: "/CxWebClient/pages/Dashboard/Dashboard",
                metadata: {
                    name: ['$translate', function ($translate) {
                        return $translate.instant('DASHBOARD');
                    }],
                    spaPagesGroups: spaPagesGroups.dashboard
                }
            });

            $stateProvider.state("dashboard.risk", {
                url: "/Risk",
                templateUrl: "/CxWebClient/pages/Dashboard/RiskTab",
                metadata: {
                    name: ['$translate', function ($translate) {
                        return $translate.instant('RISK_STATE');
                    }],
                    spaPagesGroups: spaPagesGroups.dashboard
                }
            });

            $stateProvider.state("dashboard.utilization", {
                url: "/Utilization",
                templateUrl: "/CxWebClient/pages/Dashboard/UtilizationTab",
                metadata: {
                    name: ['$translate', function ($translate) {
                        return $translate.instant('UTILIZATION');
                    }],
                    spaPagesGroups: spaPagesGroups.dashboard,
                    auth: authorizationNeeded.admin
                }
            });

            $stateProvider.state("projectState", {
                url: "/projectState/:id",
                templateUrl: "/CxWebClient/app/projectState/views/projectState.html",
                metadata: {
                    name: ['$translate', function ($translate) {
                        return $translate.instant('PROJECT_STATE');
                    }],
                    spaPagesGroups: spaPagesGroups.projectState
                },
                resolve: {
                    projectDetails: ['CxPortal.HttpErrorStatusHandler', 'httpStatusCodes', '$stateParams', 'projectDetailsDataService', function (httpErrorStatusHandler, httpStatusCodes, $stateParams, projectDetailsDataService) {
                        return projectDetailsDataService.getProject($stateParams.id).catch(function (error) {
                            if (error.status === httpStatusCodes.notFound) {
                                httpErrorStatusHandler.redirectToPageNotFound();
                            }
                        });
                    }],
                    finishedScansLatest: ['$stateParams', 'lastScanByProjectDataService', function ($stateParams, lastScanByProjectDataService) {
                        return lastScanByProjectDataService.getLastScanByProjectId($stateParams.id).catch(function () { });
                    }],
                    lastScanByProjectModel: ['$stateParams', 'lastScanByProjectLoader', function ($stateParams, lastScanByProjectLoader) {
                        return lastScanByProjectLoader.load($stateParams.id).catch(function () { });
                    }],
                    removeCache: ['cacheService', 'projectsCacheKeys', function (cacheService, projectsCacheKeys) {
                        cacheService.remove(projectsCacheKeys.openSourceAnalysisModel);
                    }],
                    loadOSALicense: ['$rootScope', 'osaLicenseDataService', function ($rootScope, osaLicenseDataService) {
                        return osaLicenseDataService.isOsaLicensed();
                    }]
                },
                id: ['$stateParams', function ($stateParams) {
                    return $stateParams.id;
                }]
            });

            $stateProvider.state("projectState.summary", {
                parent: "projectState",
                url: "/Summary",
                templateUrl: "/CxWebClient/app/projectState/views/projectStateSummary.html",
                metadata: {
                    name: ['projectStatePreloadedData', summaryOsaProjectName],
                    spaPagesGroups: spaPagesGroups.projectState
                },
                statePreloadedData: {
                    projectDetails: null,
                    finishedScansLatest: null,
                    lastScanByProjectModel: null
                },
                controller: ['$state', '$rootScope', 'projectDetails', 'finishedScansLatest', 'lastScanByProjectModel', 'loadOSALicense', 'projectStatePreloadedData', 'osaAuthorizationService', summaryOSAConfigController]
            });

            $stateProvider.state("projectState.osa", {
                parent: "projectState",
                url: "/OSA",
                templateUrl: "/CxWebClient/app/projectState/views/projectStateOSATab.html",
                metadata: {
                    name: ['projectStatePreloadedData', summaryOsaProjectName],
                    spaPagesGroups: spaPagesGroups.projectState
                },
                statePreloadedData: {
                    projectDetails: null,
                    finishedScansLatest: null,
                    lastScanByProjectModel: null
                },
                controller: ['$state', '$rootScope', 'projectDetails', 'finishedScansLatest', 'lastScanByProjectModel', 'loadOSALicense', 'projectStatePreloadedData', 'osaAuthorizationService', summaryOSAConfigController]
            });

            $stateProvider.state("SAML", {
                url: "/SAML",
                templateUrl: "/CxWebClient/app/SAML/views/saml.html",
                metadata: {
                    name: ['$translate', function ($translate) {
                        //fake name for the breadcrums to look like part of the soap path.
                        return $translate.instant('MANAGEMENT') + ' / ' + $translate.instant('CONNECTION_SETTINGS');
                    }],
                    spaPagesGroups: spaPagesGroups.SAML,
                    auth: authorizationNeeded.admin
                }
            });

            $stateProvider.state("SAML.configuration", {
                url: "/Configuration",
                templateUrl: "/CxWebClient/app/SAML/views/samlConfiguration.html",
                metadata: {
                    name: ['$translate', function ($translate) {
                        return $translate.instant('SAML');
                    }],
                    spaPagesGroups: spaPagesGroups.SAML,
                    auth: authorizationNeeded.admin
                }
            });
            
            $stateProvider.state("ApplicationSettings", {
                url: "/ApplicationSettings",
                templateUrl: "/CxWebClient/app/applicationSettings/views/ApplicationSettings.html",
                metadata: {
                    name: ['$translate', function ($translate) {
                        return $translate.instant('MANAGEMENT') + ' / ' + $translate.instant('APPLICATION_SETTINGS');
                    }],
                    spaPagesGroups: spaPagesGroups.applicationSettings,
                    auth: authorizationNeeded.admin
                }
            });

            $stateProvider.state("ApplicationSettings.ExternalServicesSettings", {
                url: "/ExternalServicesSettings",
                templateUrl: "/CxWebClient/app/applicationSettings/views/externalServices/externalServicesSettings.html",
                metadata: {
                    name: ['$translate', function ($translate) {
                        return $translate.instant('EXTERNAL_SERVICES_SETTINGS');
                    }],
                    spaPagesGroups: spaPagesGroups.applicationSettings,
                    auth: authorizationNeeded.admin
                }
            });

            $stateProvider.state("ApplicationSettings.General", {
                url: "/General",
                templateUrl: "/CxWebClient/app/applicationSettings/views/generalSettings/general.html",
                metadata: {
                    name: ['$translate', function ($translate) {
                        return $translate.instant('GENERAL');
                    }],
                    spaPagesGroups: spaPagesGroups.applicationSettings,
                    auth: authorizationNeeded.admin
                }
            });

            $stateProvider.state("ApplicationSettings.EngineManagement", {
                url: "/EngineManagement",
                templateUrl: "/CxWebClient/app/applicationSettings/views/engineManagement/engineManagement.html",
                metadata: {
                    name: ['$translate', function ($translate) {
                        return $translate.instant('ENGINE_MANAGEMENT');
                    }],
                    spaPagesGroups: spaPagesGroups.applicationSettings,
                    auth: authorizationNeeded.admin
                }
            });
            
            $urlRouterProvider.when('', '/dashboard/Utilization').when('/', '/dashboard/Utilization').when('/dashboard', '/dashboard/Utilization');
        }]);

})();