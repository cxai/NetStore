﻿(function () {
    'use strict';

    checkmarx.ApplicationSettings.factory('ApplicationSettings.GeneralSettingsDataIntegrationService', [
        'generalSettingsValues', '$translate', function (generalSettingsValues, $translate) {

            var getDefaultLanguage = function (defaultLanguages) {
                for (var i = 0; i < defaultLanguages.length; i++) {
                    if (defaultLanguages[i].isDefaultLanguage) {
                        return defaultLanguages[i];
                    }
                }
            };

            function isPropertyUndefined(val) {

                return val === undefined;
            }

            function getConfigurationData(data, languages, maxConcurrentScansValue) {
                return {
                    serverSettings: {
                        reportsFolder: data.reportS_PATH,
                        resultsFolder: data.resultS_PATH,
                        executablesFolder: data.executablesFolder,
                        isLongPathEnabled: isPropertyUndefined(data.isLongPathEnabled) ? false : (data.isLongPathEnabled.toLowerCase() === "true" ? true : false),
                        gitPath: data.giT_EXE_PATH,
                        perforcePath: data.perforcE_EXE_PATH,
                        maxConcurrentScans: Math.min(parseInt(data.maximuM_CONCURRENT_SCAN_EXECUTERS),
                            maxConcurrentScansValue),
                        webServerAddress: data.webServer,
                        defaultServerLanguage: getDefaultLanguage(languages),
                    },
                    smtpSettings: {
                        host: data.smtpHost,
                        port: data.smtpPort == "" ? null : parseInt(data.smtpPort),
                        encryptionType: data.smtpEncryption,
                        emailFromAddress: data.eMailFromAddress,
                        defaultCredentials: data.smtpUseDefaultCredentials === "True" ? true : false,
                        userName: data.smtpUseDefaultCredentials === "True" ? "" : data.smtpUsername,
                        userNameTooltip: $translate.instant('SMTP_USER_NAME_NOTIFICATION'),
                        password: data.smtpUseDefaultCredentials === "True" ? "" : data.smtpPassword
                    },
                    osaSettings: {
                        organizationToken: data.whiteSourceOrganizationToken,
                        matchByFilename: isPropertyUndefined(data.openSourceMatchByFilename) ? undefined : (data.openSourceMatchByFilename.toLowerCase() === "true" ? true : false),
                        unrecognizedLibraries: isPropertyUndefined(data.openSourceIncludeUndetectedLibraries) ? undefined : (data.openSourceIncludeUndetectedLibraries.toLowerCase() === "true" ? true : false),
                        matchByFileNameTooltip: $translate.instant('MATCH_BY_FILE_NAME_TOOLTIP_PREFIX') + '<br>' + $translate.instant('MATCH_BY_FILE_NAME_TOOLTIP_NOTE'),
                        unrecognizedLibrariesTooltip: $translate.instant('UNRECOGNIZED_LIBRARIES_TOOLTIP_PREFIX') + '<br>' + $translate.instant('UNRECOGNIZED_LIBRARIES_TOOLTIP_NOTE')
                    }
                }
            };
            

            function setConfigurationData(data) {
                return {
                        reportS_PATH: data.serverSettings.reportsFolder,
                        resultS_PATH: data.serverSettings.resultsFolder,
                        executablesFolder: data.serverSettings.executablesFolder,
                        isLongPathEnabled:data.serverSettings.isLongPathEnabled ? "True" : "False",
                        giT_EXE_PATH: data.serverSettings.gitPath,
                        perforcE_EXE_PATH: data.serverSettings.perforcePath,
                        maximuM_CONCURRENT_SCAN_EXECUTERS: data.serverSettings.maxConcurrentScans,
                        smtpHost: data.smtpSettings.host,
                        smtpPort: data.smtpSettings.port == null ? "" : data.smtpSettings.port,
                        smtpEncryption: data.smtpSettings.encryptionType,
                        emailFromAddress: data.smtpSettings.emailFromAddress,
                        smtpUseDefaultCredentials: data.smtpSettings.defaultCredentials ? "True" : "False",
                        smtpUsername: data.smtpSettings.defaultCredentials ? "" : data.smtpSettings.userName,
                        smtpPassword: data.smtpSettings.defaultCredentials ? "" : data.smtpSettings.password,
                        WebServer: data.serverSettings.webServerAddress,
                        openSourceMatchByFilename: data.osaSettings.matchByFilename ? "True" : "False",
                        openSourceIncludeUndetectedLibraries: data.osaSettings.unrecognizedLibraries ? "True" : "False"
                }
            }

            return {
                getConfigurationData: getConfigurationData,
                setConfigurationData: setConfigurationData
            };
        }]);
})();