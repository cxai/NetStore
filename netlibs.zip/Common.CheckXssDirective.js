﻿
(function () {
    "use strict";

    checkmarx.Common.directive('checkXss', ['Common.InputValidator', function (inputValidator) {
        return {
            require: 'ngModel',
            link: function (scope, elem, attr, ngModel) {

                    //For DOM -> model validation
                    ngModel.$parsers.unshift(function (value) {
                        var valid = ValidateXss(value);
                        ngModel.$setValidity('checkXss', valid);
                        return valid ? value : undefined;
                    });

                    //For model -> DOM validation
                    ngModel.$formatters.unshift(function (value) {
                        var valid = ValidateXss(value);
                        ngModel.$setValidity('checkXss', valid);
                        return value;
                    });
                
                    function ValidateXss(value) {
                        var valid = !inputValidator.checkHTMLTags(value);
                        if (valid) {
                            valid = !inputValidator.checkASCIITags(value);
                        }
                        return valid;
                };
            }
        }
    }]);
})();