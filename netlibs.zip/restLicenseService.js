﻿
(function () {
    "use strict";

    checkmarx.CxPortal.factory('restLicenseService', ['ajaxService', 'apiBaseURLService',
        function (ajaxService, apiBaseURLService) {

            function getLicenseDetails() {

                var url = apiBaseURLService.getAPIBaseURL() + '/LicenseDetails';

                return ajaxService.get(url);
            }

            return {
                getLicenseDetails: getLicenseDetails
            };
        }]);

})();