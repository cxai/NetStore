﻿(function () {
    "use strict";

    checkmarx.ProjectState.directive('newOsaScanAvailabilityIndicator', [function () {
        return {
            template: '<div class="new-osa-notification-container">' +
                        '<span class="new-osa-notification-text">' +
                            '{{ "NEW_CXOSA_SCAN_RESULT_AVAILABLE" | translate }} ' +
                            '<a href="" ng-click="reloadPage()">{{"PLEASE_REFRESH_THE_PAGE" | translate}} </a>' +
                        '</span>' +
                      '</div>',
            controller: ['$state', '$scope', function ($state, $scope) {
                $scope.reloadPage = function () {
                    $state.reload();
                }
            }]
        };
    }]);

})();