﻿
(function () {
    "use strict";

    checkmarx.CxPortal.factory('licenseService', ['ajaxService',
        function (ajaxService) {

            function getLicenseDetails() {

                var url = "api/license/getlicensedetailsdata";
                return ajaxService.get(url).then(getLicenseDetailsResponse);
            }

            function getLicenseDetailsResponse(response) {

                return response.data;
            }

            return {                
                getLicenseDetails: getLicenseDetails
            };
        }]);

})();