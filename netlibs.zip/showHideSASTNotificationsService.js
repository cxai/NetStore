﻿(function () {
    "use strict";

    checkmarx.ProjectState.factory('showHideSASTNotificationsService', ['userPreferencesService', function (userPreferencesService) {

        function shouldShow(key, propertyName, itemId) {

            var userPreferences = userPreferencesService.getUserPreferences();

            if (userPreferences && userPreferences[key]) {

                for (var i = 0; i < userPreferences[key].length; i++) {

                    if (userPreferences[key][i][propertyName] == itemId) {

                        return false;
                    }
                }
            }

            return true;
        }

        function shouldShowSASTEmptyStateModal(projectId) {

            return shouldShow("SASTEmptyStateToHide", "projectId", projectId);
        }

        function shouldShowSASTIsRunningModal(scanId) {

            return shouldShow("SASTIsRunningModalToHide", "scanId", scanId);
        }

        function shouldShowSASTNotification(scanId) {

            return shouldShow("SASTNotificationToHide", "scanId", scanId);
        }

        return {
            shouldShowSASTIsRunningModal: shouldShowSASTIsRunningModal,
            shouldShowSASTNotification: shouldShowSASTNotification,
            shouldShowSASTEmptyStateModal: shouldShowSASTEmptyStateModal
        };

    }]);

})();