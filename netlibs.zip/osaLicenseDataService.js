﻿
(function () {
    "use strict";

    checkmarx.ProjectState.factory('osaLicenseDataService', ['licenseService', function (licenseService) {

        function isOsaLicensed() {
            return licenseService.getLicenseDetails().then(getResult);
        }

        function getResult(result) {
            return result.isOsaEnabled;
        }

        return {
            isOsaLicensed: isOsaLicensed
        };

    }]);

})();