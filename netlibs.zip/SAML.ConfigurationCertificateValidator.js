﻿(function () {
    "use strict";

    checkmarx.SAML.factory('SAML.ConfigurationCertificateValidator', [ function () {

        var idpCertificateExtensions = ["crt", "cer", "cert", "pem", "der",
                                    "key", "csr", "crl", "pfx", "spc",
                                    "p7b", "p7c", "p7r", "p8", "p10", "p12"];

        var spCertificateExtensions = ["pfx", "p12"];

        var nameMaxLength = 260;

        function validateIdpCertificate(file) {
            return validate(file, idpCertificateExtensions);
        }

        function validateSpCertificate(file) {
            return validate(file, spCertificateExtensions);
        }

        function validate(file, validExtensions) {
            var isValid = false;

            if (file.name.lastIndexOf('.') > nameMaxLength) {
                return isValid;
            }

            var fileExtension = file.name.substr(file.name.lastIndexOf('.') + 1);

            for (var i = 0; i < validExtensions.length; i++) {
                if (fileExtension === validExtensions[i]) {
                    isValid = true;
                    break;
                }
            }
            return isValid;
        }        

        return {
            validateIdpCertificate: validateIdpCertificate,
            validateSpCertificate: validateSpCertificate
        };

    }]);
})();