﻿(function () {
    "use strict";

    checkmarx.CxAcademy.factory('AppSecCoach.OpenLessonLogic', [
        '$rootScope',
        'AppSecCoach.LinkType',
        'AppSecCoach.LessonsOpener',
        'AppSecCoach.DialogIDs',
        'AppSecCoach.IsFullVersionEnabledCalculator',
        function ($rootScope, linkType, lessonsOpener, appSecCoachDialogIDs, isFullVersionEnabledCalculator) {

            function open(linkData) {

                if (linkData.linkType == linkType.none) {

                    isFullVersionEnabledCalculator.calculate().then(function (result) {

                        if (result.isFullVersionEnabled) {
                            $rootScope.$broadcast('dialog-open-' + appSecCoachDialogIDs.appSecCoachLessonIsNotAvailableDialog);
                        }
                        else {
                            $rootScope.$broadcast('dialog-open-' + appSecCoachDialogIDs.appSecCoachLicenseDialog);
                        }
                    });
                }
                else if (linkData.linkType == linkType.linkToLesson) {
                    lessonsOpener.openQueryLesson(linkData.queryId);
                }
                else if (linkData.linkType == linkType.generalLink) {
                    lessonsOpener.openGeneralLessonsPage();
                }
            }

            return {
                open: open
            };

        }]);

})();