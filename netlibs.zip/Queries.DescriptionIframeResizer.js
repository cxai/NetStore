﻿
(function () {
    "use strict";

    checkmarx.Queries.directive('descriptionIframeResizer', ['$window','$rootScope', function ($window, $rootScope) {
        return {
            template: '',
            scope: {
            },
            link: function (scope, element, attrs) {

                var iframe = $('#ifQueryDescription');
               
                $rootScope.$on('iframe-content-loaded', function (evt, iframeId) {
                    updateIframeSize();
                    hideIframeOverflow();
                });
         
                angular.element($window).bind('resize', function () {
                    updateIframeSize();
                    scope.$digest();
                });

                function updateIframeSize() {
                    iframe.css('height', calculateIframeHeight());
                    iframe.css('width', '100%');
                }

                function calculateIframeHeight() {
                    var iframeContentHeight = '200px';
                    var iframeContent = iframe.contents()[0];
                    if (iframeContent) {
                        var body = iframeContent.body;
                        var doc = iframeContent.documentElement;
                        iframeContentHeight = Math.max(body.scrollHeight, body.offsetHeight, doc.clientHeight, doc.scrollHeight, doc.offsetHeight);
                    }
                    return iframeContentHeight;
                }

                function hideIframeOverflow() {
                    var iframeBody = iframe.contents().find('body');
                    iframeBody.css('overflow', 'hidden');
                    iframe.attr('scrolling', 'no');
                    iframe.attr('horizontalscrolling', 'no');
                    iframe.attr('verticalscrolling', 'no');
                }

            }
        };
    }]);
})();