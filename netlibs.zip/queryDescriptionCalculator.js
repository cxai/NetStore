﻿/// <reference path="app.js" />

(function () {
    "use strict";

    checkmarx.Queries.factory('queryDescriptionCalculator', ['queryDescriptionType', function (queryDescriptionType) {

        function isDesctiptionExists(descriptions, queryTypeId) {

            for (var i = 0; i < descriptions.length; i++) {

                if (descriptions[i]["queryTypeId"] == queryTypeId && descriptions[i]["html"] != null) {

                    return true;
                }
            }

            return false;
        }
        
        function calculate(descriptions) {

            for (var i = 0; i < descriptions.length; i++) {

                if (isDesctiptionExists(descriptions, queryDescriptionType.externals)) {
                    return descriptions[i].html;
                }
                else if (isDesctiptionExists(descriptions, queryDescriptionType.CWEDescription)) {
                    return descriptions[i].html;
                }
                else if (isDesctiptionExists(descriptions, queryDescriptionType.cxDescription)) {
                    return descriptions[i].html;
                }
            }
        }

        return {
            calculate :calculate
        };

    }]);

})();