﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />

(function () {
    "use strict";

    checkmarx.Common.factory('preventPageNavigationService', [function ($scope) {

        var beforeunload = "beforeunload";
        var onbeforeunload = "onbeforeunload";
        var handleUnloadEventFunction = null;

        function registerUnloadEvent(handleUnloadEvent) {

            handleUnloadEventFunction = handleUnloadEvent;

            if (window.addEventListener) {
                window.addEventListener(beforeunload, handleUnloadEventFunction);
            }
            else {
                window.attachEvent(onbeforeunload, handleUnloadEventFunction);
            }
        }

        function removeUnloadEvent() {

            if (window.removeEventListener) {
                window.removeEventListener(beforeunload, handleUnloadEventFunction);
            }
            else {
                window.detachEvent(onbeforeunload, handleUnloadEventFunction);
            }
        }

        return {
            registerUnloadEvent: registerUnloadEvent,
            removeUnloadEvent: removeUnloadEvent
        };

    }]);

})();