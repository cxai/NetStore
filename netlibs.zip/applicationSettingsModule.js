﻿/// <reference path="../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ApplicationSettings = angular.module('ApplicationSettings', []);

})();
