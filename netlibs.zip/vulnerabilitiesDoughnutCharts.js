﻿/// <reference path="../views/emptyStateModal.html" />
/// <reference path="vulnerabilitiesDoughnutCharts.js" />
/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.directive('vulnerabilitiesDoughnutCharts', [function () {

        return {
            template: '<div>'
                    + '     <div class="spinner spinner-widget" ng-show="vulnerabilitiesDoughnutChartsShowLoading"></div>'
                    + '     <div ng-include="templateUrl"></div>'
                    + '</div>',
            controller: ['$scope',
                '$rootScope',
                '$stateParams',
                'doughnutChartsDataBuilderService',
                'publicScanRequestsDataService',
                'scanRequestCalculatorService',
                function (
                    $scope,
                    $rootScope,
                    $stateParams,
                    doughnutChartsDataBuilderService,
                    publicScanRequestsDataService,
                    scanRequestCalculatorService) {

                    $scope.vulnerabilitiesDoughnutChartsShowLoading = true;
                    $scope.projectId = $stateParams.id;

                    function buildData() {
                        
                        doughnutChartsDataBuilderService.build($stateParams.id).then(function (result) {

                            $scope.vulnerabilitiesDoughnutChartsShowLoading = false;

                            $scope.highChartData = result.highChartData;
                            $scope.mediumChartData = result.mediumChartData;
                            $scope.lowChartData = result.lowChartData;

                            $scope.countSolvedHigh = result.highChartData.count.solved;
                            $scope.countSolvedMed = result.mediumChartData.count.solved;
                            $scope.countSolvedLow = result.lowChartData.count.solved;

                            $scope.countNewHigh = result.highChartData.count.newVulnerabilities;
                            $scope.countNewMed = result.mediumChartData.count.newVulnerabilities;
                            $scope.countNewLow = result.lowChartData.count.newVulnerabilities;

                            $scope.countRecurringHigh = result.highChartData.count.reoccured;
                            $scope.countRecurringMed = result.mediumChartData.count.reoccured;
                            $scope.countRecurringLow = result.lowChartData.count.reoccured;

                            $scope.templateUrl = 'app/projectState/views/vulnerabilitiesDoughnutCharts.html';
                        }).catch(function (result) {
                            
                            $scope.emptyChartData = doughnutChartsDataBuilderService.buildEmptyChartData();
                            $scope.templateUrl = 'app/projectState/views/vulnerabilitiesChartEmptyState.html';

                            publicScanRequestsDataService.getScanRequests($scope.projectId).then(function (scanRequests) {

                                if (scanRequests.data && scanRequests.data.length > 0) {

                                    var setUp = scanRequestCalculatorService.getScanRequestStatus(scanRequests.data);
                                    $rootScope.$broadcast('openSASTScanIsRunningModal');
                                }
                                else {
                                    $rootScope.$broadcast('openSASTEmptyStateModal');
                                }
                            });

                        });
                    }

                    buildData();
                }]
        };
    }]);

})();