﻿(function () {
    "use strict";

    checkmarx.CxPortal.factory('CxPortal.ConfigurationDataService', ['ajaxService', 'apiBaseURLService',
        function (ajaxService, apiBaseURLService) {

            var url = apiBaseURLService.getAPIBaseURL() + '/Configurations/Portal';

            function get() {
                return ajaxService.get(url);
            };

            function put(data) {
                return ajaxService.put(url, data);
            };

            return {
                get: get,
                put: put
            };

        }]);
})();