﻿/// <reference path="../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxPortal = angular.module('CxPortal', ['Common']);

})();
