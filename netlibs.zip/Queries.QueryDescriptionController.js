﻿/// <reference path="app.js" />

(function () {
    "use strict";

    checkmarx.Queries.controller('Queries.QueryDescriptionController', [
        '$rootScope',
        '$scope',
        'Queries.TabObjectsBuilderService',
        'Queries.QueryDescriptionProcessorHandler',
        'Queries.CustomDescriptionAuthorizationService',
        'ajaxService',
        'apiBaseURLService',
        'customDescriptionCommandMode',
        'queryDescriptionType',
        'Queries.CustomDescriptionButtonsCalculator',
        'Queries.CustomDescriptionDataService',
        'CxPortal.NotificationService',
        '$translate',
        function ($rootScope,
            $scope,
            tabObjectsBuilderService,
            queryDescriptionProcessorHandler,
            customDescriptionAuthorizationService,
            ajaxService,
            apiBaseURLService,
            customDescriptionCommandModeValue,
            queryDescriptionType,
            customDescriptionButtonsCalculator,
            customDescriptionDataService,
            notificationService,
            $translate) {

            $scope.htmlData = null;
            $scope.shouldShowImportButton = false;
            var isCurrentUserAuthorizeForEditCustomDescription = customDescriptionAuthorizationService.isAuthorize();
            var selectedTabData = null;

            var showEditButtonInputData = {
                selectedDescriptionTypeId: false,
                descriptions: null,
                isAuthorized: false
            };            
            var queryDescriptionCssClass = 'source-code-expanded description-frame-dynamic';
            $scope.queryDescriptionCssClass = queryDescriptionCssClass;

            $scope.deleteCustomDescriptionDialogId = "deleteCustomDescriptionDialog";
            
            $scope.deleteDescriptionDialogSetup = {
                modal: true,
                width: 391,
                resizable: false,
                show: {
                    effect: "fade", duration: 300
                },
                hide: {
                    effect: "fade", duration: 200
                }
            };

            $scope.$on('query-descriptions-loaded', function (event, descriptions) {
                $scope.descriptions = descriptions;
                setCustomDescriptionCommandMode();

                buildButtonsCalculatorData(getDefaultSelectedQueryTypeId());
                showEditButtons(customDescriptionButtonsCalculator.calculate(showEditButtonInputData));
            });

            $scope.$on('query-description-tab-clicked', function (event, tabsData) {
                selectedTabData = tabsData
                loadQueryDescription(tabsData);

                buildButtonsCalculatorData(tabsData.queryTypeId);
                showEditButtons(customDescriptionButtonsCalculator.calculate(showEditButtonInputData));
            });
            
            $scope.$on('cx-academy-displayed', function (event, args) {
                $scope.queryDescriptionCssClass = queryDescriptionCssClass + ' fixed-height';
            });

            $scope.treeItemClicked = function (input) {

                queryDescriptionProcessorHandler.runProcess(input);
                $scope.$broadcast('query-description-changed');
            };
            
            $scope.openDeleteCustomDescriptionDialog = function () {
                $rootScope.$broadcast('dialog-open-' + $scope.deleteCustomDescriptionDialogId);
            }

            $scope.closeDeleteCustomDescriptionDialog = function () {
                $rootScope.$broadcast('dialog-close-' + $scope.deleteCustomDescriptionDialogId);
            }

            $scope.deleteCustomDescription = function () {
                $scope.closeDeleteCustomDescriptionDialog();
                customDescriptionDataService.deleteCustomDescription($rootScope.currentQueryId).then(function (result) {
                    displayDeletedSuccessNotification();
                    reloadQueryDescription();
                });
            }

            $scope.shouldShowQuerySource = function () {
                /* 
                    Enable/Disable the query source based on selected tab.
                    Query source is allowed only in CWE and Cx description Tabs, or when no tabs at all.
                */
                var selectedTabQueryTypeId = getSelectedQueryTypeId();
                if (!descriptionExists() || selectedTabQueryTypeId === queryDescriptionType.cxDescription || selectedTabQueryTypeId === queryDescriptionType.CWEDescription) {
                    return true;
                }
                return false;
            }

            //#region private functions

            function descriptionExists() {
                if ($scope.descriptions && $scope.descriptions.length > 0) {
                    return true
                }            
                return false;
            }
            
            function displayDeletedSuccessNotification() {
                notificationService.success($translate.instant('CUSTOM_DESCRIPTION_DELETED'));
            }

            function reloadQueryDescription() {
                queryDescriptionProcessorHandler.runProcess($rootScope.currentQueryId);
            }

            function buildButtonsCalculatorData(queryTypeId) {

                showEditButtonInputData.selectedDescriptionTypeId = queryTypeId;
                showEditButtonInputData.descriptions = $scope.descriptions;
                showEditButtonInputData.isAuthorized = isCurrentUserAuthorizeForEditCustomDescription;

                return showEditButtonInputData;
            }

            function getDefaultSelectedQueryTypeId() {

                if ($scope.descriptions && $scope.descriptions.length > 0) {
                    return $scope.descriptions[0].queryTypeId;
                }

                return 0;
            }

            function getSelectedQueryTypeId() {
                if (selectedTabData) {
                    return selectedTabData.queryTypeId;
                } 
                return getDefaultSelectedQueryTypeId();
            }

            function isImportMode() {
                return $rootScope.customDescriptionCommandMode == customDescriptionCommandModeValue.import;
            }

            function isUpdateMode() {
                return $rootScope.customDescriptionCommandMode == customDescriptionCommandModeValue.update;
            }

            function loadQueryDescription(tabsData) {

                $rootScope.$broadcast('queryDescriptionReset');
               
                ajaxService.get(apiBaseURLService.getAPIVirtualDirectory() + tabsData.url).then(function (result) {

                    var data = {
                        queryTypeId: tabsData.queryTypeId,
                        html: null
                    };

                    if (result && result.data) {
                        data.html = result.data;
                    }

                    $rootScope.$broadcast('query-description-HTML-loaded', data);

                }).catch(function (error) {
                    $rootScope.$broadcast('query-description-HTML-loaded', "");
                });
            }

            function isCustomDescriptionFirstTab() {

                return $scope.descriptions
                        && $scope.descriptions.length > 0
                            && $scope.descriptions[0].queryTypeId == queryDescriptionType.customDescription;
            }

            function setCustomDescriptionCommandMode() {

                $rootScope.customDescriptionCommandMode = customDescriptionCommandModeValue.import;

                if (isCustomDescriptionFirstTab()) {
                    $rootScope.customDescriptionCommandMode = customDescriptionCommandModeValue.update;
                }
            }

            function showEditButtons(showEditButton) {

                $scope.shouldShowImportButton = false;
                $scope.shouldShowUpdateButton = false;

                if (showEditButton.show) {

                    if (showEditButton.buttonType == customDescriptionCommandModeValue.import) {
                        $scope.shouldShowImportButton = true;
                    }
                    else if (isUpdateMode()) {
                        $scope.shouldShowUpdateButton = true;
                    }
                }
            }

            //#endregion
        }]);

})();
