﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.value('policyViolationStatuses', {
        violated: 1,
        complaint: 2
    });

    /* compatible to server CompareStatusType enum */
    checkmarx.ProjectState.value('projectStatuses', {
        fixed: 0,
        reoccured: 1,
        new: 2
    });

    /* compatible to server Severity enum */
    checkmarx.ProjectState.value('projectSeverity', {
        info: 0,
        low: 1,
        medium: 2,
        high: 3
    });

    checkmarx.ProjectState.value('projectsCacheKeys', {
        projectStatusModel: '_projectStatusModel_',
        openSourceAnalysisModel: '_openSourceAnalysisModel_',
        lastScanByProjectIdModel: '_lastScanByProjectIdModel_'
    });

    checkmarx.ProjectState.value('projectsLocalStorageKeys', {
        userPreferences: 'userPreferences'
    });

    checkmarx.ProjectState.value('osaCurrentScanLocalStorageKey', {
        key: 'osaCurrentScanLocalStorageKey'
    });

    checkmarx.ProjectState.value('scanTypes', {
        full: 1,
        incremental: 2
    });

    checkmarx.ProjectState.value('sourceLocationType', {
        local: 0,
        shared: 1,
        sourceControl : 2,
        sourcePulling : 3
    });

    checkmarx.ProjectState.value('ProjectState.OriginType', {
        portal: 'portal',
        shared: 'shared',
        jenkins: 'jenkins',
        cli: 'cli',
        eclipse: 'eclipse',
        vs: 'vs',
        intelij: 'intelij',
        audit: 'audit',
        sdk: 'sdk',
        tfsbuild: 'tfsbuild',
        importer: 'importer',
        other: 'other',
        sonar: 'sonar',
        maven: 'maven'
    });

    checkmarx.ProjectState.value('oasVulnerabilityScore', {
        secure: 'secure',
        low: 'low',
        medium: 'medium',
        high: 'high'
    });

    checkmarx.ProjectState.value('scanRequestStage', {
        new: 1,
        prescan: 2,
        queued: 3,
        scanning: 4, /* working */
        postscan: 6,
        finished: 7, /* success */
        canceled: 8,
        failed: 9,
        sourcePullingAndDeployment: 10,
        none: 1001
    });

    checkmarx.ProjectState.value('scanRequestGeneralStages', {
        progress: 1,
        failed: 2,
        success: 3,
        cancel: 4
    });

    checkmarx.ProjectState.value('ProjectState.OSAScanProcessStatus', {
        inProgress: 1,
        finished: 2,
        failed: 3
    });

})();