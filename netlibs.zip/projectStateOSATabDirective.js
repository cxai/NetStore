﻿
(function () {

    "use strict";

    checkmarx.ProjectState.directive('projectStateOsaTab', ['osaReportDataService', '$stateParams',
        function (osaReportDataService, $stateParams) {

            return {
            
            restrict: "E",
            controller: ['$scope', '$sce', '$stateParams', function ($scope, $sce, $stateParams) {

                $scope.loading = true;
                var id = $stateParams.id;

                osaReportDataService.getOSAHTMLData(id).then(getOSAHTMLDataSuccess).catch(errorCallback);

                function getOSAHTMLDataSuccess(template) {
                    $scope.loading = false;
                    $scope.osaData = $sce.trustAsHtml(template);
                }

                function errorCallback(errorMsg) {
                    console.log('Error Message: ' + errorMsg);
                }

            }]            
        }
    }]);

}());