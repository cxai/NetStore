﻿
(function () {
    "use strict";

    checkmarx.ApplicationSettings.component('generalSettingsPanel', {
        transclude: true,
        template: '<fieldset>'
                    + '<legend>{{$ctrl.legendText}}</legend>'
                    + '<ng-transclude></ng-transclude>'
                + '</fieldset>',
        bindings: {
            legendText: '@'
        }
    });
})();