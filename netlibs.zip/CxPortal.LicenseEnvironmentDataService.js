﻿(function () {
    "use strict";

    checkmarx.CxPortal.factory('CxPortal.LicenseEnvironmentDataService', ['ajaxService', 'CxPortal.AjaxServiceWithNotification', 'apiBaseURLService',
        function (ajaxService, ajaxServiceWithNotification, apiBaseURLService) {

            var url = apiBaseURLService.getAPIVirtualDirectory() + '/License/EnvironmentData';

            function get() {

                return ajaxService.get(url);
            }

            function getWithNotification() {

                return ajaxServiceWithNotification.get(url);
            }

            function post() {

                return ajaxServiceWithNotification.post(url);
            }

            function sendDeleteRequest() {

                return ajaxServiceWithNotification.sendDeleteRequest(url);
            }

            function patch(data) {

                return ajaxServiceWithNotification.patch(url, data);
            }

            return {
                get: get,
                getWithNotification: getWithNotification,
                post: post,
                sendDeleteRequest: sendDeleteRequest,
                patch: patch
            };
        }]);

})();