var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        var C = Checkmarx.Constants;
        // Directive controller implementation
        var QueueStateWidgetDirective = (function (_super) {
            __extends(QueueStateWidgetDirective, _super);
            // Constructor (including dependencies that will be inserted automatically by angular)
            function QueueStateWidgetDirective(scope, netService) {
                // Call the server to get the widget data
                _super.call(this, netService, scope);
                this.averageWaitingTime = {}; // contains 
                this.hasScans = false;
            }
            QueueStateWidgetDirective.prototype.initializeData = function (queueStateData) {
                this.widgetData = queueStateData;
                this.scope.$emit(C.Events.DataReceived, { lastUpdated: queueStateData.data.updatedOn });
                this.convertMinutesToTime(this.widgetData.data.averageWaitingTime.value);
                this.calcScansInQueue();
            };
            QueueStateWidgetDirective.prototype.calcScansInQueue = function () {
                this.hasScans = false;
                var scansInQueue = this.widgetData.data.scansInQueue.large.value +
                    this.widgetData.data.scansInQueue.small.value +
                    this.widgetData.data.scansInQueue.medium.value;
                if (scansInQueue > 0) {
                    this.hasScans = true;
                }
            };
            QueueStateWidgetDirective.prototype.convertMinutesToTime = function (minutes) {
                var hours = Math.floor(minutes / 60);
                var min = minutes % 60;
                this.averageWaitingTime['minutes'] = min;
                this.averageWaitingTime['hours'] = hours;
            };
            // Specify the dependencies for this directive    
            QueueStateWidgetDirective.$inject = ['$scope', '#net'];
            return QueueStateWidgetDirective;
        }(Directives.BaseWidget));
        // Directive configuration
        function QueueStateWidgetDirectiveSettings() {
            return {
                restrict: 'E',
                replace: true,
                controller: QueueStateWidgetDirective,
                controllerAs: 'root',
                templateUrl: '/CxWebClient/pages/dashboard/QueueStateWidget',
                bindToController: true,
                scope: {
                    config: '='
                }
            };
        }
        Directives.QueueStateWidgetDirectiveSettings = QueueStateWidgetDirectiveSettings;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=queue-state-widget.js.map