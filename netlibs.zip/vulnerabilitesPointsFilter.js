﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.filter('vulnerabilitesPointsFilter', [function () {

        return function (input) {

            var points = parseInt(input);

            if (points === 0) {
                return points;
            }

            return points || '?';
        };
    }]);
})();