﻿(function () {
    "use strict";

    checkmarx.ProjectState.factory('projectStatePreloadedData', ['$state', function ($state) {

        this._projectDetails = null;

        function setProjectDetails(val) {

            this._projectDetails = val;
        }

        function projectDetails() {

            return this._projectDetails;
        }

        function finishedScansLatest() {

            return $state.current.statePreloadedData.finishedScansLatest;
        }

        function lastScanByProjectModel() {

            return $state.current.statePreloadedData.lastScanByProjectModel;
        }

        function osaSourceCodeOrigin() {
            return this.projectDetails().osaSourceCodeOrigin;
        }

        return {
            setProjectDetails: setProjectDetails,
            projectDetails: projectDetails,
            finishedScansLatest: finishedScansLatest,
            lastScanByProjectModel: lastScanByProjectModel,
            osaSourceCodeOrigin: osaSourceCodeOrigin
        };

    }]);

})();