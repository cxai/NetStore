﻿(function () {

    $(document).on('sweetalert-modal-closed', function () {
        deleteClosedModalFromDomOnIE10();
    });

    function deleteClosedModalFromDomOnIE10() {
        var isIE = /*@cc_on!@*/false || !!document.documentMode;
        if (isIE) {
            $('.swal-overlay').remove();
        }
    }

})();

