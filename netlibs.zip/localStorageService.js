﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.Common.factory('localStorageService', [function () {
           
        function setItem(key, item) {

            localStorage.setItem(key, item);
        }

        function getItem(key) {

            return localStorage.getItem(key);
        }

        function setJSONItem(key, item) {

            setItem(key, JSON.stringify(item));
        }

        function getJSONItem(key) {

            return JSON.parse(getItem(key));
        }
        
        function removeItem(key) {

            return localStorage.removeItem(key);
        }

        return {
            setItem: setItem,
            getItem: getItem,
            setJSONItem: setJSONItem,
            getJSONItem: getJSONItem,
            removeItem: removeItem
        };
    }]);

})();