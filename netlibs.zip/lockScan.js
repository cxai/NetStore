﻿function lockScan(scanId, successCallback) {
    swal({
        title: $("#lockScanLocalization").val(),
        text: $("#lockScanConfirmLocalization").val(),
        icon: "info",
        dangerMode: true,
        buttons: {
            cancel: {
                text: $("#cancelLocalization").val(),
                closeModal: true,
                visible: true
            },
            confirm: {
                text: $("#continueLocalization").val(),
                closeModal: true,
                visible: true
            }
        }
    }).then(
    function (isConfirm) {
        if (isConfirm) {
            $.ajax({
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                type: 'POST',
                data: '{\'scanId\':' + scanId + '}',
                url: 'WebMethods/LockScanService.asmx/LockScan',
                success: function (response) {
                    if (response.d == 'success') {
                        $("#imgLock" + scanId).addClass("unavailableAction").removeClass("availableAction");
                        $("#imgUnlock" + scanId).removeClass("unavailableAction").addClass("availableAction");
                        if (successCallback && typeof(successCallback) == "function") {
                            successCallback();
                        }                        
                        toastr.success($("#scanLockedLocalization").val());
                    }
                    else {
                        toastr.error(response);
                    }
                },
                failure: function (response) {
                    toastr.error(response);
                }
            });
        }
        $(document).trigger('sweetalert-modal-closed');
    });
}

function unlockScan(scanId, successCallback) {
    swal({
        title: $("#unlockScanLocalization").val(),
        text: $("#unlockScanConfirmLocalization").val(),
        icon: "info",
        dangerMode: true,
        buttons: {
            cancel: {
                text: $("#cancelLocalization").val(),
                closeModal: true,
                visible: true
            },
            confirm: {
                text: $("#okLocalization").val(),
                closeModal: true,
                visible: true
            }
        }
    }).then(
    function (isConfirm) {
        if (isConfirm) {
            $.ajax({
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                type: 'POST',
                data: '{\'scanId\':' + scanId + '}',
                url: 'WebMethods/LockScanService.asmx/UnlockScan',
                success: function (response) {
                    if (response.d == 'success') {
                        $("#imgLock" + scanId).removeClass("unavailableAction").addClass("availableAction");
                        $("#imgUnlock" + scanId).addClass("unavailableAction").removeClass("availableAction");
                        if (successCallback && typeof (successCallback) == "function") {
                            successCallback();
                        }
                        toastr.success($("#scanUnlockedLocalization").val());
                    }
                    else {
                        toastr.error(response);
                    }
                },
                failure: function (response) {
                    toastr.error(response);
                }
            });
        }
        $(document).trigger('sweetalert-modal-closed');
    });
}