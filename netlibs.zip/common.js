﻿var Core = {};
Core.hash = {};
Core.web = {};
Core.web.cookies = {};
Core.web.ajax = {};
Core.web.QueryString = {};
Core.REST = {};
Core.validation = {};
Core.convertion = {};

function checkFieldXSSByRegularExpression(sender, args) {
    var re = /<[!?\/a-z]|&#/gi;
    args.IsValid = !re.test(args.Value);
}

function checkXSSFieldByRegularExpressionByValue(value) {
    var re = /<[!?\/a-z]|&#/gi;
    return !re.test(value);
}

function onRequestStart(sender, args) {
    requestStart(sender, args);
}

function requestStart(sender, args) {
    var $form = $('#aspnetForm');
    var startingChars = ['<', '&'];
    var result = false;
    var summaryResult = true;
    var errorFileds = [];

    $form.find("input[type='text'], textarea").each(
        function (index) {

            var input = $(this).val();
            var fieldId = $(this).attr('id');
            input = input.toLowerCase();

            result = checkHTMLTags(input);
            if (result == true) {
                errorFileds.push(fieldId);
            }
            else {
                result = checkASCIITags(input, fieldId);
                if (result == true) {
                    errorFileds.push(fieldId);
                }
            }
            if (result == true) {
                summaryResult = false;
            }
            else {
                $(this).css('border-color', '#D7D7D7');
            }
        }
    )
    if (summaryResult == false) {
        alertError(errorFileds);
        args.set_cancel(true);
        return false;
    }
}

function alertError(errorFileds) {
    if (errorFileds.length > 0) {
        for (var i = 0; i < errorFileds.length; i++) {
            $('#' + errorFileds[i] + '').css('border-color', 'red');
        }
    }
    toastr.error("some fields are with error!");
}

function isLetter(str) {
    return str.length === 1 && str.match(/[a-z]/i);
}

function checkHTMLTags(input) {
    if (input.length > 0) {
        var index = input.indexOf('<');
        if (index >= 0) {
            var charToCheck = input.charAt(index + 1);
            if (isLetter(charToCheck) || charToCheck === '!' || charToCheck === '/' || charToCheck === '?') {
                return true;
            }
        }
    }
    return false;
}

function checkASCIITags(input) {
    if (input.length > 0) {
        var index = input.indexOf('&');
        if (index >= 0) {
            var charToCheck = input.charAt(index + 1);
            if (charToCheck === '#') {
                return true;
            }
        }
    }
    return false;
}

function checkMail(mailAddress) {
    if (mailAddress.indexOf('\\') > -1) {
        mailAddress = mailAddress.replace(/\\/g, '\\\\');
    }
    var validMailRegex = "^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)*[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$";
    if (mailAddress.match(validMailRegex) != null) {
        return true;
    }
    return false;
}

function checkURL(url) {
    var urlPattern = /^(?:(?:ftp|https?):\/\/)?(?:[a-z0-9](?:[-a-z0-9]*[a-z0-9])?\.)+(?:com|edu|biz|org|gov|int|info|mil|net|name|museum|coop|aero|[a-z][a-z])\b(?:\d+)?(?:\/[^;"'<>()\[\]{}\s\x7f-\xff]*(?:[.,?]+[^;"'<>()\[\]{}\s\x7f-\xff]+)*)?/;
    return urlPattern.test(url.toLowerCase());
}

function realPostBack(eventTarget, eventArgument) {
    __doPostBack(eventTarget, eventArgument);
}

function Grid_DoCallback(action, callBackControl, gridControl, selectionRequired) {
    if (selectionRequired) {
        if (gridControl.MasterTableView.SelectedRows.length > 0) {
            callBackControl.AjaxRequest(action);
        }
    }
    else {
        callBackControl.AjaxRequest(action);
    }
}

function OpenGridRowForUpdate(gridControl, action) {
    gridControl.AjaxRequest(action);
}

function AddToFavorite() {
    try {
        window.external.AddFavorite(location.href, 'מערכת ניהול האתר')
    }
    catch (ex) { }
}

function UpdatePictureClose() {
    try {
        if (document.getElementById("UpdatePictureButton") != null) {
            document.getElementById("UpdatePictureButton").click();
        }
    }
    catch (ex) { }
}

function SetWindowSize() {
    alert(window.dialogHeight)
    window.dialogHeight = 500;
}

function SetWindowSize(oWnd) {
    oWnd.SetSize(oWnd.GetWidth(), parseInt(oWnd.Height));
}

function CloseWindow() {
    window.close();
}

function ChangeIcon(_this) {
    if (_this.src.indexOf("Icon.gif") > 0) {
        _this.src = _this.src.replace("Icon.gif", "Download.gif");
        return true;
    }
    return false;

}

var lastOpenedWindow;

function OpenReportWindow(url) {
    //lastOpenedWindow = radopen(url, "ReportWindow");
    //lastOpenedWindow = radopen(url);
    window.open(url);
}

function CloseLastWindow() {

    if (lastOpenedWindow != null) {
        lastOpenedWindow.Hide();
        lastOpenedWindow.close();
    }

}

function OpenViewerWindow(url) {
    window.open(url);
    //lastOpenedWindow = radopen(url, "ViewerWindow");
}

function CloseTicket(id) {
    document.getElementById(id).style.display = "none";
}

function GoToLogin() {
    location = "Login.aspx";
}

function getLocationOriginURL() {

    return window.location.origin ? window.location.origin : (window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : ''));
}

// stretch document to the end of the window
function resizeContainer() {

    var ContainerStretch = document.getElementById("ContainerStretch");

    if (ContainerStretch == null)
        return;

    var Container = document.getElementById("Container");
    var htmlheight = Container.scrollHeight;
    var windowheight = getWindowHeight();

    if ((htmlheight + 20) < windowheight) {
        ContainerStretch.style.height = ((windowheight - htmlheight) - 20) + "px";
    }
    else {
        ContainerStretch.style.height = 0;
    }

}

function getWindowHeight() {
    var windowHeight = 0;
    if (typeof (window.innerHeight) == 'number') {
        windowHeight = window.innerHeight;
    }
    else {
        if (document.documentElement && document.documentElement.clientHeight) {
            windowHeight = document.documentElement.clientHeight;
        }
        else {
            if (document.body && document.body.clientHeight) {
                windowHeight = document.body.clientHeight;
            }
        }
    }
    return windowHeight;
}

window.onload = function () {
    resizeContainer();
}

window.onresize = function () {
    resizeContainer();
}

function SetBlockUI() {
    isBlockUI = true;
}

Core.hash.setJWTToken = function (data, redirectPage) {

    localStorage.setItem('JWTToken', JSON.stringify(data));
    window.location.href = redirectPage;
};

Core.isStringEmpty = function (str) {
    return (!str || 0 === str.length);
}

/* HTTP code statuses start*/

Core.web.HTTPCodeStatuses = {};
Core.web.HTTPCodeStatuses.movedPermanently = 301;
Core.web.HTTPCodeStatuses.found = 302;
Core.web.HTTPCodeStatuses.badRequest = 400;
Core.web.HTTPCodeStatuses.unauthorized = 401;
Core.web.HTTPCodeStatuses.forbidden = 403;
Core.web.HTTPCodeStatuses.notFound = 404;

/* HTTP code statuses end */

Core.REST.messageCode = {
    osaHasNotConfigured: 21052,
    LoginWrongUserNameOrPassword: 12502
};

Core.REST.restUrlPrefix = "/cxrestapi/";

Core.REST.getRestBaseUrl = function () {

    return getLocationOriginURL();
}

/* HTTP cookies start */

Core.web.cookies.getCookie = function (cookieName) {

    var name = cookieName + "=";

    var ca = document.cookie.split(';');

    for (var i = 0; i < ca.length; i++) {

        var c = ca[i];

        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }

        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }

    return "";
}

/* HTTP cookies end */

function addCXRFHeader(xhrObj) {

    if (Core.web.cookies.getCookie(_cxGlobalVariables.CXCSRFCookieName) != "") {
        xhrObj.setRequestHeader(_cxGlobalVariables.CXCSRFCookieName, Core.web.cookies.getCookie(_cxGlobalVariables.CXCSRFCookieName));
    }
}

function addCultureHeader(xhrObj) {

    if (_cxGlobalVariables.currentCulture != "") {
        xhrObj.setRequestHeader("Accept-Language", _cxGlobalVariables.currentCulture);
    }
}

function addAjaxCallHeader(xhrObj) {
    xhrObj.setRequestHeader("X-Requested-With", "XMLHttpRequest");
}

function getAppVersionNumber() {

    var str = _cxGlobalVariables.cxAppVersionNumber;
    var numberPattern = /\d+/g;
    var versionNumberArray = null;

    if (str != null) {

        versionNumberArray = str.match(numberPattern);
    }

    if (versionNumberArray != null && versionNumberArray.length > 0) {

        str = versionNumberArray.join('.');
    }
    else {
        str = "";
    }

    return str;
}

function addCxOriginHeader(xhrObj) {
    xhrObj.setRequestHeader("cxOrigin", 'cx-WebPortal/' + getAppVersionNumber());
}


/* ajax start */

Core.web.ajax.baseRequest = function (ajaxParams) {

    var paramsToSend = {
        contentType: ajaxParams.contentType,
        dataType: ajaxParams.dataType,
        url: ajaxParams.url,
        data: ajaxParams.data,
        crossDomain: true,
        beforeSend: function (xhrObj) {
            addCXRFHeader(xhrObj);
            addCultureHeader(xhrObj);
            addAjaxCallHeader(xhrObj);
            addCxOriginHeader(xhrObj);
        },
        xhrFields: {
            withCredentials: true
        },
        success: function (response) {
            ajaxParams.success(response);
        },
        error: function (xhr, status, error) {
            ajaxParams.error(xhr, status, error);
        },
        failure: function (response) {
            ajaxParams.failure(response);
        }
    };

    if (!ajaxParams.contentType) {
        delete paramsToSend["contentType"];
    }

    if (!ajaxParams.dataType) {
        delete paramsToSend["dataType"];
    }

    return paramsToSend;
};

Core.web.ajax.post = function (ajaxParams) {

    var paramsToSend = Core.web.ajax.baseRequest(ajaxParams);
    paramsToSend.type = 'POST';
    $.ajax(paramsToSend);
};

Core.web.ajax.get = function (ajaxParams) {

    var paramsToSend = Core.web.ajax.baseRequest(ajaxParams);
    paramsToSend.type = 'GET';
    $.ajax(paramsToSend);
};

/* ajax end */

/* browsers start */

Core.Browsers = {};

Core.Browsers.userAgentNavigator = function (userAgentName) {
    return navigator.userAgent.toLowerCase().indexOf(userAgentName) > -1;
};

Core.Browsers.getInternetExplorerVersionAsFloat = function () {

    var ieVersion, userAgent, regExp;
    ieVersion = -1;

    if (navigator.appName == 'Microsoft Internet Explorer') {

        userAgent = navigator.userAgent;
        regExp = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");

        if (regExp.exec(userAgent) != null) {
            ieVersion = parseFloat(RegExp.$1);
        }
    }
    else if (navigator.appName == 'Netscape') {

        userAgent = navigator.userAgent;
        regExp = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");

        if (regExp.exec(userAgent) != null) {
            ieVersion = parseFloat(RegExp.$1);
        }
    }

    return ieVersion;
};

Core.Browsers.isChrome = function () {
    return Core.Browsers.userAgentNavigator('chrome');
};

Core.Browsers.isFireFox = function () {
    return Core.Browsers.userAgentNavigator('firefox');
};

Core.Browsers.isIE = function () {
    return Core.Browsers.userAgentNavigator('msie') || Core.Browsers.userAgentNavigator('msie');
};

Core.Browsers.isIE8 = function () {

    if (Core.Browsers.getInternetExplorerVersionAsFloat() == 8.0) {

        return true;
    }

    return false;
};

Core.Browsers.isIE9 = function () {

    if (Core.Browsers.getInternetExplorerVersionAsFloat() == 9.0) {

        return true;
    }

    return false;
};

Core.Browsers.isIE10 = function () {

    if (Core.Browsers.getInternetExplorerVersionAsFloat() == 10.0) {

        return true;
    }

    return false;
};

Core.Browsers.isIE11 = function () {

    var version = Core.Browsers.getInternetExplorerVersionAsFloat();

    if (version >= 11.0 && version < 12.0) {

        return true;
    }

    return false;
};

/* browsers end */

Core.web.QueryString.getParameterByName = function (name, url) {

    if (!url) {
        url = window.location.href;
    }

    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)");
    var results = regex.exec(url);

    if (!results) {
        return null;
    }

    if (!results[2]) {
        return '';
    }

    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

Core.web.QueryString.isParameterExists = function (name, url) {

    var result = Core.web.QueryString.getParameterByName(name, url);

    if (result && result !== '') {
        return true;
    }

    return false;
}


/* locale start */

var LOCALE_DATE_FORMATS = {

    "ar-SA": "dd/MM/yy",
    "bg-BG": "dd.M.yyyy",
    "ca-ES": "dd/MM/yyyy",
    "zh-TW": "yyyy/M/d",
    "cs-CZ": "d.M.yyyy",
    "da-DK": "dd-MM-yyyy",
    "de-DE": "dd.MM.yyyy",
    "el-GR": "d/M/yyyy",
    "en-US": "M/d/yyyy",
    "fi-FI": "d.M.yyyy",
    "fr-FR": "dd/MM/yyyy",
    "he-IL": "dd/MM/yyyy",
    "hu-HU": "yyyy. MM. dd.",
    "is-IS": "d.M.yyyy",
    "it-IT": "dd/MM/yyyy",
    "ja-JP": "yyyy/MM/dd",
    "ko-KR": "yyyy-MM-dd",
    "nl-NL": "d-M-yyyy",
    "nb-NO": "dd.MM.yyyy",
    "pl-PL": "yyyy-MM-dd",
    "pt-BR": "d/M/yyyy",
    "ro-RO": "dd.MM.yyyy",
    "ru-RU": "dd.MM.yyyy",
    "hr-HR": "d.M.yyyy",
    "sk-SK": "d. M. yyyy",
    "sq-AL": "yyyy-MM-dd",
    "sv-SE": "yyyy-MM-dd",
    "th-TH": "d/M/yyyy",
    "tr-TR": "dd.MM.yyyy",
    "ur-PK": "dd/MM/yyyy",
    "id-ID": "dd/MM/yyyy",
    "uk-UA": "dd.MM.yyyy",
    "be-BY": "dd.MM.yyyy",
    "sl-SI": "d.M.yyyy",
    "et-EE": "d.MM.yyyy",
    "lv-LV": "yyyy.MM.dd.",
    "lt-LT": "yyyy.MM.dd",
    "fa-IR": "MM/dd/yyyy",
    "vi-VN": "dd/MM/yyyy",
    "hy-AM": "dd.MM.yyyy",
    "az-Latn-AZ": "dd.MM.yyyy",
    "eu-ES": "yyyy/MM/dd",
    "mk-MK": "dd.MM.yyyy",
    "af-ZA": "yyyy/MM/dd",
    "ka-GE": "dd.MM.yyyy",
    "fo-FO": "dd-MM-yyyy",
    "hi-IN": "dd-MM-yyyy",
    "ms-MY": "dd/MM/yyyy",
    "kk-KZ": "dd.MM.yyyy",
    "ky-KG": "dd.MM.yy",
    "sw-KE": "M/d/yyyy",
    "uz-Latn-UZ": "dd/MM yyyy",
    "tt-RU": "dd.MM.yyyy",
    "pa-IN": "dd-MM-yy",
    "gu-IN": "dd-MM-yy",
    "ta-IN": "dd-MM-yyyy",
    "te-IN": "dd-MM-yy",
    "kn-IN": "dd-MM-yy",
    "mr-IN": "dd-MM-yyyy",
    "sa-IN": "dd-MM-yyyy",
    "mn-MN": "yy.MM.dd",
    "gl-ES": "dd/MM/yy",
    "kok-IN": "dd-MM-yyyy",
    "syr-SY": "dd/MM/yyyy",
    "dv-MV": "dd/MM/yy",
    "ar-IQ": "dd/MM/yyyy",
    "zh-CN": "yyyy/M/d",
    "de-CH": "dd.MM.yyyy",
    "en-GB": "dd/MM/yyyy",
    "es-MX": "dd/MM/yyyy",
    "fr-BE": "d/MM/yyyy",
    "it-CH": "dd.MM.yyyy",
    "nl-BE": "d/MM/yyyy",
    "nn-NO": "dd.MM.yyyy",
    "pt-PT": "dd-MM-yyyy",
    "sr-Latn-CS": "d.M.yyyy",
    "sv-FI": "d.M.yyyy",
    "az-Cyrl-AZ": "dd.MM.yyyy",
    "ms-BN": "dd/MM/yyyy",
    "uz-Cyrl-UZ": "dd.MM.yyyy",
    "ar-EG": "dd/MM/yyyy",
    "zh-HK": "d/M/yyyy",
    "de-AT": "dd.MM.yyyy",
    "en-AU": "d/MM/yyyy",
    "es-ES": "dd/MM/yyyy",
    "fr-CA": "yyyy-MM-dd",
    "sr-Cyrl-CS": "d.M.yyyy",
    "ar-LY": "dd/MM/yyyy",
    "zh-SG": "d/M/yyyy",
    "de-LU": "dd.MM.yyyy",
    "en-CA": "dd/MM/yyyy",
    "es-GT": "dd/MM/yyyy",
    "fr-CH": "dd.MM.yyyy",
    "ar-DZ": "dd-MM-yyyy",
    "zh-MO": "d/M/yyyy",
    "de-LI": "dd.MM.yyyy",
    "en-NZ": "d/MM/yyyy",
    "es-CR": "dd/MM/yyyy",
    "fr-LU": "dd/MM/yyyy",
    "ar-MA": "dd-MM-yyyy",
    "en-IE": "dd/MM/yyyy",
    "es-PA": "MM/dd/yyyy",
    "fr-MC": "dd/MM/yyyy",
    "ar-TN": "dd-MM-yyyy",
    "en-ZA": "yyyy/MM/dd",
    "es-DO": "dd/MM/yyyy",
    "ar-OM": "dd/MM/yyyy",
    "en-JM": "dd/MM/yyyy",
    "es-VE": "dd/MM/yyyy",
    "ar-YE": "dd/MM/yyyy",
    "en-029": "MM/dd/yyyy",
    "es-CO": "dd/MM/yyyy",
    "ar-SY": "dd/MM/yyyy",
    "en-BZ": "dd/MM/yyyy",
    "es-PE": "dd/MM/yyyy",
    "ar-JO": "dd/MM/yyyy",
    "en-TT": "dd/MM/yyyy",
    "es-AR": "dd/MM/yyyy",
    "ar-LB": "dd/MM/yyyy",
    "en-ZW": "M/d/yyyy",
    "es-EC": "dd/MM/yyyy",
    "ar-KW": "dd/MM/yyyy",
    "en-PH": "M/d/yyyy",
    "es-CL": "dd-MM-yyyy",
    "ar-AE": "dd/MM/yyyy",
    "es-UY": "dd/MM/yyyy",
    "ar-BH": "dd/MM/yyyy",
    "es-PY": "dd/MM/yyyy",
    "ar-QA": "dd/MM/yyyy",
    "es-BO": "dd/MM/yyyy",
    "es-SV": "dd/MM/yyyy",
    "es-HN": "dd/MM/yyyy",
    "es-NI": "dd/MM/yyyy",
    "es-PR": "dd/MM/yyyy",
    "am-ET": "d/M/yyyy",
    "tzm-Latn-DZ": "dd-MM-yyyy",
    "iu-Latn-CA": "d/MM/yyyy",
    "sma-NO": "dd.MM.yyyy",
    "mn-Mong-CN": "yyyy/M/d",
    "gd-GB": "dd/MM/yyyy",
    "en-MY": "d/M/yyyy",
    "prs-AF": "dd/MM/yy",
    "bn-BD": "dd-MM-yy",
    "wo-SN": "dd/MM/yyyy",
    "rw-RW": "M/d/yyyy",
    "qut-GT": "dd/MM/yyyy",
    "sah-RU": "MM.dd.yyyy",
    "gsw-FR": "dd/MM/yyyy",
    "co-FR": "dd/MM/yyyy",
    "oc-FR": "dd/MM/yyyy",
    "mi-NZ": "dd/MM/yyyy",
    "ga-IE": "dd/MM/yyyy",
    "se-SE": "yyyy-MM-dd",
    "br-FR": "dd/MM/yyyy",
    "smn-FI": "d.M.yyyy",
    "moh-CA": "M/d/yyyy",
    "arn-CL": "dd-MM-yyyy",
    "ii-CN": "yyyy/M/d",
    "dsb-DE": "d. M. yyyy",
    "ig-NG": "d/M/yyyy",
    "kl-GL": "dd-MM-yyyy",
    "lb-LU": "dd/MM/yyyy",
    "ba-RU": "dd.MM.yy",
    "nso-ZA": "yyyy/MM/dd",
    "quz-BO": "dd/MM/yyyy",
    "yo-NG": "d/M/yyyy",
    "ha-Latn-NG": "d/M/yyyy",
    "fil-PH": "M/d/yyyy",
    "ps-AF": "dd/MM/yy",
    "fy-NL": "d-M-yyyy",
    "ne-NP": "M/d/yyyy",
    "se-NO": "dd.MM.yyyy",
    "iu-Cans-CA": "d/M/yyyy",
    "sr-Latn-RS": "d.M.yyyy",
    "si-LK": "yyyy-MM-dd",
    "sr-Cyrl-RS": "d.M.yyyy",
    "lo-LA": "dd/MM/yyyy",
    "km-KH": "yyyy-MM-dd",
    "cy-GB": "dd/MM/yyyy",
    "bo-CN": "yyyy/M/d",
    "sms-FI": "d.M.yyyy",
    "as-IN": "dd-MM-yyyy",
    "ml-IN": "dd-MM-yy",
    "en-IN": "dd-MM-yyyy",
    "or-IN": "dd-MM-yy",
    "bn-IN": "dd-MM-yy",
    "tk-TM": "dd.MM.yy",
    "bs-Latn-BA": "d.M.yyyy",
    "mt-MT": "dd/MM/yyyy",
    "sr-Cyrl-ME": "d.M.yyyy",
    "se-FI": "d.M.yyyy",
    "zu-ZA": "yyyy/MM/dd",
    "xh-ZA": "yyyy/MM/dd",
    "tn-ZA": "yyyy/MM/dd",
    "hsb-DE": "d. M. yyyy",
    "bs-Cyrl-BA": "d.M.yyyy",
    "tg-Cyrl-TJ": "dd.MM.yy",
    "sr-Latn-BA": "d.M.yyyy",
    "smj-NO": "dd.MM.yyyy",
    "rm-CH": "dd/MM/yyyy",
    "smj-SE": "yyyy-MM-dd",
    "quz-EC": "dd/MM/yyyy",
    "quz-PE": "dd/MM/yyyy",
    "hr-BA": "d.M.yyyy.",
    "sr-Latn-ME": "d.M.yyyy",
    "sma-SE": "yyyy-MM-dd",
    "en-SG": "d/M/yyyy",
    "ug-CN": "yyyy-M-d",
    "sr-Cyrl-BA": "d.M.yyyy",
    "es-US": "M/d/yyyy"
};

var LANG = window.navigator.userLanguage || window.navigator.language;

var LOCALE_DATE_FORMAT = LOCALE_DATE_FORMATS[LANG] || 'dd/MM/yyyy';

function getLocalizedDate(o, options) {

    var res = '';
    var date = new Date(o);

    if (o != null && !isNaN(date) && typeof (date.getFullYear) == 'function') {

        var d = date.getDate();
        var dd = d < 10 ? '0' + d : d;
        var M = date.getMonth() + 1;
        var MM = M < 10 ? '0' + M : M;
        var yyyy = date.getFullYear();
        var yy = new String(yyyy).substring(2);

        var format = LOCALE_DATE_FORMAT;

        if (options && options.lang)
            format = LOCALE_DATE_FORMATS[options.lang];
        else if (options && options.format)
            format = options.format;

        res = format
            .replace(/dd/g, dd)
            .replace(/d/g, d)
            .replace(/MM/g, MM)
            .replace(/M/g, M)
            .replace(/yyyy/g, yyyy)
            .replace(/yy/g, yy);
    }

    return res;
}

/* locale end */

Core.validation.vlidateFileExtension = function (fileName, validFileExtensions) {

    if (fileName.length > 0) {

        for (var i = 0; i < validFileExtensions.length; i++) {

            var sCurExtension = validFileExtensions[i];

            if (fileName.substr(fileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                return true;
            }
        }
    }

    return false;
};

Core.convertion.megabytesToBytes = function (megabytes) {

    var oneMegaInBytes = 1000000;

    return (megabytes * oneMegaInBytes);
};
