﻿(function () {
    "use strict";

    checkmarx.CxPortal.value('restAPIErrorMessageCodes', {
        osaHasNotConfigured: 21052,
        LoginWrongUserNameOrPassword: 12502,
        LoginPasswordHasToBeChanged: 25007
    });

    checkmarx.CxPortal.value('portalPageURLs', {
        login: "login.aspx",
        pageNotFound: "ErrorPages/404.aspx"
    });

    checkmarx.CxPortal.value('portalCookieNames', {
        CXCSRFToken: 'CXCSRFToken'
    });

    checkmarx.CxPortal.value('portalHeaderNames', {
        cxOrigin: 'cxOrigin',
        CXCSRFToken: 'CXCSRFToken'
    });

    checkmarx.CxPortal.constant("spaPagesGroups", {
        "dashboard": 0,
        "projectState": 1,
        "SAML": 2,
        "applicationSettings": 3
    });

    checkmarx.CxPortal.constant("cxPortalRoles", {
        reviewer: "reviewer",
        scanner: "scanner"
    });

    checkmarx.CxPortal.constant("cxPortalRolesPrivileges", {
        allowProjectAndScanDelete: 0,
        allowNotExploitable: 1,
        allowSeverityAndStatusChanges: 2
    });

    checkmarx.CxPortal.constant("authorizationNeeded", {
        admin: 0
    });

})();