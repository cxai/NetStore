﻿
(function () {

    "use strict";

    checkmarx.ProjectState.directive('byStateStatusWidget', ['chartConfigurationDataService', 'chartColumnDataNames',
        function (chartConfigurationDataService, chartColumnDataNames) {
            return {
                templateUrl: "/CxWebClient/app/projectState/views/byStateWidget.html",
                restrict: "E",
                controller: ['$rootScope',
                            '$scope',
                            '$stateParams',
                            '$state',
                            '$translate',
                            '$timeout',
                            'lastScanByProjectLoader',
                            function ($rootScope,
                                      $scope,
                                      $stateParams,
                                      $state,
                                      $translate,
                                      $timeout,
                                      lastScanByProjectLoader) {

                    $scope.byStateShowLoading = true;
                    var projectId = $stateParams.id;
                    $scope.chartConfig = chartConfigurationDataService.stackedBarChartconfig;

                    var lastScanByProjectWithNoCache = true;
                    lastScanByProjectLoader.load(projectId, lastScanByProjectWithNoCache).then(renderWidget).catch(noData);

                    function noData(err) {
                        $scope.byStateShowLoading = false;
                        var valueList = [[0, 0, 0],[0, 0, 0],[0, 0, 0]];
                        setChart(100, 20, valueList);
                    };

                    function renderWidget(result) {
                        $scope.byStateShowLoading = false;
                        var data = result.resultDistribution;
                        var valuesList = [];
                        var maxValue = 0;
                        var res = {};

                        calculateValues(data, valuesList);
                        maxValue = getHighestValue(valuesList);
                        res = calculateTopValueAndInterval(maxValue);
                        setChart(res.topValue, res.intervalValue, valuesList);
                    };

                    function calculateValues(data, valuesList) {
                        var currentList = [];
                        var i, j;
                        var fixedId = 0;
                        var recurrentId = 1;
                        var id;
                        var count;


                        for (i = 0; i < data[0].statuses.length; i++) {
                            j = 0;
                            currentList = [];

                            for (j = 0; j < data[0].statuses.length; j++) {
                                var id = data[i].statuses[j].id;
                                var count = data[i].statuses[j].count;

                                currentList[id] = count;
                            }

                            valuesList[data[i].severity.id - 1] = currentList;
                        }
                    };

                    function getHighestValue(valuesList) {
                        var i = 0, j = 0;
                        var maxValue = 0, solvedAndRecurrent = 0, recurrentAndNew = 0;
                        for (i; i < valuesList.length; i++) {
                            solvedAndRecurrent = (valuesList[i][0] + valuesList[i][1]);
                            recurrentAndNew = (valuesList[i][1] + valuesList[i][2]);
                            if ( solvedAndRecurrent > maxValue) {
                                maxValue = solvedAndRecurrent;
                            }
                            if (recurrentAndNew > maxValue) {
                                maxValue = recurrentAndNew;
                            }
                        }
                        return maxValue;
                    };
                    
                    var amountOfSpacesBetweenBars = 5;
                    function calculateTopValueAndInterval(maxValue) {
                        if (maxValue == 0) {
                            return {
                                topValue: 100,
                                intervalValue: 20
                            }
                        }                   
                        var fivePercentMore = maxValue + (maxValue * 0.05);
                        var topValue = roundTheNumber(fivePercentMore);

                        var intervalValue = calculateIntervalValue(topValue);
                        topValue = (intervalValue * amountOfSpacesBetweenBars);

                        return {
                            topValue: topValue,
                            intervalValue: intervalValue
                        }
                    };

                    function calculateIntervalValue(topValue) {
                        var interval = Math.floor(topValue / amountOfSpacesBetweenBars);
                        return roundTheNumber(interval);
                    };
                    
                    function roundTheNumber(number) {
                        var valueWithoutLastDigit = Math.floor(number / 10);
                        return (valueWithoutLastDigit * 10) + 10;
                    };

                    function checkIfHasPreviousScan(valuesList) {
                        return (hasSolvedResults(valuesList) || hasRecurrentResults(valuesList));
                    };

                    function hasSolvedResults(valuesList) {
                        return (valuesList[2][0] != 0 || valuesList[1][0] != 0 || valuesList[0][0] != 0);
                    };

                    function hasRecurrentResults(valuesList) {
                        return (valuesList[2][1] != 0 || valuesList[1][1] != 0 || valuesList[0][1] != 0);
                    };

                    function hasNewResults(valuesList) {
                        return (valuesList[2][2] != 0 || valuesList[1][2] != 0 || valuesList[0][2] != 0)
                    };

                    function setChart(topValue, intervalValue, valuesList) {
                        $scope.chartConfig.xAxis = {
                            lineWidth: 0,
                            tickWidth: 0,
                            categories: [$translate.instant('HIGH').toUpperCase(),
                                         $translate.instant('MED').toUpperCase(),
                                         $translate.instant('LOW').toUpperCase()]
                        };

                        $scope.chartConfig.yAxis.max = topValue;
                        $scope.chartConfig.yAxis.tickInterval = intervalValue;
                        var hasPreviousScan = checkIfHasPreviousScan(valuesList);
                       
                        $scope.chartConfig.series = [{
                            name: $translate.instant(chartColumnDataNames.Solved),
                            data: [valuesList[2][0], valuesList[1][0], valuesList[0][0]],
                            stack: hasPreviousScan ? 'prev' : 'one',
                            color: '#d2d4d8',
                            borderColor: '#b1cc49',
                            dashStyle: 'dash',
                            borderWidth: 1.5,
                            legendIndex: 2
                        }, {
                            name: $translate.instant(chartColumnDataNames.PrevScan), //recurrent
                            data: [valuesList[2][1], valuesList[1][1], valuesList[0][1]],
                            stack: hasPreviousScan ? 'prev' : 'one',
                            color: '#d2d4d8',
                            legendIndex: 1
                        }, {
                            name: $translate.instant(chartColumnDataNames.New),
                            data: [{
                                y: valuesList[2][2],
                                color: '#e14d4d'
                            },
                            {
                                y: valuesList[1][2],
                                color: '#ffc000'
                            },
                            {
                                y: valuesList[0][2],
                                color: '#fff200'
                            }],
                            stack: hasPreviousScan ? 'current' : 'one',
                            showInLegend: false
                        }, {
                            name: $translate.instant(chartColumnDataNames.Recurrent),
                            data: [{
                                y: valuesList[2][1],
                                color: 'url(#high-recurrent)'
                             },
                            {
                                y: valuesList[1][1],
                                color: 'url(#medium-recurrent)'
                            },
                            {
                                y: valuesList[0][1],
                                color: 'url(#low-recurrent)'
                            }],
                            stack: hasPreviousScan ? 'current' : 'one',
                            color: 'url(#recurrent)',
                            legendIndex: 3
                        }];
                    };
                    
                }]
            }
    }]);
}());