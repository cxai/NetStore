﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('runSASTDataService', ['ajaxService', function (ajaxService) {

        function getProjectSourceLocationType(projectId) {

            var url = "/cxwebclient/api/projects/" + projectId + "/sourcelocationtype";

            return ajaxService.get(url);
        }

        function runProject(projectId, scanType, scanLocation) {

            var url = "/cxwebclient/api/sast/runscan";

            return ajaxService.post(url, {
                projectId: projectId,
                scanType: scanType,
                scanLocation: scanLocation
            });
        }

        return {
            getProjectSourceLocationType: getProjectSourceLocationType,
            runProject: runProject
        };

    }]);

})();