﻿(function () {
    "use strict";
    checkmarx.ProjectState.controller('ProjectState.MainProjectStateController', [
        '$translate',
        '$rootScope',
        '$scope',
        '$stateParams',
        'osaLicenseDataService',
        'osaAuthorizationService',
        'CxPortal.ConfigurationDataService',
        'FileSaver',
        'osaReportDataService',
            function (
                $translate,
                $rootScope,
                $scope,
                $stateParams,
                osaLicenseDataService,
                osaAuthorizationService,
                configurationDataService,
                FileSaver,
                osaReportDataService) {

                this.summary = $translate.instant('SUMMARY');
                this.osa = $translate.instant('OSA');
                this.scansHistory = $translate.instant('SCANS_HISTORY');
                this.id = $stateParams.id;
                var projectId = $stateParams.id;
                $rootScope.showOSATab = false;
                $rootScope.NoOSAAnalysisDataYet = $rootScope.NoOSAAnalysisDataYet === undefined ? true : $rootScope.NoOSAAnalysisDataYet;
                $scope.isOpenBetaViewerItemEnabled = false;
                $scope.betaViewerURL = "";

                osaLicenseDataService.isOsaLicensed().then(function (result) {

                    $rootScope.isOsaLicensed = result;
                });

                $rootScope.$watch('[NoOSAAnalysisDataYet,isOsaLicensed]', function () {

                    $rootScope.showOSATab = !$rootScope.NoOSAAnalysisDataYet && $rootScope.isOsaLicensed;
                    if ($rootScope.isOsaLicensed !== undefined) {
                        osaAuthorizationService.checkAuthorization($rootScope.isOsaLicensed);
                    }
                });

                $scope.downloadPDF = function () {

                    $scope.spinnerPDFLoading = true;

                    osaReportDataService.getOSAReportPDF(projectId).then(function (result) {
                        getOSAReportPDFSuccess(result);
                    })
                    .catch(function (error) {
                        $scope.spinnerPDFLoading = false;
                    });
                }

                function getOSAReportPDFSuccess(data) {

                    var file = new window.Blob(([data]), {
                        type: 'application/pdf'
                    });

                    FileSaver.saveAs(file, "OSA-Report.pdf");
                    $scope.spinnerPDFLoading = false;
                }


                function loadFeatureFlagOpenBetaViewer() {
                    configurationDataService.get().then(featureFlagSuccessCallback);
                }


                function featureFlagSuccessCallback(result) {

                    if (result.data.enableOpenBetaViewer && result.data.enableOpenBetaViewer.toLowerCase() === 'true') {
                        buildBetaViewerURL();
                        $scope.isOpenBetaViewerItemEnabled = true;
                    }

                }

                function buildBetaViewerURL() {
                    $scope.betaViewerURL = '/CxWebClient/SPA/#/viewer/project/' + projectId;
                }


                loadFeatureFlagOpenBetaViewer();
            }]);

}());