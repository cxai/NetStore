var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        var RadialGaugeDirective = (function (_super) {
            __extends(RadialGaugeDirective, _super);
            // Constructor (including dependencies that will be inserted automatically by angular)
            function RadialGaugeDirective(netService, scope, element, $timeout) {
                var _this = this;
                _super.call(this, netService, scope);
                this.element = element;
                this.$timeout = $timeout;
                this.currentHeight = null;
                this.registerWatch(this.scope, function () { return _this.widgetData; }, function () {
                    _this.timeoutInstance = _this.$timeout(function () {
                        _this.createChart();
                        _this.$timeout.cancel(_this.timeoutInstance);
                        _this.timeoutInstance = undefined;
                    });
                });
                this.scope.$on("$destroy", function () {
                    if (_this.timeoutInstance) {
                        _this.$timeout.cancel(_this.timeoutInstance);
                        _this.timeoutInstance = undefined;
                    }
                });
            }
            RadialGaugeDirective.prototype.createChart = function () {
                this.element.radialGauge({
                    gaugeColors: ['#92d231'],
                    centerColor: '#f9f9f9',
                    centerBorderColor: '#e7eaeb',
                    fontColor: '#4c4b57',
                    values: [this.getPrecentageValue()],
                    innerText: {
                        value: this.widgetData.data.value.value,
                        suffix: this.widgetData.data.value.label
                    },
                    outerText: {
                        prefix: this.widgetData.data.outOfLabel,
                        value: this.widgetData.data.total.value,
                        suffix: this.widgetData.data.total.label
                    },
                    fontFamily: 'Roboto Condensed, Sans-Serif',
                    responsive: true,
                    hoverable: false,
                    animate: true
                });
            };
            RadialGaugeDirective.prototype.getPrecentageValue = function () {
                return (this.widgetData.data.value.value / Math.max(this.widgetData.data.total.value, 1)) * 100;
            };
            // Specify the dependencies for this directive    
            RadialGaugeDirective.$inject = ['#net', '$scope', '$element', '$timeout'];
            return RadialGaugeDirective;
        }(Directives.BaseWidget));
        // Directive configuration
        function RadialGaugeDirectiveSettings($timeout) {
            var that = this;
            return {
                restrict: 'E',
                replace: true,
                controller: RadialGaugeDirective,
                controllerAs: 'root',
                template: '<div class="widget radial-gauge-widget"></div>',
                bindToController: true,
                scope: {
                    config: '=',
                }
            };
        }
        Directives.RadialGaugeDirectiveSettings = RadialGaugeDirectiveSettings;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=radial-gauge.js.map