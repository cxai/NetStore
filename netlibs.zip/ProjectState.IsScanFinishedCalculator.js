﻿/// <reference path="../../../../app.js" />
/// <reference path="../../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('ProjectState.IsScanFinishedCalculator', [function () {

        function calculate(oldScanList, newScanList) {

            var result = { isAllScansFinished: false };

            for (var i = 0; i < oldScanList.length; i++) {

                var isFound = false;
                var oldScanId = oldScanList[i].scanId;

                for (var k = 0; k < newScanList.length; k++) {

                    if (newScanList[k]["scanId"]) {

                        var newScanId = newScanList[k].scanId;

                        if (oldScanId == newScanId) {
                            isFound = true;
                            
                            return result;
                        }
                    }
                }

                if (isFound == false) {

                    return {
                        isAllScansFinished: true
                    };
                }
            }

            return result;
        }

        return {
            calculate: calculate
        };

    }]);
})();