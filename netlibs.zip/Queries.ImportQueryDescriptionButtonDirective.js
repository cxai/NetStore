﻿/// <reference path="app.js" />

(function () {
    "use strict";

    checkmarx.Queries.directive('importQueryDescriptionButton',
        [function () {

            return {
                restrict: 'E',
                template: '<button type="button" class="import-button position-right"'
                            + 'ng-click="importQueryDiscription()"> <img src="app/styles/images/plus-symbol.png" class="plus-symbol" /> '
                            + '{{"IMOPRT_QUERY_DESCRIPTION" | translate}}'
                        + '</button>',
                scope: {},
                controller: ['$rootScope', '$scope', function ($rootScope, $scope) {

                    $scope.importQueryDiscription = function () {
                        $rootScope.$broadcast('dialog-open', 'import');
                    };
                }]
            };
        }]);
})();