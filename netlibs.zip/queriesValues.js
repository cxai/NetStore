﻿(function () {
    "use strict";

    checkmarx.Queries.value('queryDescriptionType', {
        cxDescription: 1,
        CWEDescription: 2,
        externals: 3,
        customDescription: 4
    });

    checkmarx.Queries.value('customDescriptionCommandMode', {
        import: 1,
        update: 2
    });

})();