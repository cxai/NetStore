﻿(function () {
    "use strict";

    checkmarx.Queries.factory('Queries.TabObjectsBuilderService', ['$translate', 'queryDescriptionType', 'ajaxService', 'apiBaseURLService', '$q',
		function ($translate, queryDescriptionType, ajaxService, apiBaseURLService, $q) {

		    function getDescription(title, url, queryTypeId) {

		        return {
		            title: $translate.instant(title),
		            url: url,
		            queryTypeId: queryTypeId
		        };
		    }

		    function tryLoadExternalDescription(descriptions) {

		        var url = apiBaseURLService.getAPIVirtualDirectory() + descriptions.externals.teamMentor;

		        return ajaxService.get(url);
		    }

		    function continueLoading(descriptions, isTeamMentorExists, deferred) {

		        var isCWEEnable = true, tabObjects = [];

		        if (descriptions.customDescription) {
		            tabObjects.push(getDescription('CUSTOM_DESCRIPTION', descriptions.customDescription, queryDescriptionType.customDescription));
		        }

		        if (isTeamMentorExists && descriptions.externals && descriptions.externals.teamMentor) {

		            tabObjects.push(getDescription('TEAM_MENTOR', descriptions.externals.teamMentor, queryDescriptionType.externals));
		        }

		        if (descriptions.cx) {
		            tabObjects.push(getDescription('CX_DESCRIPTION', descriptions.cx, queryDescriptionType.cxDescription));
		            isCWEEnable = false;
		        }

		        if (isCWEEnable && descriptions.cwe) {
		            tabObjects.push(getDescription('CWE_DESCRIPTION', descriptions.cwe, queryDescriptionType.CWEDescription));
		        }

                deferred.resolve(tabObjects);
		    }

		    function calculate(descriptions) {

                var deferred = $q.defer();
		        if (descriptions) {
		            if (descriptions.externals && descriptions.externals.teamMentor) {
		                tryLoadExternalDescription(descriptions).then(function () {
		                    continueLoading(descriptions, true, deferred);
		                }).catch(function () {
		                    continueLoading(descriptions, false, deferred);
		                });
		            }
		            else {
		                continueLoading(descriptions, false, deferred);
		            }
		        }
               
                return deferred.promise;
		    }

		    return {
		        calculate: calculate
		    };

		}]);

})();