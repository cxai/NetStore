﻿/// <reference path="../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.Queries.directive('queryViewerHeader', function () {

        return {
            templateUrl: "app/queries/views/queryViewerHeader.html",
            transclude: true,
            scope: {
                defaultTitle: "@"
            },
            controller: ['$scope', '$translate', function ($scope, $translate) {

                $scope.$on('query-description-HTML-loaded', function (event, data) {

                    $scope.defaultTitle = "";

                    if (data.html == null) {
                        //$scope.defaultTitle = $translate.instant('DESCRIPTION');
                    }
                });
            }]
        };

    });

})();