﻿(function () {
    "use strict";

    checkmarx.CxAcademy.controller('AppSecCoach.BannerController', ['$scope', '$translate', 'Common.QueryString',
        function ($scope, $translate, queryString) {

            function getQueryName() {

                var queryName = queryString.getParameterByName('queryTitle', window.location.href);

                if (queryName) {
                    queryName = queryName.replace(/_/g, ' ');
                }

                return queryName;
            }

            function buildHeaderText() {
                $scope.headerText = $translate.instant('CONFUSED_ABOUT') + ' ' + getQueryName();
            }

            buildHeaderText();

        }]);
})();