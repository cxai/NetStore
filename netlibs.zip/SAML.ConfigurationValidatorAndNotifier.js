﻿(function () {
    "use strict";

    checkmarx.SAML.factory('SAML.ConfigurationValidatorAndNotifier', ['CxPortal.NotificationService', '$translate', 'SAML.ConfigurationCertificateValidator', function (notificationService, $translate, configurationCertificateValidator) {

        function validCertificateFile(files, certificateDetails, isValidationNeeded, isExternal, $scope) {

            if (!isValidationNeeded) {
                return true;
            }

            if ((!files || files.length < 1) && !certificateDetails) {
                return false;
            }

            var validCertificate = true;

            if (files && files.length > 0) {
                validCertificate = isExternal ? configurationCertificateValidator.validateSpCertificate(files[0]) : configurationCertificateValidator.validateIdpCertificate(files[0]);
                updateScope(isExternal, $scope, !validCertificate);
            }

            return validCertificate;
        };

        function updateScope(isExternal, $scope, invalidCertificate) {
            if (isExternal) {
                $scope.invalidExternalCertificate = invalidCertificate;
            }
            else {
                $scope.invalidCertificate = invalidCertificate;
            }
        };

        function isFormValid(samlConfiguration, $scope) {
            return ($scope.form.$valid
                    && validCertificateFile(samlConfiguration.idPCertificateFiles, samlConfiguration.certificateDetails, true, false, $scope)
                    && validCertificateFile(samlConfiguration.externalCertificateFiles, samlConfiguration.externalCertificateDetails, samlConfiguration.clientSignatureRequired, true, $scope)
                    && samlConfiguration.manualUserManagement.defaultTeam.value
                    && !textHasWhiteSpaces(samlConfiguration.samlApiName))
                    || samlConfiguration.isEnabled == false;
        }

        function textHasWhiteSpaces(text) {
            if (!text) {
                return false;
            }
            return text.indexOf(' ') >= 0;
        }

        function notifySuccess($scope) {
            $scope.loadSAML();
            notificationService.success($translate.instant("SAML_SAVED_SUCCESSFULLY"));
        }

        function notifyFailure(errorMessage, $scope) {
            $scope.showPanelErrorMessage = true;
            $scope.panelErrorMessage = errorMessage;
        }

        return {
            isFormValid: isFormValid,
            textHasWhiteSpaces: textHasWhiteSpaces,
            notifySuccess: notifySuccess,
            notifyFailure: notifyFailure
        };

    }]);
})();