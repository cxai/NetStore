﻿
(function () {
    "use strict";

    checkmarx.Common.factory('modalService', ['$uibModal', function ($uibModal) {

        function openModalTemplateUrl(templateUrl, windowClass) {

            return openModal(templateUrl, null, windowClass);
        }

        function openModalHTMLTemplate(template, windowClass) {

            return openModal(null, template, windowClass);
        }

        function openModal(templateUrl, template, windowClass) {
            return $uibModal.open({
                templateUrl: templateUrl ? templateUrl : null,
                template: template ? (startTemplate + template + endTemplate) : null,
                controller: ['$scope', '$uibModalInstance', function ($scope, $ModalInstance) {
                    $scope.close = function () {
                        $ModalInstance.close();
                    };
                }],
                windowClass: windowClass ? windowClass : null
            });
        };

        function close() {
            $uibModal.close();
        }

        var startTemplate = '<modal show=\'showModal\'>' +
                            '  <div>' +
                            '       <button type="button" class="close closeModal" ng-click="close()" data-dismiss="modal">&times;</button>';

        var endTemplate =   '   </div>' +
                            '</modal>';

        return {
            openModal: openModal,
            openModalTemplateUrl: openModalTemplateUrl,
            openModalHTMLTemplate: openModalHTMLTemplate,
            close: close
        };
    }]);

})();