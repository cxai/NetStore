var Checkmarx;
(function (Checkmarx) {
    var Constants;
    (function (Constants) {
        //Events
        var Events = (function () {
            function Events() {
            }
            Events.ToggleContainerEvent = "container-toggle";
            Events.DataReceived = "data-received";
            Events.RefreshRateEvent = "refresh-rate";
            Events.DataFilterChangedEvent = "data-filter-changed-event";
            Events.FilterChangedEvent = "filter-changed-event";
            return Events;
        }());
        Constants.Events = Events;
    })(Constants = Checkmarx.Constants || (Checkmarx.Constants = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=constants.js.map