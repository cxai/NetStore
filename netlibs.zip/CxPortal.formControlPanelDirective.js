﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxPortal.directive('formControlPanel', [function () {

        return {
            restrict: 'E',
            transclude: true,
            template: '<div class="form-control-panel-container">'
                        + '<div class="buttons-container">'
                            + '<ng-transclude></ng-transclude>'
                        + '</div>'
                    + '</div>',
            scope: {}
        };
    }]);
})();