﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.directive('policyViolationStatus',
        ['policyStatusService', 'policyViolationStatuses', 'projectStatuses', 'projectSeverity', 
        function (policyStatusService, policyViolationStatuses, projectStatuses, projectSeverity) {

            var policyViolatedText = "POLICY_VIOLATED";
            var policyComplaintText = "POLICY_COMPLAINT";

        return {
            template: '<span ng-show="{{showMessage}}" class="policy-message {{policyStatusTextClass}}">{{policyText | translate}}</span>',
            controller: ['$scope', function ($scope) {
                
                $scope.showMessage = true;

                function getPolicyViolationStatus() {

                    return policyStatusService.calculatePolicyStatus();
                }

                function initiateViolatedPolicyMessage() {

                    $scope.policyText = policyViolatedText;
                    $scope.policyStatusTextClass = 'violated';
                }

                function initiateComplaintPolicyMessage() {

                    $scope.policyText = policyComplaintText;
                    $scope.policyStatusTextClass = 'complaint';
                }

                function runProcess() {

                    getPolicyViolationStatus().then(function (policyViolationStatus) {

                        switch (policyViolationStatus) {
                            case policyViolationStatuses.violated:
                                initiateViolatedPolicyMessage();
                                break;
                            case policyViolationStatuses.complaint:
                                initiateComplaintPolicyMessage();
                                break;
                            default:
                                $scope.showMessage = false;
                        }
                    });
                }

                /*
                 temporary disabled. SHIMIZ.
                 runProcess();
                 */
            }]
        };

    }]);

})();