﻿/// <reference path="../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.SAML = angular.module('SAML', []);

})();
