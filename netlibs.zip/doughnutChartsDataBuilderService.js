﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('doughnutChartsDataBuilderService', [
        '$q',
        'lastScanByProjectLoader',
        'projectSeverity',
        'projectStatuses',
        'summarizeBySeverityAndStateService',
        '$translate',
        'chartColumnDataNames',
        function ($q,
            lastScanByProjectLoader,
            projectSeverity,
            projectStatuses,
            summarizeBySeverityAndStateService,
            $translate,
            chartColumnDataNames) {

            var scanDataModel = {};
            var zeroStateColor = '#F6F7F8';
            var generalData = {
                width: 155,
                height: 158,
                type: 'line',
                events: {
                    onChartLoading: renderImageAndText
                }
            };

            function calculateImageAndTextSize() {

                var result = {};

                if (window.innerWidth < 1200) {

                    result = {
                        fontSize: "14px",
                        imgWidth: 37,
                        imgHeight: 46,
                    };
                }
                else if (window.innerWidth >= 1200 && window.innerWidth <= 1800) {

                    result = {
                        fontSize: "9px",
                        imgWidth: 23,
                        imgHeight: 29,
                    };
                }
                else {
                    result = {
                        fontSize: "14px",
                        imgWidth: 37,
                        imgHeight: 46,
                    };
                }

                return result;
            }

            function calculateImageLocation(chart, img, textAndImage) {

                var xImg = (chart.chartWidth * 0.5) - (textAndImage.imgWidth * 0.5 + 3);
                var image = chart.renderer.image(img, xImg, "30%", textAndImage.imgWidth, textAndImage.imgHeight).add();
            }

            function calculateTextLocation(chart, text, textCss, textAndImage) {

                var rend = chart.renderer,
                pie = chart.series[0],
                left = chart.plotLeft + pie.center[0],
                top = chart.plotTop + pie.center[1] + (textAndImage.imgHeight * 0.7),
                text = rend.text(text, left, top).attr({ 'text-anchor': 'middle' }).css(textCss).add();
            }

            function renderImageAndText(chart, img, text, textCss) {

                var textAndImage = calculateImageAndTextSize();
                textCss['font-size'] = textAndImage.fontSize;

                calculateTextLocation(chart, text, textCss, textAndImage);
                calculateImageLocation(chart, img, textAndImage);
            }

            function getCountObject(projectSeverity) {

                var count = {
                    newVulnerabilities: summarizeBySeverityAndStateService.getStatusCount(scanDataModel, projectSeverity, projectStatuses.new),
                    reoccured: summarizeBySeverityAndStateService.getStatusCount(scanDataModel, projectSeverity, projectStatuses.reoccured),
                    solved: summarizeBySeverityAndStateService.getStatusCount(scanDataModel, projectSeverity, projectStatuses.fixed)
                };

                return count;
            }

            function getTotalCount(count) {

                return count.newVulnerabilities + count.reoccured;
            }

            function isZeroState(count) {
    
                return count.newVulnerabilities <= 0 && count.reoccured <= 0;
            }

            function buildEmptyChartData() {

                var color = '#949495';

                var shadow = {
                    color: color,
                    offsetX: -1,
                    offsetY: 1,
                    opacity: 0.3,
                    width: 2
                };

                var data = [{
                    y: 1,
                    color: zeroStateColor,
                }];

                generalData.events.onChartLoading = null;
                generalData.tooltip = {
                    enabled: false
                };

                return {
                    generalData: generalData,
                    chartName: 'empty',
                    mainColor: color,
                    data: data,
                    containerId: 'container',
                    shadow: shadow
                };
            }

            function buildChartData(count, countColor, customPattern) {

                var data = {};

                if (isZeroState(count)) {

                    data = [{
                        y: 1,
                        color: zeroStateColor
                    }];
                }
                else {
                    data = [{
                        y: count.newVulnerabilities,
                        color: countColor
                    }, {
                        y: count.reoccured,
                        color: customPattern
                    }];
                }

                return data;
            }

            function getShadow(count) {

                if (isZeroState(count)) {

                    return {
                        color: '#949495',
                        offsetX: -1,
                        offsetY: 1,
                        opacity: 0.2,
                        width: 3
                    };
                }

                return false;
            }

            function buildHighChartData() {

                var color = '#E14D4D';
                var count = getCountObject(projectSeverity.high);
                var data = buildChartData(count, color, 'url(#custom-pattern-high)');
                var shadow = getShadow(count);
                generalData.events.onChartLoading = renderImageAndText;

                return {
                    generalData: generalData,
                    chartName: 'high',
                    name: chartColumnDataNames.Solved,
                    mainColor: color,
                    count: count,
                    data: data,
                    imageUrl: 'images/charts/high.png',
                    text: getTotalCount(count) + ' ' + $translate.instant('HIGH'),
                    textCss: {
                        'color': '#343a41',
                        'font-size': '14px',
                        'font-weight': 700
                    },
                    containerId: 'container',
                    shadow: shadow
                };
            }

            function buildMediumChartData() {

                var color = '#FFC000';
                var count = getCountObject(projectSeverity.medium);
                var data = buildChartData(count, color, 'url(#custom-pattern-medium)');
                var shadow = getShadow(count);
                generalData.events.onChartLoading = renderImageAndText;

                return {
                    generalData: generalData,
                    chartName: 'medium',
                    mainColor: color,
                    count: count,
                    data: data,
                    imageUrl: 'images/charts/medium.png',
                    text: getTotalCount(count) + ' ' + $translate.instant('MED'),
                    textCss: {
                        'color': '#343a41',
                        'font-size': '14px',
                        'font-weight': 700
                    },
                    containerId: 'container2',
                    shadow: shadow
                };
            }

            function buildLowChartData() {

                var color = '#FFF200';
                var count = getCountObject(projectSeverity.low);
                var data = buildChartData(count, color, 'url(#custom-pattern-low)');
                var shadow = getShadow(count);
                generalData.events.onChartLoading = renderImageAndText;

                return {
                    generalData: generalData,
                    chartName: 'low',
                    mainColor: color,
                    count: count,
                    data: data,
                    imageUrl: 'images/charts/low.png',
                    text: getTotalCount(count) + ' ' + $translate.instant('LOW'),
                    textCss: {
                        'color': '#343a41',
                        'font-size': '14px',
                        'font-weight': 700
                    },
                    containerId: 'container3',
                    shadow: shadow
                };
            }

            function loadData(projectId) {

                var deferred = $q.defer();

                var lastScanByProjectWithNoCache = true;

                lastScanByProjectLoader.load(projectId, lastScanByProjectWithNoCache).then(function (lastScanData) {

                    deferred.resolve(lastScanData);
                })
                .catch(function (result) {
                    deferred.reject(result);
                });

                return deferred.promise;
            }

            function build(projectId) {

                var deferred = $q.defer();

                loadData(projectId).then(function (lastScanData) {

                    scanDataModel = lastScanData;

                    var chartsData = {
                        highChartData: buildHighChartData(),
                        mediumChartData: buildMediumChartData(),
                        lowChartData: buildLowChartData()
                    };

                    deferred.resolve(chartsData);

                }).catch(function (result) {
                    
                    deferred.reject(result);
                });

                return deferred.promise;
            }

            return {
                build: build,
                buildEmptyChartData: buildEmptyChartData
            };
        }]);

})();