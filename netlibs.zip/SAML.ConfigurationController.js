﻿(function () {
	"use strict";

	checkmarx.SAML.controller('SAML.ConfigurationController',
                ['$scope',
                    '$rootScope',
                    'SAML.ConfigurationsTranslator',
                    'SAML.ConfigurationDataService',
                    'SAML.ConfigurationLoadDataService',
                    'SAML.ConfigurationValidatorAndNotifier',
                    'SAML.ConfigurationExternalCertificateService',
                    'httpStatusCodes',
                    'cxPortalRoles',
                    '$translate',
                    '$timeout',
                    '$q',
	function ($scope, $rootScope, configurationsTranslator, configurationDataService, configurationLoadDataService, configurationValidatorAndNotifier, configurationExternalCertificateService, httpStatusCodes, cxPortalRoles, $translate, $timeout, $q) {

	    $scope.ManualDownloadLink = configurationDataService.getDownloadLink();
	    $scope.AutomaticDownloadLink = configurationDataService.getExtendedDownloadLink();
	    $scope.ManualMetadataFileName = "Cx_Manual_Metadata.xml";
	    $scope.AutomaticMetadataFileName = "Cx_IdP_Metadata.xml";

	    $scope.reset = function () {

	        if ($scope.form) {
	            $scope.form.$setPristine();
	            $scope.form.$setUntouched();
	        }
	        $scope.showPanelErrorMessage = false;
	    };

	    $scope.samlDisabled = function () {
	        $scope.disableClicked = true;
	    };

	    $scope.textChanged = function () {
	        $scope.showNameError = configurationValidatorAndNotifier.textHasWhiteSpaces($scope.SAML.samlApiName);
	    };

	    function callTheExternalCertificate(samlData) {
	        configurationExternalCertificateService.get().then(function (certificateData) {
	            loadPageData(samlData, certificateData);
	        }).catch(function (ex) {
	            loadPageData(samlData);
	            if (ex.data && ex.data.messageDetails) {
	                $scope.showPanelErrorMessage = true;
	                $scope.panelErrorMessage = ex.data.messageDetails;
	                $scope.samlLoaded = true;
	            }
	        });
	    };

	    function loadPageData(samlData, certificateData){
	        if (samlData) {
	            $scope.reset();
	            configurationLoadDataService.load($scope.SAML, samlData.data, certificateData ? certificateData.data: undefined);
	            configurationLoadDataService.duplicateData($scope.savedSAMLFromLoad, $scope.SAML);
	            $scope.clearFiles();
	            $scope.samlLoaded = true;
	        }
	    };

	    $scope.loadSAML = function () {

	        $scope.certificatePasswordReadonly = true;

	        configurationDataService.get().then(function(samlData) {
	            if (samlData && samlData.data && samlData.data.clientSignatureRequired) {
	                callTheExternalCertificate(samlData);
	            }
	            else {
	                loadPageData(samlData);
	            }
	        }).catch(function(ex) {
	            if (ex.status === httpStatusCodes.notFound) {
	                initializeSamlConfigurationData();
	                $scope.isFirstSave = true;
	            }
	            else if (ex.data && ex.data.messageDetails) {
	                $scope.showPanelErrorMessage = true;
	                $scope.panelErrorMessage = ex.data.messageDetails;
	            }
	            $scope.samlLoaded = true;
	        });
	    };

	    $scope.clearFiles = function() {
	        $scope.$broadcast('clear-upload-files');

	        if ($scope.SAML.certificateDetails) {
	            $scope.$broadcast('clear-upload-files-certificate', $scope.SAML.certificateDetails);
	        }
	        if ($scope.SAML.externalCertificateDetails) {
	            $scope.$broadcast('clear-upload-files-externalCertificate', $scope.SAML.externalCertificateDetails);
	        }
	    };
         
	    $scope.focusCertificatePassword = function() {
            $scope.certificatePasswordReadonly = false;
	    };

	    $scope.$on('yes-cancel-saml-modal', function () {
	        $scope.SAML.manualUserManagement.defaultTeam.isTouched = false;
	        $scope.loadSAML();
	    });

	    $scope.$on('download-file-success', function () {
	        $scope.showPanelErrorMessage = false;
	});

	    $scope.$on('download-file-error', function () {
	        $scope.panelErrorMessage = $translate.instant('DOWNLOAD_METADATA_ERROR');
	        $scope.showPanelErrorMessage = true;
	});

        $scope.$on('no-disable-saml-modal', function () {
            $scope.SAML.isEnabled = true;
	});
        
        $scope.$on('show-default-team-error', function () {
            $timeout(function () {
                $scope.showDefaultTeamError = true;
        });
	});

        $scope.$on('hide-default-team-error', function () {
            $timeout(function () {
                $scope.showDefaultTeamError = false;
        });
	});

        $scope.$on('default-team-error-was-touched', function () {
            $timeout(function () {
                $scope.SAML.manualUserManagement.defaultTeam.isTouched = true;
        });
	});

        $scope.broadcastElementLoaded = function() {
            $rootScope.$broadcast('elementLoaded', 'saml-view');
	}

        $(window).resize(function () {
            $scope.broadcastElementLoaded();
	});
        
        $scope.$on("$destroy", function () {
            $rootScope.$broadcast('elementDistroyed');
	});


	    function initializeSamlObject() {        
            $scope.SAML = { };
            $scope.savedSAMLFromLoad = { };
            $scope.SAML.isEnabled = false;
            $scope.SAML.userManagementMethod = {
                value: 1
	    };

            $scope.SAML.manualUserManagement = {
                    defaultTeam: samlConfigurationExternalService.group,
                    role: { id: cxPortalRoles.reviewer, name: $translate.instant(cxPortalRoles.reviewer.toUpperCase()) },
                    allowNotExploitable: true,
                    allowProjectAndScanDelete: false,
                    allowSeverityAndStatusChanges: false
	    }

            $scope.SAML.manualUserManagement.roles = [
                    { id: cxPortalRoles.scanner, name: $translate.instant(cxPortalRoles.scanner.toUpperCase()) },
                    { id: cxPortalRoles.reviewer, name: $translate.instant(cxPortalRoles.reviewer.toUpperCase()) }
	    ];   
	};

	    function initializeScopeParameters() {
            $scope.samlLoaded = false;
            $scope.showPanelErrorMessage = false;
            $scope.invalidCertificate = false;
            $scope.invalidExternalCertificate = false;
            $scope.disableClicked = false;
            $scope.isFirstSave = false;
            $scope.showDefaultTeamError = false;
            $scope.showNameError = false;

            $scope.reset();
	};

	    function initializeSamlConfigurationData() {
            initializeSamlObject();
            initializeScopeParameters();           
	}

	    function translate() {
            $scope.translations = configurationsTranslator.getTranslations();
	}


        initializeSamlConfigurationData();
	    translate();
	    $scope.loadSAML();

        }]);

})();