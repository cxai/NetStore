﻿
(function () {
    "use strict";

    checkmarx.ApplicationSettings.directive('webServerAddress', function () {
        return {
            require: 'ngModel',
            link: function (scope, elem, attr, ngModel) {
                
                if (attr.webServerAddress) {
                    //For DOM -> model validation
                    ngModel.$parsers.unshift(function (value) {
                        var valid = validateWebServerAddress(value);
                        ngModel.$setValidity('webServerAddress', valid);
                        return valid ? value : undefined;
                    });

                    //For model -> DOM validation
                    ngModel.$formatters.unshift(function (value) {
                        var valid = validateWebServerAddress(value);
                        ngModel.$setValidity('webServerAddress', valid);
                        return value;
                    });
                }

                function validateWebServerAddress(value) {
                    if (value) {
                        var regexp = /(^[h|H][t|T][t|T][p|P][s|S]?:\/\/[\w|\-]+(\.[\w|\-]+)*(:(6553[0-5]|655[0-2][0-9]|65[0-4][0-9][0-9]|[1-6][0-4][0-9][0-9][0-9]|\d{2,4}|[1-9]))?)$/;
                        return regexp.test(value);
                    }

                    return true;
                };
            }
        }
    });
})();