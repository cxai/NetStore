﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('scanRequestCalculatorService', ['scanRequestStage', 'scanRequestGeneralStages',
        function (scanRequestStage, scanRequestGeneralStages) {

        function getScanRequestStatus(scanRequests) {

            var setUp = {
                scanId: 0,
                scanStatusId : 0,
                scanStatus: "",
                scanStatusText: "",
                showNotification: false,
                showCloseButton: false
            };
            
            for (var i = 0; i < scanRequests.length; i++) {

                var stageId = scanRequests[i].stage.id;
                setUp.scanId = scanRequests[i].id;

                switch (stageId) {
                    case scanRequestStage.new:
                    case scanRequestStage.prescan:
                    case scanRequestStage.queued:
                    case scanRequestStage.scanning:
                    case scanRequestStage.postscan:
                    case scanRequestStage.sourcePullingAndDeployment:
                        setUp.scanStatus = "progress";
                        setUp.scanStatusId = scanRequestGeneralStages.progress;
                        setUp.scanStatusText = "SCAN_IN_PROGRESS";
                        setUp.showNotification = true;
                        setUp.showCloseButton = false;
                        return setUp;
                    case scanRequestStage.failed:
                        setUp.scanStatus = "failed";
                        setUp.scanStatusId = scanRequestGeneralStages.failed;
                        setUp.scanStatusText = "SCAN_FAILED";
                        setUp.showCloseButton = true;
                        setUp.showNotification = true;
                        break;
                    case scanRequestStage.finished:
                        setUp.scanStatus = "success";
                        setUp.scanStatusId = scanRequestGeneralStages.success;
                        setUp.scanStatusText = "SCAN_COMPLETED_SUCCESSFULLY";
                        setUp.showCloseButton = true;
                        setUp.showNotification = true;
                        setUp.stage = scanRequestStage.finished;
                        break;
                    case scanRequestStage.canceled:
                        setUp.scanStatus = "cancel";
                        setUp.scanStatusId = scanRequestGeneralStages.cancel;
                        setUp.scanStatusText = "SCAN_CANCEL";
                        setUp.showCloseButton = true;
                        setUp.showNotification = true;
                        break;
                }
            }

            return setUp;
        }

        return {
            getScanRequestStatus: getScanRequestStatus
        };

    }]);

})();