﻿/// <reference path="app.js" />

(function () {
    "use strict";

    checkmarx.Queries = angular.module('Queries', []);

})();