var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        var C = Checkmarx.Constants;
        // Directive controller implementation
        var WidgetDirective = (function () {
            // Constructor (including dependencies that will be inserted automatically by angular)
            function WidgetDirective(scope, $interval) {
                var _this = this;
                this.scope = scope;
                this.$interval = $interval;
                this.loading = true;
                var refreshRate = this.source.config.refreshRate;
                this.intervalInstance = this.$interval(function () {
                    //Fire refresh rate event
                    _this.loading = true;
                    _this.scope.$broadcast(C.Events.RefreshRateEvent);
                }, refreshRate);
                //the widgetShell listen to DataReceived
                this.scope.$on(C.Events.DataReceived, function (evt, data) {
                    _this.updatedOn = data.lastUpdated;
                    _this.loading = false;
                });
                //Submit button call to onDataFilterChanged event
                this.scope['onDataFilterChanged'] = function () {
                    _this.loading = true;
                    _this.scope.$broadcast(C.Events.DataFilterChangedEvent);
                };
                this.scope.$on("$destroy", function () {
                    if (_this.intervalInstance) {
                        _this.$interval.cancel(_this.intervalInstance);
                        _this.intervalInstance = undefined;
                    }
                });
            }
            // Specify the dependencies for this directive    
            WidgetDirective.$inject = ['$scope', '$interval'];
            return WidgetDirective;
        }());
        // Directive configuration
        function WidgetDirectiveSettings() {
            return {
                restrict: 'E',
                replace: true,
                controller: WidgetDirective,
                controllerAs: 'root',
                templateUrl: '/CxWebClient/pages/dashboard/Widget',
                bindToController: true,
                scope: {
                    source: '='
                }
            };
        }
        Directives.WidgetDirectiveSettings = WidgetDirectiveSettings;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=widget.js.map