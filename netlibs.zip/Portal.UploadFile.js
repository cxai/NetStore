﻿(function () {
    "use strict";

    checkmarx.CxPortal.directive('portalFileUpload', ['$rootScope', '$timeout', function ($rootScope, $timeout) {



        return {
            template: '<div class="portal-file-upload fileinput-button">'
                            + '<div class="hint-button-container">'
                                + '<div class="hint-message" ng-class="{\'file-loaded\': files.length > 0}">{{message}}</div>'
                                + '<div class="file-upload-button">'
                                    + '<img ng-src="{{imageSrc}}" /> <span>{{"CHOOSE_FILE" | translate}}</span>'
                                + '</div>'
                            + '</div>'
                            + '<upload-file is-disable="isDisable" title={{message}} control-id="{{controlId}}" name="{{name}}" is-multiple-supported="isMultipleSupported" filter-files="{{filterFiles}}" files="files"></upload-file>'
                        + '</div>',
            restrict: 'E',
            scope: {
                name: '@',
                files: '=files',
                imageSrc: '@',
                message: '@',
                filterFiles: '@',
                isMultipleSupported: '=',
                controlId: '@',
                isDisable: '='
            },
            link: function (scope, element, attributes) {
                
                scope.files = [];
                scope.defaultMessage = scope.message;

                scope.$on('clear-upload-files', function (event, defaultMessage) {
                    scope.message = defaultMessage ? defaultMessage : scope.defaultMessage;
                });

                scope.$on('clear-upload-files-' + scope.controlId, function (event, defaultMessage) {
                    scope.message = defaultMessage ? defaultMessage : scope.defaultMessage;
                });

                scope.$watchCollection('files', function () {

                    printSelectedFilesNames();
                });

                function printSelectedFilesNames() {

                    if (scope.files && scope.files.length > 0) {

                        var fileNames = [];

                        for (var i = 0; i < scope.files.length; i++) {

                            fileNames.push(scope.files[i].name);
                        }

                        scope.message = '';
                        scope.message += fileNames.join(', ');

                        updateRootScopeFiles();
                    }
                }

                function updateRootScopeFiles() {
                    $rootScope.localSourceDialogFiles = scope.files;
                }
            }
        };
    }]);
})();