﻿var ldapServer = {};

// functions available:
// ldapServer.getServerDiv(inputId, server);
// ldapServer.setTranslations(serversList, elem, i);

(function () {

    var newServer = {
        Id: 0,
        Name: '{{NEW_SERVER}}',
        HostName: "",
        Port: "",
        UseSSL: "",
        VerifySslCertificate: "",
        Username: "",
        Password: "",
        BaseDn: "",
        AdditionalUserDn: "",
        UserObjectClass: "",
        UserObjectFilter: "",
        UsernameAttribute: "",
        UserRdnAttribute: "",
        FirstNameAttribute: "",
        LastNameAttribute: "",
        EmailAttribute: "",
        DomainMapSettings: { IsMappedToDomain: "False" },
        SyncSettings: {
            AdditionalGroupDN: "",
            GroupObjectClass: "",
            GroupObjectFilter: "",
            GroupIdAttribute: "",
            GroupNameAttribute: "",
            GroupMembersAttribute: "",
            UserMemberShipAttribute: "",            
            LdapRoleMapping: {
                DefaultRoleId: "0",
                DefaultRoleApplyNotExploitable: "0",
                DefaultRoleDeleteProjectsAndScans: "0",
                DefaultRoleAllowStatusSeverityChanges: "0",
                WsLdapAdvancedRoleMapping: {
                    ScannerWithoutRoleAttributesGroupDnList: "",
                    ScannerWithNotExploitableGroupDnList: "",
                    ScannerWithDeleteGroupDnList: "",
                    ScannerWithNotExploitableAndDeleteGroupDnList: "",
                    ReviewerWithoutRoleAttributesGroupDnList: "",
                    ReviewerWithSeverityStatusChangeGroupDnList: "",
                }
            }
        },
    };
    
    function addTextBoxWithTooltipAndLabel(inputId, name, value, translatedName, className, disabled, required, validator, validationLength) {
       return "<div class='" + className + "'>" +
                    "<label class='label-form label-form-" + name + "'></label>" +
                    "<input data-name='" + name + "' value='" + (value != undefined ? value : '') + "' " + disabled + " style='display:inline;margin-left:5px;' type='text' placeholder='' class=' form-control' " + required + " " + validator + " data-parsley-maxlength='" + validationLength + "'  data-parsley-errors-container='[data-validation-for=" + name + inputId + "]'>" +
                        "<span class='custom-tooltip-filter  custom-tooltip-filter-down'>" +
                                "<img src='Images/Icons/help16x16.png' class='helpIcon' title='' />" +
                                "<span class='custom-tooltip-content'>" +
                                    "<span class='custom-tooltip-text'>" +
                                        "<span class='custom-tooltip-inner custom-tooltip-inner" + translatedName + "'>" +
                                            "{{" + translatedName + "}}" +
                                        "</span>" +
                                    "</span>" +
                                "</span>" +
                            "</span>" +
                    "<span class='errorMessageParsley' data-validation-for='" + name + inputId + "'>&nbsp;</span>" +
                "</div>";
    };

    function addCheckbox(id, name, value, translaedName, className) {
        return "<div class='checkbox " + className + "' id='" + id + "'>" +
                    "<label>" +
                        "<input data-name='" + name + "' type='checkbox' value='' " + (value == true ? 'checked' : '') + ">" +
                            "<i class='input-helper input-helper"+ translaedName + "'>{{"+ translaedName + "}}</i>" +
                    "</label>" +
                "</div>";
    };

    ldapServer.getServerDiv = function (inputId, server) {

        var isNewServer = false;

	    if (!server) {
	    	server = newServer;
	    	isNewServer = true;
	    }

	    return "<h3 data-id='" + server.Id + "'  class='headerItem' style='padding-bottom:13px;margin-top:13px;outline: none !important'><span " + (isNewServer ? "class='headerItemNEW_SERVER'" : "") + ">" + server.Name + "</span>" +
                        "<span class='action-button deleteAction'>" +
                        "<button class='btn btn-default' style='margin-top:-5px;font-size:15px;padding: 0;' type='button'><i style='font-family: FontAwesome !important' class='fa fa-trash-o'></i> {{DELETE}}</button>" +
                      "</span>" +                   
                   "</h3>" +
                        "<div class='server' input-id='" + inputId + "' style='padding-bottom:24px;padding-top:24px' data-action='" + (isNewServer ? "Insert" : "None") + "'>" +
                         "<form class='form-horizontal form-bordered form-authentication' " + (isNewServer ? " data-parsley-excluded=[disabled] " : "") + " data-parsley-validate='true' name='demo-form' id='demo-form'>" +
                            "<div class='row'>" +
                             "<h3 class='authentiacation headline'>" +
                                            "{{AUTHENTICATION}}" +
                                        "</h3>" +
                                "<div class='col-xs-4'>" +
                                   "<fieldset>" +
                                        "<legend class='legendSERVER_SETTINGS'>" +
                                            "{{SERVER_SETTINGS}}" +
                                        "</legend>" +
                                       "<div class='form-group'>" +
                                            "<label class='label-form label-form-Name'></label>" +
                                            "<input " + (!isNewServer ? ("value='" + server.Name + "'") : "") + " data-name='Name' style='display:inline;margin-left:5px;' type='text' maxlength='100'  data-parsley-maxlength='100' placeholder='' class='nameInput form-control'  required data-parsley-errors-container='[data-validation-for=name" + inputId + "]' >" +
                                             "<span class='custom-tooltip-filter custom-tooltip-filter-down'>" +
                                                    "<img src='Images/Icons/help16x16.png' class='helpIcon' title='' />" +
                                                    "<span class='custom-tooltip-content'>" +
                                                        "<span class='custom-tooltip-text'>" +
                                                            "<span class='custom-tooltip-inner custom-tooltip-innerLDAP_NAME_TOOLTIP'>" +
                                                                "{{LDAP_NAME_TOOLTIP}}" +
                                                            "</span>" +
                                                        "</span>" +
                                                    "</span>" +
                                                "</span>" +
                                            "<span class='errorMessageParsley' data-validation-for='name" + inputId + "'>&nbsp;</span>" +
                                        "</div>" +
                                        "<div class='form-group'>" +
                                        "<label class='label-form label-form-DirectoryType'></label>" +
                                           "<span class='ui-select' >" +
                                               "<select  class='directoryTypeSelection form-control'  data-name='DirectoryType' style='display:inline;' required data-parsley-errors-container='[data-validation-for=directoryTypeSelection" + inputId + "]'>" +
                                                   "<option value='' style='font-weight:bold !important;' class='optionDIRECTORY_TYPE'>{{DIRECTORY_TYPE}}</option>" +
                                                   "<option " + ((!isNewServer && server.DirectoryType == "1") ? "selected" : "") + " value='ActiveDirectory' class='optionActiveDirectory'>{{ActiveDirectory}}</option>" +
                                                   "<option " + ((!isNewServer && server.DirectoryType == "2") ? "selected" : "") + " value='OpenLDAP' class='optionOPENLDAP'>{{OPENLDAP}}</option>" +
                                                   "<option " + ((!isNewServer && server.DirectoryType == "3") ? "selected" : "") + " value='CustomLDAPServer' class='optionCUSTOM_LDAP_SERVER'>{{CUSTOM_LDAP_SERVER}}</option>" +
                                               "</select>" +
                                          " </span> " +
                                           "<span class='custom-tooltip-filter'>" +
                                                    "<img src='Images/Icons/help16x16.png' style='margin-left:1px' class='helpIcon'  />" +
                                                    "<span class='custom-tooltip-content'>" +
                                                        "<span class='custom-tooltip-text'>" +
                                                            "<span class='custom-tooltip-inner custom-tooltip-innerLDAP_DIRECTORYTYPE_TOOLTIP'>" +
                                                                "{{LDAP_DIRECTORYTYPE_TOOLTIP}}" +
                                                            "</span>" +
                                                        "</span>" +
                                                    "</span>" +
                                                "</span>" +
                                            "<span class='errorMessageParsley' data-validation-for='directoryTypeSelection" + inputId + "'>&nbsp;</span>" +
                                       "</div>" +
                                       // **************** Ldap SSO ********************** 
                                       "<div class='form-group enable-sso-ldap-div'>" +
                                           "<div class='checkbox enable-sso-ldap-checkbox'>" +
                                                "<label>" +
                                                   "<input id='sso-enabled-cb-" + inputId + "' class='sso-enabled-cb' disabled data-name='SSOEnabled' type='checkbox' value='" + server.DomainMapSettings.IsMappedToDomain + "'>" +
                                                      "<i class='input-helper input-helperLDAP_SSO_CHECKBOX'>{{LDAP_SSO_CHECKBOX}}</i>" +
                                                "</label>" +
                                           "</div>" +
                                            "<span class='custom-tooltip-filter'  id='custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP_DISABLED" + inputId + "'>" +
                                                "<img src='Images/Icons/help16x16.png' style='margin-left:1px' class='helpIcon'  />" +
                                                "<span class='custom-tooltip-content'>" +
                                                    "<span class='custom-tooltip-text'>" +
                                                        "<span class='custom-tooltip-inner custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP_DISABLED'>" +
                                                            "{{LDAP_SSO_CHECKBOX_TOOLTIP_DISABLED}}" +
                                                        "</span>" +
                                                    "</span>" +
                                                "</span>" +
                                            "</span>" +
                                            "<span class='custom-tooltip-filter'  id='custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP" + inputId + "'>" +
                                                "<img src='Images/Icons/help16x16.png' style='margin-left:1px' class='helpIcon'  />" +
                                                "<span class='custom-tooltip-content'>" +
                                                    "<span class='custom-tooltip-text'>" +
                                                        "<span class='custom-tooltip-inner custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP'>" +
                                                            "{{LDAP_SSO_CHECKBOX_TOOLTIP}}" +
                                                        "</span>" +
                                                    "</span>" +
                                                "</span>" +
                                            "</span>" +
                                            //Domain dropdown
                                            "<span class='domain-in-use-message'>{{DOMAIN_IN_USE_MESSAGE}}</span>" +
                                            "<label class='label-form label-form-DomainType'></label>" +
                                                "<span class='ui-select' >" +
                                                    "<select id='select-domain-for-sso-" + inputId + "' " + (server.DomainMapSettings.IsMappedToDomain ? "" : "disabled") + " class='select-domain-for-sso form-control'  data-name='DomainNetbiosName' style='display:inline;' required>" +
                                                    "</select>" +
                                                " </span> " +
                                            "</div>" +
                                        // ****************** End Ldap SSO **********************

                                        addTextBoxWithTooltipAndLabel(inputId, 'HostName', server.HostName, 'LDAP_HOST_NAME_TOOLTIP', 'form-group', '', 'required', '', '100') +
                                        addTextBoxWithTooltipAndLabel(inputId, 'Port', server.Port, 'LDAP_PORT_TOOLTIP', 'form-group', '', 'required', "data-parsley-portValidator data-parsley-portValidator-message=''", '100') +
                                         "<div class='form-group'>" +
                                            "<div style='margin-left:14px;' class='checkbox'>" +
                                               "<label>" +
                                                   "<input id='primary_cb' type='checkbox'  data-name='UseSSL' value='" + server.UseSSL + "'>" +
                                                       "<i class='input-helper input-helperUSE_SSL'>{{USE_SSL}}</i>" +
                                               "</label>" +
                                            "</div>" +
                                         "</div>" +
                                         "<div class='form-group'>" +
                                           "<div style='margin-left:14px;'  class='checkbox'>" +
                                                "<label>" +
                                                   "<input class='secondary_CB' disabled data-name='VerifySslCertificate' type='checkbox' value='" + server.VerifySslCertificate + "'>" +
                                                      "<i class='input-helper input-helperVERIFY_SSL_CERTIFICATE'>{{VERIFY_SSL_CERTIFICATE}}</i>" +
                                                "</label>" +
                                           "</div>" +
                                         "</div>" +
                                          "<div class='form-group'>" +
                                            "<label class='label-form label-form-UserName'></label>" +
                                            "<input value='" + server.Username + "' data-name='UserName' style='display:inline;margin-left:5px;' " + (!isNewServer ? "data-trigger='change'" : "") + " data-parsley-maxlength='100' type='text' placeholder=''  class='form-control' required data-parsley-errors-container='[data-validation-for=userName" + inputId + "]'>" +
                                            "<span class='custom-tooltip-filter'>" +
                                                    "<img src='Images/Icons/help16x16.png' class='helpIcon' />" +
                                                    "<span class='custom-tooltip-content'>" +
                                                        "<span class='custom-tooltip-text'>" +
                                                            "<span class='custom-tooltip-inner custom-tooltip-innerLDAP_USER_NAME_TOOLTIP'>" +
                                                                "" + ((isNewServer || server.DirectoryType != "2") ? "{{LDAP_USER_NAME_TOOLTIP}}" : "{{LDAP_USERDN_TOOLTIP}}") +
                                                            "</span>" +
                                                        "</span>" +
                                                    "</span>" +
                                                "</span>" +
                                            "<span class='errorMessageParsley' data-validation-for='userName" + inputId + "'>&nbsp;</span>" +
                                        "</div>" +
                                          "<div class='form-group'>" +
                                            "<label class='label-form label-form-Password'></label>" +
                                            "<input value='" + server.Password + "' data-name='Password' style='display:inline;margin-left:5px;'" + (!isNewServer ? "data-trigger='change'" : "") + " data-parsley-maxlength='100' type='password' placeholder='' class='form-control' required data-parsley-errors-container='[data-validation-for=password" + inputId + "]'>" +
                                             "<span class='custom-tooltip-filter'>" +
                                                    "<img src='Images/Icons/help16x16.png' class='helpIcon' />" +
                                                    "<span class='custom-tooltip-content'>" +
                                                        "<span class='custom-tooltip-text'>" +
                                                            "<span class='custom-tooltip-inner custom-tooltip-innerPASSWORD'>" +
                                                                "<u>{{PASSWORD}}</u>" +
                                                            "</span>" +
                                                        "</span>" +
                                                    "</span>" +
                                                "</span>" +
                                            "<span class='errorMessageParsley' data-validation-for='password" + inputId + "'>&nbsp;</span>" +
                                        "</div>" +
                                    "</fieldset>" +
                                 "</div>" +
                                 "<div class='col-xs-4'>" +
                                    "<fieldset>" +
                                        "<legend class='legendLDAP_SCHEMA'>" +
                                            "{{LDAP_SCHEMA}}" +
                                        "</legend>" +
                                        addTextBoxWithTooltipAndLabel(inputId, 'BaseDn', server.BaseDn, 'LDAP_BASE_DN_TOOLTIP', 'form-group', '', 'required', '', '255') +
                                        addTextBoxWithTooltipAndLabel(inputId, 'AdditionalUserDn', server.AdditionalUserDn, 'LDAP_ADDITIONAL_USER_DN_TOOLTIP', 'form-group', '', '', '', '255') +
                                    "</fieldset>" +
                                 "</div>" +
                                 "<div class='col-xs-4'>" +
                                    "<fieldset>" +
                                        "<legend class='legendUSER_SCHEMA_SETTINGS'>" +
                                                "{{USER_SCHEMA_SETTINGS}}" +
                                        "</legend>" +
                                        addTextBoxWithTooltipAndLabel(inputId, 'UserObjectSchema', server.UserObjectClass, 'LDAP_USER_OBJECT_SCHEMA_TOOLTIP', 'form-group', '', 'required', '', '100') +
                                        addTextBoxWithTooltipAndLabel(inputId, 'UserObjectFilter', server.UserObjectFilter, 'LDAP_USER_OBJECT_FILTER_TOOLTIP', 'form-group', '', 'required', '', '100') +
                                        addTextBoxWithTooltipAndLabel(inputId, 'UserNameAttribute', server.UsernameAttribute, 'LDAP_USER_NAME_ATTRIBUTE_TOOLTIP', 'form-group', '', 'required', '', '100') +
                                        addTextBoxWithTooltipAndLabel(inputId, 'UserRDNAttribute', server.UserRdnAttribute, 'LDAP_USER_RDN_ATTRIBUTE_TOOLTIP', 'form-group', '', 'required', '', '100') +
                                        addTextBoxWithTooltipAndLabel(inputId, 'UserFirstNameAttribute', server.FirstNameAttribute, 'LDAP_FIRST_NAME_ATTRIBUTE_TOOLTIP', 'form-group', '', '', '', '100') +
                                        addTextBoxWithTooltipAndLabel(inputId, 'UserLastNameAttribute', server.LastNameAttribute, 'LDAP_LAST_NAME_ATTRIBUTE_TOOLTIP', 'form-group', '', '', '', '100') +
                                        addTextBoxWithTooltipAndLabel(inputId, 'UserEmailAttribute', server.EmailAttribute, 'LDAP_USER_EMAIL_ATTRIBUTE_TOOLTIP', 'form-group', '', '', '', '254') +
                                    "</fieldset>" +
                                "</div>" +
                        "</div>" +
                        "<div style='border-top: 1px #e7eaec;color: #ffffff;background-color: #E0DBDB;height: 1px;margin: 20px 0;'></div>" +
                             "<div class='row synchronization-header-div'>" +
                              "<h3 class='synchronization headline'>" +
                                            "{{SYNCHRONIZATION}}" +
                              "</h3>" +
                             "<span class='synchronization-description' id='synchronization-description'>{{SYNCHRONIZATION_DESCRIPTION}}</span>" +
                                //Checkbox Enabled
                                "<div class='form-group enabled-check-box-div'>" +
                                    "<div style='margin-left:21px;' class='checkbox'>" +
                                        "<label>" +
                                            "<input id='enabled-cb-" + inputId + "' class='enabledCheckBox' data-name='Enabled' type='checkbox' >" +
                                                "<i class='input-helper input-helperENABLED' style='font-size:16px;font-style:normal;'>{{ENABLED}}</i>" +
                                        "</label>" +
                                    "</div>" +
                                "</div>" +
                                "<span class='sso-sync-warning-message' id='sso-sync-warning-message-" + inputId + "'>{{SSO_SYNC_WARNING_MESSAGE}}</span>" +
                             "</div>" +
                             "<div class='row rowEnbaledSynchronization'>" +
                                //start column
                                "<div class='col-xs-6'>" +
                                   "<fieldset>" +
                                    //GROUP_SCHEMA_SETTINGS
                                    "<legend class='legendGROUP_SCHEMA_SETTINGS'>" +
                                       "{{GROUP_SCHEMA_SETTINGS}}" +
                                    "</legend>" +
                                        addTextBoxWithTooltipAndLabel(inputId, 'AdditionalGroupDN', server.SyncSettings.AdditionalGroupDN, 'ADDITIONAL_GROUP_DN_TOOLTIP', 'form-group', '', '', '', '255') +
                                        addTextBoxWithTooltipAndLabel(inputId, 'GroupObjectClass', server.SyncSettings.GroupObjectClass, 'GROUP_OBJECT_CLASS_TOOLTIP', 'form-group', '', 'required', '', '100') +
                                        addTextBoxWithTooltipAndLabel(inputId, 'GroupObjectFilter', server.SyncSettings.GroupObjectFilter, 'GROUP_OBJECT_FILTER_TOOLTIP', 'form-group', '', 'required', '', '100') +
                                        addTextBoxWithTooltipAndLabel(inputId, 'GroupIDAttribute', server.SyncSettings.GroupIdAttribute, 'GROUP_ID_ATTRIBUTE_TOOLTIP', 'form-group', '', 'required', '', '100') +
                                        addTextBoxWithTooltipAndLabel(inputId, 'GroupNameAttribute', server.SyncSettings.GroupNameAttribute, 'GROUP_NAME_ATTRIBUTE_TOOLTIP', 'form-group', '', 'required', '', '100') +
                                   "</fieldset>" +
                                //End Column
                                "</div>" +
                                //Start Column
                                 "<div class='col-xs-6'>" +
                                    "<fieldset>" +
                                        //MEMBERSHIP_SCHEMA_SETTINGS
                                        "<legend class='legendMEMBERSHIP_SCHEMA_SETTINGS'>" +
                                           "{{MEMBERSHIP_SCHEMA_SETTINGS}}" +
                                        "</legend>" +                                        
                                        addTextBoxWithTooltipAndLabel(inputId, 'GroupMembersAttribute', server.SyncSettings.GroupMembersAttribute, 'GROUP_MEMBERS_ATTRIBUTE_TOOLTIP', 'form-group', '', 'required', '', '100') +
                                        addTextBoxWithTooltipAndLabel(inputId, 'UserMembershipAttribute', server.SyncSettings.UserMemberShipAttribute, 'USER_MEMBERSHIP_ATTRIBUTE_TOOLTIP', 'form-group', '', '', '', '100') +
                                    "</fieldset>" +
                                //End Column
                                 "</div>" +
                                //Start Column
                                 "<div class='col-xs-12 role-mapping-div'>" +
                                    "<fieldset>" +
                                    //ROLE_MAPPING
                                        "<legend class='legendROLE_MAPPING'>" +
                                           "{{ROLE_MAPPING}}" +
                                        "</legend>" +
                                    //DDL: DefaultRoleId
                                    "<div class='form-group col-xs-3'>" +
                                    "<label class='label-form label-form-DefaultRoleId'></label>" +
                                       "<span class='ui-select'>" +
                                           "<select class='defaultRoleId form-control' disabled data-name='DefaultRoleId' style='display:inline;' required data-parsley-errors-container='[data-validation-for=DefaultRoleId" + inputId + "]'>" +
                                                "<option " + ((server.SyncSettings.LdapRoleMapping.DefaultRoleId == "0") ? "selected" : "") + " value='0' class='optionSCANNER'>{{SCANNER}}</option>" +
                                                "<option " + ((server.SyncSettings.LdapRoleMapping.DefaultRoleId == "1") ? "selected" : "") + " value='1' class='optionREVIEWER'>{{REVIEWER}}</option>" +
                                           "</select>" +
                                      " </span> " +
                                           "<span class='custom-tooltip-filter'>" +
                                                    "<img src='Images/Icons/help16x16.png' style='margin-left:1px' class='helpIcon'  />" +
                                                    "<span class='custom-tooltip-content'>" +
                                                        "<span class='custom-tooltip-text'>" +
                                                            "<span class='custom-tooltip-inner custom-tooltip-innerDEFAULT_ROLE_ID_TOOLTIP'>" +
                                                                "{{DEFAULT_ROLE_ID_TOOLTIP}}" +
                                                            "</span>" +
                                                        "</span>" +
                                                    "</span>" +
                                                "</span>" +
                                        "<span class='errorMessageParsley' data-validation-for='DefaultRoleId" + inputId + "'>&nbsp;</span>" +
                                            addCheckbox('allowSeverityStatusChanges', 'DefaultRoleAllowStatusSeverityChanges', server.SyncSettings.LdapRoleMapping.DefaultRoleAllowStatusSeverityChanges, 'ALLOW_SEVERITY_STATUS_CHANGES', 'default-role-id-checkbox') +
                                            addCheckbox('permissionToChangeNotExploitable', 'DefaultRoleApplyNotExploitable', server.SyncSettings.LdapRoleMapping.DefaultRoleApplyNotExploitable, 'PERMISSION_TO_CHANGE_NOT_EXPLOITABLE', 'default-role-id-checkbox') +
                                            addCheckbox('allowDeleteProjectScan', 'DefaultRoleDeleteProjectsAndScans', server.SyncSettings.LdapRoleMapping.DefaultRoleDeleteProjectsAndScans, 'ALLOW_DELETE_PROJECT_SCAN', 'default-role-id-checkbox') +
                                   "</div>" +
                                "</fieldset>" +

                                //ADVANCED_ROLE_MAPPING Checkbox
                                "<div class=''>" +
                                    "<legend class='legendADVANCED_ROLE_MAPPING'>" +
                                        "<div style='margin-left:14px;' class='checkbox'>" +
                                            "<label>" +
                                                "<input id='advancedRoleMapping_cb' disabled data-name='AdvancedRoleMappingEnabled' type='checkbox' value=''>" +
                                                    "<i class='input-helper input-helperADVANCED_ROLE_MAPPING'>{{ADVANCED_ROLE_MAPPING}}</i>" +
                                            "</label>" +
                                        "</div>" +                                        
                                    "</legend>" +
                                "</div>" +
                                
                                //SCANNER
                                "<div class='col-xs-6'>" +
                                    "<fieldset>" +
                                        "<label class='legendSCANNER'>" +
                                           "{{SCANNER}}" +
                                        "</label>" +
                                        "<div class=''>" +
                                            addTextBoxWithTooltipAndLabel(inputId, 'ScannerWithoutRoleAttributesGroupDnList', server.SyncSettings.LdapRoleMapping.WsLdapAdvancedRoleMapping.ScannerWithoutRoleAttributesGroupDnList, 'SCANNER_GROUP_DN_NO_AUTH_TOOLTIP', 'form-group attribute-roles-group-dn attribute-roles-group-dn-left', 'disabled', '', '', '4000') +
                                            addTextBoxWithTooltipAndLabel(inputId, 'ScannerWithNotExploitableGroupDnList', server.SyncSettings.LdapRoleMapping.WsLdapAdvancedRoleMapping.ScannerWithNotExploitableGroupDnList, 'SCANNER_GROUP_DN_NE_TOOLTIP', 'form-group attribute-roles-group-dn attribute-roles-group-dn-left', 'disabled', '', '', '4000') +
                                            addTextBoxWithTooltipAndLabel(inputId, 'ScannerWithDeleteGroupDnList', server.SyncSettings.LdapRoleMapping.WsLdapAdvancedRoleMapping.ScannerWithDeleteGroupDnList, 'SCANNER_GROUP_DN_ALLOW_DELETE_TOOLTIP', 'form-group attribute-roles-group-dn attribute-roles-group-dn-left', 'disabled', '', '', '4000') +
                                            addTextBoxWithTooltipAndLabel(inputId, 'ScannerWithNotExploitableAndDeleteGroupDnList', server.SyncSettings.LdapRoleMapping.WsLdapAdvancedRoleMapping.ScannerWithNotExploitableAndDeleteGroupDnList, 'SCANNER_GROUP_DN_ALL_AUTH_TOOLTIP', 'form-group attribute-roles-group-dn attribute-roles-group-dn-left', 'disabled', '', '', '4000') +
                                         "</div>" +
                                    "</fieldset>" +
                                "</div>" +

                                //REVIEWER
                                "<div class='col-xs-6'>" +
                                    "<fieldset>" +
                                        "<label class='legendREVIEWER'>" +
                                           "{{REVIEWER}}" +
                                        "</label>" +
                                        "<div class=''>" +
                                            addTextBoxWithTooltipAndLabel(inputId, 'ReviewerWithoutRoleAttributesGroupDnList', server.SyncSettings.LdapRoleMapping.WsLdapAdvancedRoleMapping.ReviewerWithoutRoleAttributesGroupDnList, 'REVIEWER_GROUP_DN_NO_AUTH_TOOLTIP', 'form-group attribute-roles-group-dn', 'disabled', '', '', '4000') +
                                            addTextBoxWithTooltipAndLabel(inputId, 'ReviewerWithSeverityStatusChangeGroupDnList', server.SyncSettings.LdapRoleMapping.WsLdapAdvancedRoleMapping.ReviewerWithSeverityStatusChangeGroupDnList, 'REVIEWER_GROUP_DN_ALL_AUTH_TOOLTIP', 'form-group attribute-roles-group-dn', 'disabled', '', '', '4000') +
                                        "</div>" +
                                    "</fieldset>" +
                                  "</div>" +

                                //End Column
                                "</div>" +
                            "</div>" +
                         "</form>" +
                      "<div class='row'>" +
                         "<div style='margin-top: 64px;margin-right:12px;float:right;'>" +
                            "<span class='action-button saveAction'>" +
                                "<button class='btn btn-default saveButton' style='height:30px;font-size:15px;padding: 0;' type='button'><i style='font-family: FontAwesome !important' class='fa fa-floppy-o'></i> {{SAVE}} </button>" +
                            "</span>" +                            
                            "<span class='action-button connectionAction'>" +
                                "<button class='btn btn-default' style='height:30px;font-size:15px;padding: 0;width:145px' type='button'><i style='font-family: FontAwesome !important' class='fa fa-share-alt'></i> {{TEST_CONNECTION}}</button>" +
                             "</span>" +
                            "<span class='action-button " + (isNewServer ? "clearAction" : "cancelAction") + "'>" +
                                "<button class='btn btn-default cancelButton' " + (isNewServer ? "" : "tabindex='-1'") + " style='height:30px;font-size:15px;padding: 0;' type='button'><i style='font-family: FontAwesome !important' class='fa fa-times'></i> {{CANCEL}} </button>" +
                            "</span>" +
                         "</div>" +
                      "</div>" +		      
		   "</div>";
    }

    ldapServer.setTranslations = function (serversList, elem, i) {
        //Values
        var btnDelete = $(elem).find(".deleteAction").html();
        var btnTestConnection = $(elem).find(".connectionAction").html();

        var ValueLegendSERVER_SETTINGS = $(elem).find('.legendSERVER_SETTINGS').html();
        var ValueAuthentication = $(elem).find('.authentiacation').html();
        var ValueSynchronization = $(elem).find('.synchronization').html();
        var ValueSynchronizationDescription = $(elem).find('.synchronization-description').html();

        var ValueLegendGROUP_SCHEMA_SETTINGS = $(elem).find('.legendGROUP_SCHEMA_SETTINGS').html();
        var ValueLegendMEMBERSHIP_SCHEMA_SETTINGS = $(elem).find('.legendMEMBERSHIP_SCHEMA_SETTINGS').html();
        var ValueLegendROLE_MAPPING = $(elem).find('.legendROLE_MAPPING').html();


        var ValueCustom_tooltip_innerLDAP_NAME_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_NAME_TOOLTIP').html();
        var ValueOptionDIRECTORY_TYPE = $(elem).find('.optionDIRECTORY_TYPE').html();
        var ValueOptionCUSTOM_LDAP_SERVER = $(elem).find('.optionCUSTOM_LDAP_SERVER').html();
        var ValueoOptionOPENLDAP = $(elem).find('.optionOPENLDAP').html();
        var ValueCustom_tooltip_innerLDAP_DIRECTORYTYPE_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_DIRECTORYTYPE_TOOLTIP').html();
        var ValueInput_helperLDAP_SSO_CHECKBOX = $(elem).find('.input-helperLDAP_SSO_CHECKBOX').html();

        var ValueCustom_tooltip_innerLDAP_HOST_NAME_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_HOST_NAME_TOOLTIP').html();
        var ValueCustom_tooltip_innerLDAP_PORT_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_PORT_TOOLTIP').html();
        var ValueInput_helperUSE_SSL = $(elem).find('.input-helperUSE_SSL').html();
        var ValueInput_helperVERIFY_SSL_CERTIFICATE = $(elem).find('.input-helperVERIFY_SSL_CERTIFICATE').html();
        var ValueCustom_tooltip_innerLDAP_USER_NAME_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_USER_NAME_TOOLTIP').html();
        var ValueCustom_tooltip_innerPASSWORD = $(elem).find('.custom-tooltip-innerPASSWORD').html();

        var ValueLegendLDAP_SCHEMA = $(elem).find('.legendLDAP_SCHEMA').html();
        var ValueCustom_tooltip_innerLDAP_BASE_DN_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_BASE_DN_TOOLTIP').html();
        var ValueCustom_tooltip_innerLDAP_ADDITIONAL_USER_DN_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_ADDITIONAL_USER_DN_TOOLTIP').html();

        var ValueLegendUSER_SCHEMA_SETTINGS = $(elem).find('.legendUSER_SCHEMA_SETTINGS').html();
        var ValueCustom_tooltip_innerLDAP_USER_OBJECT_SCHEMA_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_USER_OBJECT_SCHEMA_TOOLTIP').html();
        var ValueCustom_tooltip_innerLDAP_USER_OBJECT_FILTER_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_USER_OBJECT_FILTER_TOOLTIP').html();
        var ValueCustom_tooltip_innerLDAP_USER_NAME_ATTRIBUTE_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_USER_NAME_ATTRIBUTE_TOOLTIP').html();
        var ValueCustom_tooltip_innerLDAP_USER_RDN_ATTRIBUTE_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_USER_RDN_ATTRIBUTE_TOOLTIP').html();
        var ValueCustom_tooltip_innerLDAP_FIRST_NAME_ATTRIBUTE_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_FIRST_NAME_ATTRIBUTE_TOOLTIP').html();
        var ValueCustom_tooltip_innerLDAP_LAST_NAME_ATTRIBUTE_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_LAST_NAME_ATTRIBUTE_TOOLTIP').html();
        var LDAP_USER_EMAIL_ATTRIBUTE_TOOLTIPValue = $(elem).find('.custom-tooltip-innerLDAP_USER_EMAIL_ATTRIBUTE_TOOLTIP').html();
        var optionActiveDirectoryValue = $(elem).find('.optionActiveDirectory').html();
        var ValueCustom_tooltip_innerLDAP_SSO_CHECKBOX_TOOLTIP = $(elem).find('.custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP').html();
        var ValueCustom_tooltip_innerLDAP_SSO_CHECKBOX_TOOLTIP_DISABLED = $(elem).find('.custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP_DISABLED').html();

        var ValueDOMAIN_IN_USE_MESSAGE = $(elem).find('.domain-in-use-message').html();
        var ValueSSO_SYNC_WARNING_MESSAGE = $(elem).find('.sso-sync-warning-message').html();

        var ValueALLOW_SEVERITY_STATUS_CHANGES = $(elem).find('.input-helperALLOW_SEVERITY_STATUS_CHANGES').html();
        var ValuePERMISSION_TO_CHANGE_NOT_EXPLOITABLE = $(elem).find('.input-helperPERMISSION_TO_CHANGE_NOT_EXPLOITABLE').html();
        var ValueALLOW_DELETE_PROJECT_SCAN = $(elem).find('.input-helperALLOW_DELETE_PROJECT_SCAN').html();

        //Replace Values
        $(elem).find(".deleteAction").html(btnDelete.replace('{{DELETE}}', $("#hdnDELETE").val()));
        $(elem).find(".connectionAction").html(btnTestConnection.replace('{{TEST_CONNECTION}}', $("#hdnTEST_CONNECTION").val()));

        $(elem).find('.optionActiveDirectory').html(optionActiveDirectoryValue.replace('{{ActiveDirectory}}', $("#hdnACTIVEDIRECTORY").val()));
        $(elem).find('.legendSERVER_SETTINGS').html(ValueLegendSERVER_SETTINGS.replace('{{SERVER_SETTINGS}}', $("#hdnSERVER_SETTINGS").val()));

        $(elem).find('.authentiacation').html(ValueAuthentication.replace('{{AUTHENTICATION}}', $("#hdnAUTHENTICATION").val()));
        $(elem).find('.synchronization').html(ValueSynchronization.replace('{{SYNCHRONIZATION}}', $("#hdnSYNCHRONIZATION").val()));
        $(elem).find('.synchronization-description').html(ValueSynchronizationDescription.replace('{{SYNCHRONIZATION_DESCRIPTION}}', $("#hdnSYNCHRONIZATION_DESCRIPTION").val()));

        $(elem).find('.custom-tooltip-innerLDAP_NAME_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_NAME_TOOLTIP.replace('{{LDAP_NAME_TOOLTIP}}', $("#hdnLDAP_NAME_TOOLTIP").val()));
        $(elem).find('.optionDIRECTORY_TYPE').html(ValueOptionDIRECTORY_TYPE.replace('{{DIRECTORY_TYPE}}', $("#hdnDIRECTORY_TYPE").val()));
        $(elem).find('.optionCUSTOM_LDAP_SERVER').html(ValueOptionCUSTOM_LDAP_SERVER.replace('{{CUSTOM_LDAP_SERVER}}', $("#hdnCUSTOM_LDAP_SERVER").val()));
        $(elem).find('.optionOPENLDAP').html(ValueoOptionOPENLDAP.replace('{{OPENLDAP}}', $("#hdnOPENLDAP").val()));
        $(elem).find('.custom-tooltip-innerLDAP_DIRECTORYTYPE_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_DIRECTORYTYPE_TOOLTIP.replace('{{LDAP_DIRECTORYTYPE_TOOLTIP}}', $("#hdnLDAP_DIRECTORYTYPE_TOOLTIP").val()));
        $(elem).find('.input-helperLDAP_SSO_CHECKBOX').html(ValueInput_helperLDAP_SSO_CHECKBOX.replace('{{LDAP_SSO_CHECKBOX}}', $('#hdnLDAP_SSO_CHECKBOX').val()));

        $(elem).find('.domain-in-use-message').html(ValueDOMAIN_IN_USE_MESSAGE.replace('{{DOMAIN_IN_USE_MESSAGE}}', $("#hdnDOMAIN_IN_USE_MESSAGE").val()));
        $(elem).find('.sso-sync-warning-message').html(ValueSSO_SYNC_WARNING_MESSAGE.replace('{{SSO_SYNC_WARNING_MESSAGE}}', $("#hdnSSO_SYNC_WARNING_MESSAGE").val()));

        $(elem).find('.custom-tooltip-innerLDAP_HOST_NAME_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_HOST_NAME_TOOLTIP.replace('{{LDAP_HOST_NAME_TOOLTIP}}', $("#hdnLDAP_HOST_NAME_TOOLTIP").val()));
        $(elem).find('.custom-tooltip-innerLDAP_PORT_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_PORT_TOOLTIP.replace('{{LDAP_PORT_TOOLTIP}}', $("#hdnLDAP_PORT_TOOLTIP").val()));
        $(elem).find('.input-helperUSE_SSL').html(ValueInput_helperUSE_SSL.replace('{{USE_SSL}}', $("#hdnUSE_SSL").val()));
        $(elem).find('.input-helperVERIFY_SSL_CERTIFICATE').html(ValueInput_helperVERIFY_SSL_CERTIFICATE.replace('{{VERIFY_SSL_CERTIFICATE}}', $("#hdnVERIFY_SSL_CERTIFICATE").val()));
        if (ValueCustom_tooltip_innerLDAP_USER_NAME_TOOLTIP === '{{LDAP_USER_NAME_TOOLTIP}}') {
            $(elem).find('.custom-tooltip-innerLDAP_USER_NAME_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_USER_NAME_TOOLTIP.replace('{{LDAP_USER_NAME_TOOLTIP}}', $("#hdnLDAP_USER_NAME_TOOLTIP").val()));
        }
        else if (ValueCustom_tooltip_innerLDAP_USER_NAME_TOOLTIP === '{{LDAP_USERDN_TOOLTIP}}') {
            $(elem).find('.custom-tooltip-innerLDAP_USER_NAME_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_USER_NAME_TOOLTIP.replace('{{LDAP_USERDN_TOOLTIP}}', $("#hdnLDAP_USERDN_TOOLTIP").val()));
        }
        $(elem).find('.custom-tooltip-innerPASSWORD').html(ValueCustom_tooltip_innerPASSWORD.replace('{{PASSWORD}}', $("#hdnPASSWORD").val()));

        $(elem).find('.legendLDAP_SCHEMA').html(ValueLegendLDAP_SCHEMA.replace('{{LDAP_SCHEMA}}', $("#hdnLDAP_SCHEMA").val()));
        $(elem).find('.custom-tooltip-innerLDAP_BASE_DN_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_BASE_DN_TOOLTIP.replace('{{LDAP_BASE_DN_TOOLTIP}}', $("#hdnLDAP_BASE_DN_TOOLTIP").val()));
        $(elem).find('.custom-tooltip-innerLDAP_ADDITIONAL_USER_DN_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_ADDITIONAL_USER_DN_TOOLTIP.replace('{{LDAP_ADDITIONAL_USER_DN_TOOLTIP}}', $("#hdnLDAP_ADDITIONAL_USER_DN_TOOLTIP").val()));

        $(elem).find('.legendUSER_SCHEMA_SETTINGS').html(ValueLegendUSER_SCHEMA_SETTINGS.replace('{{USER_SCHEMA_SETTINGS}}', $("#hdnUSER_SCHEMA_SETTINGS").val()));
        $(elem).find('.custom-tooltip-innerLDAP_USER_OBJECT_SCHEMA_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_USER_OBJECT_SCHEMA_TOOLTIP.replace('{{LDAP_USER_OBJECT_SCHEMA_TOOLTIP}}', $("#hdnLDAP_USER_OBJECT_SCHEMA_TOOLTIP").val()));
        $(elem).find('.custom-tooltip-innerLDAP_USER_OBJECT_FILTER_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_USER_OBJECT_FILTER_TOOLTIP.replace('{{LDAP_USER_OBJECT_FILTER_TOOLTIP}}', $("#hdnLDAP_USER_OBJECT_FILTER_TOOLTIP").val()));
        $(elem).find('.custom-tooltip-innerLDAP_USER_NAME_ATTRIBUTE_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_USER_NAME_ATTRIBUTE_TOOLTIP.replace('{{LDAP_USER_NAME_ATTRIBUTE_TOOLTIP}}', $("#hdnLDAP_USER_NAME_ATTRIBUTE_TOOLTIP").val()));
        $(elem).find('.custom-tooltip-innerLDAP_USER_RDN_ATTRIBUTE_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_USER_RDN_ATTRIBUTE_TOOLTIP.replace('{{LDAP_USER_RDN_ATTRIBUTE_TOOLTIP}}', $("#hdnLDAP_USER_RDN_ATTRIBUTE_TOOLTIP").val()));
        $(elem).find('.custom-tooltip-innerLDAP_FIRST_NAME_ATTRIBUTE_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_FIRST_NAME_ATTRIBUTE_TOOLTIP.replace('{{LDAP_FIRST_NAME_ATTRIBUTE_TOOLTIP}}', $("#hdnLDAP_FIRST_NAME_ATTRIBUTE_TOOLTIP").val()));
        $(elem).find('.custom-tooltip-innerLDAP_LAST_NAME_ATTRIBUTE_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_LAST_NAME_ATTRIBUTE_TOOLTIP.replace('{{LDAP_LAST_NAME_ATTRIBUTE_TOOLTIP}}', $("#hdnLDAP_LAST_NAME_ATTRIBUTE_TOOLTIP").val()));
        $(elem).find('.custom-tooltip-innerLDAP_USER_EMAIL_ATTRIBUTE_TOOLTIP').html(LDAP_USER_EMAIL_ATTRIBUTE_TOOLTIPValue.replace('{{LDAP_USER_EMAIL_ATTRIBUTE_TOOLTIP}}', $("#hdnLDAP_USER_EMAIL_ATTRIBUTE_TOOLTIP").val()));
        $(elem).find('.custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP').html(ValueCustom_tooltip_innerLDAP_SSO_CHECKBOX_TOOLTIP.replace('{{LDAP_SSO_CHECKBOX_TOOLTIP}}', $("#hdnLDAP_SSO_CHECKBOX_TOOLTIP").val()));
        $(elem).find('.custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP_DISABLED').html(ValueCustom_tooltip_innerLDAP_SSO_CHECKBOX_TOOLTIP_DISABLED.replace('{{LDAP_SSO_CHECKBOX_TOOLTIP_DISABLED}}', $("#hdnLDAP_SSO_CHECKBOX_TOOLTIP_DISABLED").val()));

        $(elem).find('.legendGROUP_SCHEMA_SETTINGS').html(ValueLegendGROUP_SCHEMA_SETTINGS.replace('{{GROUP_SCHEMA_SETTINGS}}', $("#hdnGROUP_SCHEMA_SETTINGS").val()));
        $(elem).find('.legendMEMBERSHIP_SCHEMA_SETTINGS').html(ValueLegendMEMBERSHIP_SCHEMA_SETTINGS.replace('{{MEMBERSHIP_SCHEMA_SETTINGS}}', $("#hdnMEMBERSHIP_SCHEMA_SETTINGS").val()));
        $(elem).find('.legendROLE_MAPPING').html(ValueLegendROLE_MAPPING.replace('{{ROLE_MAPPING}}', $("#hdnROLE_MAPPING").val()));

        $(elem).find('.input-helperALLOW_SEVERITY_STATUS_CHANGES').html(ValueALLOW_SEVERITY_STATUS_CHANGES.replace('{{ALLOW_SEVERITY_STATUS_CHANGES}}', $("#hdnALLOW_SEVERITY_STATUS_CHANGES").val()));
        $(elem).find('.input-helperPERMISSION_TO_CHANGE_NOT_EXPLOITABLE').html(ValuePERMISSION_TO_CHANGE_NOT_EXPLOITABLE.replace('{{PERMISSION_TO_CHANGE_NOT_EXPLOITABLE}}', $("#hdnPERMISSION_TO_CHANGE_NOT_EXPLOITABLE").val()));
        $(elem).find('.input-helperALLOW_DELETE_PROJECT_SCAN').html(ValueALLOW_DELETE_PROJECT_SCAN.replace('{{ALLOW_DELETE_PROJECT_SCAN}}', $("#hdnALLOW_DELETE_PROJECT_SCAN").val()));

        var ValueOptionSCANNER = $(elem).find('.optionSCANNER').html();
        var ValueOptionREVIEWER = $(elem).find('.optionREVIEWER').html();
        var ValueLegendSCANNER = $(elem).find('.legendSCANNER').html();
        var ValueLegendREVIEWER = $(elem).find('.legendREVIEWER').html();
        $(elem).find('.optionSCANNER').html(ValueOptionSCANNER.replace('{{SCANNER}}', $("#hdnSCANNER").val()));
        $(elem).find('.optionREVIEWER').html(ValueOptionREVIEWER.replace('{{REVIEWER}}', $("#hdnREVIEWER").val()));
        $(elem).find('.legendSCANNER').html(ValueLegendSCANNER.replace('{{SCANNER}}', $("#hdnSCANNER").val()));
        $(elem).find('.legendREVIEWER').html(ValueLegendREVIEWER.replace('{{REVIEWER}}', $("#hdnREVIEWER").val()));

        var ValueInput_helperADVANCED_ROLE_MAPPING = $(elem).find('.input-helperADVANCED_ROLE_MAPPING').html();
        $(elem).find('.input-helperADVANCED_ROLE_MAPPING').html(ValueInput_helperADVANCED_ROLE_MAPPING.replace('{{ADVANCED_ROLE_MAPPING}}', $("#hdnADVANCED_ROLE_MAPPING").val()));

        var ValueInput_helperENABLED = $(elem).find('.input-helperENABLED').html();
        $(elem).find('.input-helperENABLED').html(ValueInput_helperENABLED.replace('{{ENABLED}}', $("#hdnENABLED_SYNCHRONIZATION").val()));


        var button_CANCELValue = $(elem).find('.cancelButton').html();
        $(elem).find('.cancelButton').html(button_CANCELValue.replace('{{CANCEL}}', $("#hdnCANCEL").val()));

        var button_SAVEValue = $(elem).find('.saveButton').html();
        $(elem).find('.saveButton').html(button_SAVEValue.replace('{{SAVE}}', $("#hdnSAVE").val()));

        //Tab Synchronization ToolTips

        //ADDITIONAL_GROUP_DN_TOOLTIP
        var ADDITIONAL_GROUP_DN_TOOLTIPValue = $(elem).find('.custom-tooltip-innerADDITIONAL_GROUP_DN_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerADDITIONAL_GROUP_DN_TOOLTIP').html(ADDITIONAL_GROUP_DN_TOOLTIPValue.replace('{{ADDITIONAL_GROUP_DN_TOOLTIP}}', $("#hdnADDITIONAL_GROUP_DN_TOOLTIP").val()));

        //GROUP_OBJECT_CLASS_TOOLTIP
        var GROUP_OBJECT_CLASS_TOOLTIPValue = $(elem).find('.custom-tooltip-innerGROUP_OBJECT_CLASS_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerGROUP_OBJECT_CLASS_TOOLTIP').html(GROUP_OBJECT_CLASS_TOOLTIPValue.replace('{{GROUP_OBJECT_CLASS_TOOLTIP}}', $("#hdnGROUP_OBJECT_CLASS_TOOLTIP").val()));

        //GROUP_OBJECT_FILTER_TOOLTIP
        var GROUP_OBJECT_FILTER_TOOLTIPValue = $(elem).find('.custom-tooltip-innerGROUP_OBJECT_FILTER_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerGROUP_OBJECT_FILTER_TOOLTIP').html(GROUP_OBJECT_FILTER_TOOLTIPValue.replace('{{GROUP_OBJECT_FILTER_TOOLTIP}}', $("#hdnGROUP_OBJECT_FILTER_TOOLTIP").val()));

        //GROUP_ID_ATTRIBUTE_TOOLTIP
        var GROUP_ID_ATTRIBUTE_TOOLTIPValue = $(elem).find('.custom-tooltip-innerGROUP_ID_ATTRIBUTE_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerGROUP_ID_ATTRIBUTE_TOOLTIP').html(GROUP_ID_ATTRIBUTE_TOOLTIPValue.replace('{{GROUP_ID_ATTRIBUTE_TOOLTIP}}', $("#hdnGROUP_ID_ATTRIBUTE_TOOLTIP").val()));

        //GROUP_NAME_ATTRIBUTE_TOOLTIP
        var GROUP_NAME_ATTRIBUTE_TOOLTIPValue = $(elem).find('.custom-tooltip-innerGROUP_NAME_ATTRIBUTE_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerGROUP_NAME_ATTRIBUTE_TOOLTIP').html(GROUP_NAME_ATTRIBUTE_TOOLTIPValue.replace('{{GROUP_NAME_ATTRIBUTE_TOOLTIP}}', $("#hdnGROUP_NAME_ATTRIBUTE_TOOLTIP").val()));

        //ADDITIONAL_GROUP_DN_TOOLTIP
        var ADDITIONAL_GROUP_DN_TOOLTIPValue = $(elem).find('.custom-tooltip-innerADDITIONAL_GROUP_DN_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerADDITIONAL_GROUP_DN_TOOLTIP').html(ADDITIONAL_GROUP_DN_TOOLTIPValue.replace('{{ADDITIONAL_GROUP_DN_TOOLTIP}}', $("#hdnADDITIONAL_GROUP_DN_TOOLTIP").val()));

        //GROUP_OBJECT_CLASS_TOOLTIP
        var GROUP_OBJECT_CLASS_TOOLTIPValue = $(elem).find('.custom-tooltip-innerGROUP_OBJECT_CLASS_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerGROUP_OBJECT_CLASS_TOOLTIP').html(GROUP_OBJECT_CLASS_TOOLTIPValue.replace('{{GROUP_OBJECT_CLASS_TOOLTIP}}', $("#hdnGROUP_OBJECT_CLASS_TOOLTIP").val()));

        //GROUP_OBJECT_FILTER_TOOLTIP
        var GROUP_OBJECT_FILTER_TOOLTIPValue = $(elem).find('.custom-tooltip-innerGROUP_OBJECT_FILTER_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerGROUP_OBJECT_FILTER_TOOLTIP').html(GROUP_OBJECT_FILTER_TOOLTIPValue.replace('{{GROUP_OBJECT_FILTER_TOOLTIP}}', $("#hdnGROUP_OBJECT_FILTER_TOOLTIP").val()));

        //GROUP_ID_ATTRIBUTE_TOOLTIP
        var GROUP_ID_ATTRIBUTE_TOOLTIPValue = $(elem).find('.custom-tooltip-innerGROUP_ID_ATTRIBUTE_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerGROUP_ID_ATTRIBUTE_TOOLTIP').html(GROUP_ID_ATTRIBUTE_TOOLTIPValue.replace('{{GROUP_ID_ATTRIBUTE_TOOLTIP}}', $("#hdnGROUP_ID_ATTRIBUTE_TOOLTIP").val()));

        //GROUP_NAME_ATTRIBUTE_TOOLTIP
        var GROUP_NAME_ATTRIBUTE_TOOLTIPValue = $(elem).find('.custom-tooltip-innerGROUP_NAME_ATTRIBUTE_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerGROUP_NAME_ATTRIBUTE_TOOLTIP').html(GROUP_NAME_ATTRIBUTE_TOOLTIPValue.replace('{{GROUP_NAME_ATTRIBUTE_TOOLTIP}}', $("#hdnGROUP_NAME_ATTRIBUTE_TOOLTIP").val()));

        //GROUP_MEMBERS_ATTRIBUTE_TOOLTIP
        var GROUP_MEMBERS_ATTRIBUTE_TOOLTIPValue = $(elem).find('.custom-tooltip-innerGROUP_MEMBERS_ATTRIBUTE_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerGROUP_MEMBERS_ATTRIBUTE_TOOLTIP').html(GROUP_MEMBERS_ATTRIBUTE_TOOLTIPValue.replace('{{GROUP_MEMBERS_ATTRIBUTE_TOOLTIP}}', $("#hdnGROUP_MEMBERS_ATTRIBUTE_TOOLTIP").val()));

        //USER_MEMBERSHIP_ATTRIBUTE_TOOLTIP
        var USER_MEMBERSHIP_ATTRIBUTE_TOOLTIPValue = $(elem).find('.custom-tooltip-innerUSER_MEMBERSHIP_ATTRIBUTE_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerUSER_MEMBERSHIP_ATTRIBUTE_TOOLTIP').html(USER_MEMBERSHIP_ATTRIBUTE_TOOLTIPValue.replace('{{USER_MEMBERSHIP_ATTRIBUTE_TOOLTIP}}', $("#hdnUSER_MEMBERSHIP_ATTRIBUTE_TOOLTIP").val()));

        //DEFAULT_ROLE_ID_TOOLTIP
        var DEFAULT_ROLE_ID_TOOLTIPValue = $(elem).find('.custom-tooltip-innerDEFAULT_ROLE_ID_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerDEFAULT_ROLE_ID_TOOLTIP').html(DEFAULT_ROLE_ID_TOOLTIPValue.replace('{{DEFAULT_ROLE_ID_TOOLTIP}}', $("#hdnDEFAULT_ROLE_ID_TOOLTIP").val()));

        //SCANNER REVIEWER GROUP DN TOOLTIPS
        var SCANNER_GROUP_DN_NO_AUTH_TOOLTIPValue = $(elem).find('.custom-tooltip-innerSCANNER_GROUP_DN_NO_AUTH_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerSCANNER_GROUP_DN_NO_AUTH_TOOLTIP').html(SCANNER_GROUP_DN_NO_AUTH_TOOLTIPValue.replace('{{SCANNER_GROUP_DN_NO_AUTH_TOOLTIP}}', $("#hdnSCANNER_GROUP_DN_NO_AUTH_TOOLTIP").val()));
        var SCANNER_GROUP_DN_ALLOW_DELETE_TOOLTIPValue = $(elem).find('.custom-tooltip-innerSCANNER_GROUP_DN_ALLOW_DELETE_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerSCANNER_GROUP_DN_ALLOW_DELETE_TOOLTIP').html(SCANNER_GROUP_DN_ALLOW_DELETE_TOOLTIPValue.replace('{{SCANNER_GROUP_DN_ALLOW_DELETE_TOOLTIP}}', $("#hdnSCANNER_GROUP_DN_ALLOW_DELETE_TOOLTIP").val()));
        var SCANNER_GROUP_DN_NE_TOOLTIPValue = $(elem).find('.custom-tooltip-innerSCANNER_GROUP_DN_NE_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerSCANNER_GROUP_DN_NE_TOOLTIP').html(SCANNER_GROUP_DN_NE_TOOLTIPValue.replace('{{SCANNER_GROUP_DN_NE_TOOLTIP}}', $("#hdnSCANNER_GROUP_DN_NE_TOOLTIP").val()));
        var SCANNER_GROUP_DN_ALL_AUTH_TOOLTIPValue = $(elem).find('.custom-tooltip-innerSCANNER_GROUP_DN_ALL_AUTH_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerSCANNER_GROUP_DN_ALL_AUTH_TOOLTIP').html(SCANNER_GROUP_DN_ALL_AUTH_TOOLTIPValue.replace('{{SCANNER_GROUP_DN_ALL_AUTH_TOOLTIP}}', $("#hdnSCANNER_GROUP_DN_ALL_AUTH_TOOLTIP").val()));
        var REVIEWER_GROUP_DN_NO_AUTH_TOOLTIPValue = $(elem).find('.custom-tooltip-innerREVIEWER_GROUP_DN_NO_AUTH_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerREVIEWER_GROUP_DN_NO_AUTH_TOOLTIP').html(REVIEWER_GROUP_DN_NO_AUTH_TOOLTIPValue.replace('{{REVIEWER_GROUP_DN_NO_AUTH_TOOLTIP}}', $("#hdnREVIEWER_GROUP_DN_NO_AUTH_TOOLTIP").val()));
        var REVIEWER_GROUP_DN_ALL_AUTH_TOOLTIPValue = $(elem).find('.custom-tooltip-innerREVIEWER_GROUP_DN_ALL_AUTH_TOOLTIP').html();
        $(elem).find('.custom-tooltip-innerREVIEWER_GROUP_DN_ALL_AUTH_TOOLTIP').html(REVIEWER_GROUP_DN_ALL_AUTH_TOOLTIPValue.replace('{{REVIEWER_GROUP_DN_ALL_AUTH_TOOLTIP}}', $("#hdnREVIEWER_GROUP_DN_ALL_AUTH_TOOLTIP").val()));

        //Labels
        $(elem).find('.label-form-Name').html($("#hdnName").val());
        $(elem).find('.label-form-DirectoryType').html($("#hdnDIRECTORY_TYPE").val());
        $(elem).find('.label-form-HostName').html($("#hdnHOST_NAME").val());
        $(elem).find('.label-form-Port').html($("#hdnPORT").val());
        $(elem).find('.label-form-UserName').html($("#hdnUSER_NAME").val());
        $(elem).find('.label-form-Password').html($("#hdnPASSWORD").val());
        $(elem).find('.label-form-BaseDn').html($("#hdnBASE_DN").val());
        $(elem).find('.label-form-AdditionalUserDn').html($("#hdnADDITIONAL_USER_DN").val());
        $(elem).find('.label-form-UserObjectSchema').html($("#hdnUSER_OBJECT_SCHEMA").val());
        $(elem).find('.label-form-UserObjectFilter').html($("#hdnUSER_OBJECT_FILTER").val());
        $(elem).find('.label-form-UserNameAttribute').html($("#hdnUSER_NAME_ATTRIBUTE").val());
        $(elem).find('.label-form-UserRDNAttribute').html($("#hdnUSER_RDN_ATTRIBUTE").val());
        $(elem).find('.label-form-UserFirstNameAttribute').html($("#hdnFIRST_NAME_ATTRIBUTE").val());
        $(elem).find('.label-form-UserLastNameAttribute').html($("#hdnLAST_NAME_ATTRIBUTE").val());
        $(elem).find('.label-form-UserEmailAttribute').html($("#hdnUSER_EMAIL_ATTRIBUTE").val());
        $(elem).find('.label-form-AdditionalGroupDN').html($("#hdnADDITIONAL_GROUP_DN").val());
        $(elem).find('.label-form-GroupObjectClass').html($("#hdnGROUP_OBJECT_SCHEMA").val());
        $(elem).find('.label-form-GroupObjectFilter').html($("#hdnGROUP_OBJECT_FILTER").val());
        $(elem).find('.label-form-GroupIDAttribute').html($("#hdnGROUP_ID_ATTRIBUTE").val());
        $(elem).find('.label-form-GroupNameAttribute').html($("#hdnGROUP_NAME_ATTRIBUTE").val());
        $(elem).find('.label-form-GroupMembersAttribute').html($("#hdnGROUP_MEMBERS_ATTRIBUTE").val());
        $(elem).find('.label-form-UserMembershipAttribute').html($("#hdnUSER_MEMBERSHIP_ATTRIBUTE").val());

        $(elem).find('.label-form-ScannerWithoutRoleAttributesGroupDnList').html($("#hdnSCANNER_GROUP_DN").val());
        $(elem).find('.label-form-ScannerWithNotExploitableGroupDnList').html($("#hdnSCANNER_GROUP_DN_WITH_NE").val());
        $(elem).find('.label-form-ScannerWithDeleteGroupDnList').html($("#hdnSCANNER_GROUP_DN_WITH_DELETE").val());
        $(elem).find('.label-form-ScannerWithNotExploitableAndDeleteGroupDnList').html($("#hdnSCANNER_GROUP_DN_WITH_NE_AND_DELETE").val());
        $(elem).find('.label-form-ReviewerWithoutRoleAttributesGroupDnList').html($("#hdnREVIEWER_GROUP_DN").val());
        $(elem).find('.label-form-ReviewerWithSeverityStatusChangeGroupDnList').html($("#hdnREVIEWER_GROUP_DN_SEVERITY_STATUS").val());

        $(elem).find('.label-form-AdvancedRoleMapping').html($("#hdnADVANCED_ROLE_MAPPING").val());
        $(elem).find('.label-form-DefaultRoleId').html($("#hdnDEFAULT_ROLE_ID").val());

        //Parsly
        $(elem).find('[data-name="Port"]').attr("data-parsley-portValidator-message", $("#hdnPARSLY_VALID_NUMBER").val());
    }
})();