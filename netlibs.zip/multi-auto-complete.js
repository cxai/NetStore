var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        // Directive controller implementation
        var MultiAutoCompleteDirective = (function (_super) {
            __extends(MultiAutoCompleteDirective, _super);
            // Constructor (including dependencies that will be inserted automatically by angular)
            function MultiAutoCompleteDirective(scope, $timeout, element) {
                _super.call(this, scope, $timeout);
                this.element = element;
                this.termIndex = -1;
                this.inputElement = this.element.find('input[type="text"]');
                this.tooltipContentElement = this.element.find('.custom-tooltip-inner span');
            }
            MultiAutoCompleteDirective.prototype.onInitialization = function () {
                this.autoCompleteSource = this.source.values;
                this.createAutoComplete();
            };
            MultiAutoCompleteDirective.prototype.onFilteringData = function (valuesToRemove, valuesToKeep) {
                //ensure that the autocomplete only takes values that are not removed by dependencies on other filters.
                this.autoCompleteSource = valuesToKeep;
                //remove obsolete items from UI
                var value = this.inputElement.val();
                var terms = this.split(value);
                terms = terms.filter(function (term) { return valuesToRemove.map(function (badValue) { return badValue.label.toLowerCase(); }).indexOf(term.toLowerCase()) === -1; });
                this.inputElement.val(terms.join(','));
                if (this.inputElement.val() === "") {
                    valuesToKeep.forEach(function (val) { return val.selected = true; });
                }
                this.setTooltipContent();
            };
            MultiAutoCompleteDirective.prototype.split = function (val) {
                return val.split(/,\s*/);
            };
            MultiAutoCompleteDirective.prototype.removeBadTextBoxContent = function (terms) {
                var labels = this.autoCompleteSource.map(function (value) { return value.label.toLowerCase(); });
                terms = terms.filter(function (term) { return labels.indexOf(term.toLowerCase()) !== -1; });
                if (terms && terms.length > 0 && terms[terms.length - 1] !== '') {
                    terms.push('');
                }
                this.inputElement.val(terms.join(","));
                return terms;
                /*var toDelete = true;
                terms.forEach((value) => {
                    for (var i = 0; i < this.autoCompleteSource.length; i++) {
                        if (this.autoCompleteSource[i].label === value) {
                            toDelete = false;
                            break;
                        }
                        else {
                            toDelete = true;
                        }
                    }
                    if (toDelete) {
                        if (!!value) {
                            var index = terms.indexOf(value);
                            terms.splice(index, 1);
                            if (terms && terms.length > 0 && terms[terms.length - 1].length > 0) {
                                //add placeholder to get the comma-and-space at the end
                                terms.push("");
                            }
                            this.inputElement.val(terms.join(","));
                        }
                    }
                });*/
            };
            MultiAutoCompleteDirective.prototype.setTooltipContent = function () {
                var value = this.inputElement.val();
                var content = this.autoCompleteSource.filter(function (val) { return val.selected; }).map(function (val) { return val.label; }).join(', ');
                if (content.length > 500) {
                    content = content.substring(0, 500) + '...';
                }
                this.tooltipContentElement.text(content);
            };
            MultiAutoCompleteDirective.prototype.createAutoComplete = function () {
                var _this = this;
                this.autoComplete = this.inputElement.on({
                    keydown: function (event) {
                        var $ = angular.element;
                        if (event.keyCode === $.ui.keyCode.TAB &&
                            _this.inputElement.autocomplete('instance').menu.active) {
                            event.preventDefault();
                        }
                        else if (event.keyCode === $.ui.keyCode.RIGHT || event.keyCode === $.ui.keyCode.LEFT) {
                            setTimeout(function () { return _this.handleSelectionChanged(); }, 0);
                        }
                        _this.setTooltipContent();
                    },
                    mousedown: function (event) {
                        setTimeout(function () { return _this.handleSelectionChanged(); }, 0);
                    },
                    focus: function (event) {
                        setTimeout(function () { return _this.handleSelectionChanged(); }, 0);
                    },
                    blur: function (event) {
                        var terms = _this.split(_this.inputElement.val());
                        terms = _this.removeBadTextBoxContent(terms);
                        _this.updateDataSource(terms);
                        _this.setTooltipContent();
                    }
                }).autocomplete({
                    minLength: 0,
                    source: function (request, response) {
                        var elementText = _this.inputElement.val();
                        var terms = _this.split(elementText);
                        var currentPosition = _this.inputElement.context.selectionStart;
                        _this.termIndex = Math.max(0, _this.split(elementText.substring(0, currentPosition)).length - 1); //get real value
                        var theTerm = terms[_this.termIndex];
                        var result = _this.autoCompleteSource
                            .filter(function (val) {
                            //find the values that contain the searched term
                            return val.label.toLowerCase().indexOf(theTerm.toLowerCase()) !== -1 &&
                                //except all of the items that are already selected
                                terms.slice(0, _this.termIndex)
                                    .concat(terms.slice(_this.termIndex + 1))
                                    .map(function (t) { return t.toLowerCase(); })
                                    .indexOf(val.label.toLowerCase()) == -1;
                        });
                        response((result || []).slice(0, 50));
                        _this.setTooltipContent();
                    },
                    focus: function () {
                        _this.setTooltipContent();
                        // prevent value inserted on focus
                        return false;
                    },
                    select: function (event, ui) {
                        var terms = _this.split(_this.inputElement.val());
                        //remove the old value and insert the new one
                        terms.splice(_this.termIndex, 1, ui.item.label);
                        _this.updateDataSource(terms);
                        //don't add "," if the terms is not empty
                        if (terms[terms.length - 1].length > 0) {
                            //add placeholder to get the comma-and-space at the end
                            terms.push("");
                        }
                        _this.inputElement.val(terms.join(","));
                        _this.setTooltipContent();
                        //this.termIndex = -1;
                        return false;
                    }
                });
                this.setTooltipContent();
            };
            MultiAutoCompleteDirective.prototype.handleSelectionChanged = function () {
                if (this.inputElement.autocomplete('instance')) {
                    this.inputElement.autocomplete('search', '');
                }
            };
            MultiAutoCompleteDirective.prototype.updateDataSource = function (terms) {
                this.source.values.forEach(function (value) {
                    var noTermsAllValues = !terms || terms.length == 0 || (terms.length === 1 && terms[0] === "");
                    value.selected = noTermsAllValues || terms.indexOf(value.label) !== -1;
                });
                this.notifyChange();
            };
            // Specify the dependencies for this directive    
            MultiAutoCompleteDirective.$inject = ['$scope', '$timeout', '$element'];
            return MultiAutoCompleteDirective;
        }(Directives.BaseFilter));
        // Directive configuration
        function MultiAutoCompleteDirectiveSettings() {
            return {
                restrict: 'E',
                replace: true,
                controller: MultiAutoCompleteDirective,
                controllerAs: 'root',
                templateUrl: '/CxWebClient/pages/common/MultiAutoComplete',
                bindToController: true,
                scope: {
                    source: '='
                }
            };
        }
        Directives.MultiAutoCompleteDirectiveSettings = MultiAutoCompleteDirectiveSettings;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=multi-auto-complete.js.map