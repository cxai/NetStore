var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        var C = Checkmarx.Constants;
        var BaseWidget = (function (_super) {
            __extends(BaseWidget, _super);
            function BaseWidget(netService, scope) {
                var _this = this;
                _super.call(this);
                this.netService = netService;
                this.scope = scope;
                this.containerActive = false;
                //the widget listen to DataFilterChangedEvent from widgetShell (widget.ts) broadcast
                this.scope.$on(C.Events.DataFilterChangedEvent, function () {
                    _this.getWidgetData();
                });
                //the widget listen to RefreshRateEvent from widgetShell (widget.ts) broadcast
                this.scope.$on(C.Events.RefreshRateEvent, function () {
                    _this.getWidgetData();
                });
                this.registerWatch(this.scope, function () { return _this.config.filters; }, function (nv, ov) {
                    if (!!nv) {
                        _this.getWidgetData();
                    }
                });
            }
            BaseWidget.prototype.getWidgetData = function () {
                var _this = this;
                this.netService.getWidgetData(this.config).then(function (data) { return _this.initializeData(data); });
            };
            BaseWidget.prototype.initializeData = function (data) {
                this.widgetData = data;
                //the widget fire DataReceived event up to the widgetShell (widget.ts)
                this.scope.$emit(C.Events.DataReceived, { lastUpdated: data.data.updatedOn });
            };
            return BaseWidget;
        }(Directives.BaseController));
        Directives.BaseWidget = BaseWidget;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=base-widget.js.map