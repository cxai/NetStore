﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    "use strict";

    checkmarx.CxPortal.factory('CxPortal.AjaxServiceWithNotification', ['ajaxService', 'CxPortal.NotificationService', '$q',
        function (ajaxService, notificationService, $q) {
            /* 
            *   note: the additional $q added due to the migration of angular 1.3 to 1.6, that's because succes/error callback function are not supported anymore.
            */

            function displayError(data) {

                notificationService.error((data && data.messageDetails) || "");
            }

            function get(url, config) {

                var deferred = $q.defer();

                ajaxService.get(url, config)
                    .then(function (result) {
                        deferred.resolve(result.data);
                    })
                    .catch(function (result, status, headers, config) {
                        displayError(result.data);
                        deferred.reject(result.data);
                    });

                return deferred.promise;
            }

            function post(url, data, config) {

                var deferred = $q.defer();

                ajaxService.post(url, data || {}, config)
                    .then(function (result) {
                        deferred.resolve(result.data);
                    })
                    .catch(function (result, status, headers, config) {

                        if (result && result.data.messageCode) {
                            displayError(result.data);
                            deferred.reject(result.data);
                        }
                    });

                return deferred.promise;
            }

            function put(url, data, config) {

                var deferred = $q.defer();

                ajaxService.put(url, data || {}, config)
                    .then(function (result) {
                        deferred.resolve(result.data);
                    })
                    .catch(function (result, status, headers, config) {

                        if (result && result.data.messageCode) {
                            displayError(result.data);
                            deferred.reject(result.data);
                        }
                    });

                return deferred.promise;
            }

            function sendDeleteRequest(url, config) {
                /* The name "delete" could not be used for this function since is a keyword of the language and is invalid to use it for an identifier. */

                var deferred = $q.defer();

                ajaxService.sendDeleteRequest(url, config)
                    .then(function (result) {
                        deferred.resolve(result.data);
                    })
                    .catch(function (result, status, headers, config) {

                        if (result && result.data.messageCode) {
                            displayError(result.data);
                            deferred.reject(result.data);
                        }
                    });

                return deferred.promise;
            }

            function patch(url, data) {

                var deferred = $q.defer();

                ajaxService.patch(url, data || {})
                    .then(function (result) {
                        deferred.resolve(result.data);
                    })
                    .catch(function (result, status, headers, config) {

                        if (data && result.data.messageCode) {
                            displayError(result.data);
                            deferred.reject(result.data);
                        }
                    });

                return deferred.promise;
            }

            return {
                get: get,
                post: post,
                put: put,
                sendDeleteRequest: sendDeleteRequest,
                patch: patch
            };

        }]);
})();