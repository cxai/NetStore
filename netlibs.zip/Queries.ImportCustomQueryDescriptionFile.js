﻿(function () {
    "use strict";

    checkmarx.Queries.directive('importCustomQueryDescriptionFile', function () {

        return {
            template: '<portal-File-Upload files="files" '
                            + 'control-id="flpImportCustomDescription" '
                            + 'name="flpImportCustomDescription"'
                            + 'filter-files=".htm,.html"'
                            + 'image-src="app/portal/styles/images/file-icon.png" '
                            + 'message="{{\'FILE_UPLOAD_MESSAGE\' | translate}}"></portal-File-Upload>',
            restrict: 'E'
        };
    });
})();