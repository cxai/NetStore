﻿/// <reference path="../../app.js" />

(function () {
    "use strict";

    checkmarx.Queries.factory('Queries.CustomDescriptionDataService', ['$q', 'CxPortal.AjaxServiceWithNotification', 'apiBaseURLService',
        function ($q, ajaxServiceWithNotification, apiBaseURLService) {

            function buildConfig(data) {

                return {
                    headers: {
                        'Content-Type': undefined
                    }
                };
            }

            function getCustomDescription(url) {

                url = apiBaseURLService.getAPIVirtualDirectory() + '/' + url;

                return ajaxServiceWithNotification.get(url);
            }

            function postNewCustomDescription(data) {

                var url = apiBaseURLService.getAPIVirtualDirectory() + '/Queries/' + data.queryId + '/CustomDescription';

                return ajaxServiceWithNotification.post(url, data.formData, buildConfig(data));
            }

            function updateCustomDescription(data) {

                var url = apiBaseURLService.getAPIVirtualDirectory() + '/Queries/' + data.queryId + '/CustomDescription';

                return ajaxServiceWithNotification.put(url, data.formData, buildConfig(data));
            }

            function deleteCustomDescription(queryId) {

                var url = apiBaseURLService.getAPIVirtualDirectory() + '/Queries/' + queryId + '/CustomDescription';

                return ajaxServiceWithNotification.sendDeleteRequest(url);
            }

            return {
                getCustomDescription: getCustomDescription,
                postNewCustomDescription: postNewCustomDescription,
                updateCustomDescription: updateCustomDescription,
                deleteCustomDescription: deleteCustomDescription
            };
    }]);

})();