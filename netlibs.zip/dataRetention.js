﻿$(function () {
    toastr.options = {
        'closeButton': true,
        'debug': false,
        'newestOnTop': true,
        'progressBar': true,
        'positionClass': 'toast-top-right',
        'preventDuplicates': true,
        'showDuration': '300',
        'hideDuration': '1000',
        'timeOut': '5000',
        'extendedTimeOut': '1000',
        'showEasing': 'swing',
        'hideEasing': 'linear',
        'showMethod': 'fadeIn',
        'hideMethod': 'fadeOut'
    }

    var parsleyForm = $('form').parsley();

    $('#retention-stages-container .stage').hide();

    $.listen('parsley:field:validated', function (field) {
        var $elem = field.$element;
        if ($elem.attr('data-input-type') === 'spinner') {
            var $spinner = $elem.closest('.ui-spinner');
            if (field.isValid()) {
                $spinner.removeClass('error-border');
            } else {
                $spinner.addClass('error-border');
            }
        }
    });
    $('input[data-input-type="spinner"]').on('blur', function () {
        $(this).parsley().validate();
    }).spinner({
        spin: function (event, ui) {
            var $this = $(this),
                min = parseInt($this.attr('data-min')),
                max = parseInt($this.attr('data-max'));
            if (!isNaN(min) && ui.value < min) {
                $this.spinner('value', min);
                return false;
            }
            if (!isNaN(max) && ui.value > max) {
                $this.spinner('value', max);
                return false;
            }
            $(this).parsley().validate();
        }
    });
    $('#inputDateTo').on('changeDate', function (event) {
        $(this).parsley().validate();
    })
    $('.input-daterange').datepicker({
        language: convertCultureNameFromDotNetToBootstrapDatePicker(UIConsts.Culture),
        format: convertDateFormatFromDotNetToBootstrapDatepicker(UIConsts.PageDateFormat),
        todayHighlight: true,
        toggleActive: true,
        orientation: 'bottom auto'
    });

    $('#btnStop').button().click(function (event) {
        swal({
            title: UIMessages.confirmationTitle,
            text: UIMessages.stopConfirmation,
            icon: 'warning',
            buttons: {
                cancel: {
                    text: UIMessages.cancel,
                    closeModal: true,
                    visible: true
                },
                confirm: {
                    text: UIMessages.confirm,
                    closeModal: true,
                    visible: true
                }
            },
            dangerMode: true
        }).then(
        function (isConfirmed) {
            if (isConfirmed) {
                $('#btnStop').button('disable');
                $.ajax({
                    type: 'POST',
                    url: 'DataRetention.aspx/StopDataRetentiton',
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json',
                    success: function (response) {
                        if (response.d == null) {
                            window.top.location.href = UIConsts.loginPageURL;
                        } else if (!response.d.IsSuccesfull) {
                            toastr.error(response.d.ErrorMessage || UIMessages.generalError);
                            $('#btnStop').button('enable');
                        } else {
                            updateStatus({ Status: UIConsts.RetentionStages.Stopping });
                            toastr.success(UIMessages.stopInfo);
                        }
                    },
                    failure: function (response) {
                        toastr.error(UIMessages.generalError);
                        $('#btnStop').button('enable');
                    }
                });
            }
            $(document).trigger('sweetalert-modal-closed');
        });

        return stopEvent(event);
    });


    $('#btnStart').button().click(function (event) {


        var defaultValue =  '1/1/1970';
        var $this = $(this),
            duration = parseInt($('#inputHoursToRun').val()) || null,
            retentionType = $('#data-retention-container input[type="radio"]:checked').val(),
            scansToKeep = parseInt($('#inputScansToKeep').val()) || null,
            dateFrom = $('#inputDateFrom').datepicker('getDate') || defaultValue,
            dateTo = $('#inputDateTo').datepicker('getDate') || null;

        dateFrom = dateFrom != defaultValue ? convertLocalDateToUTC(dateFrom) : dateFrom;
        dateTo = dateTo ? convertLocalDateToUTC(dateTo) : dateTo;

        var currentMessage = (retentionType === 'DateRange')
                ? (!dateFrom || dateFrom == defaultValue)
                    ? formatString(UIMessages.dateRangeUpToWarning, new Date(dateTo).toUTCString())
                    : formatString(UIMessages.dateRangeFromToWarning, new Date(dateFrom).toUTCString(), new Date(dateTo).toUTCString())
                : retentionType === 'LastXScans'
                    ? formatString(UIMessages.lastXScansWarning, scansToKeep)
                    : '';

        

        if (parsleyForm.validate() === true) {
            var span = document.createElement("span");
            var innerSpan = document.createElement("span");
            span.innerHTML = UIMessages.backupDbWarning;
            innerSpan.innerHTML = currentMessage;
            span.appendChild(innerSpan);

            swal({
                title: UIMessages.confirmationTitle,
                icon: 'warning',
                content: span,
                buttons: {
                    cancel: {
                        text:UIMessages.cancel,
                        closeModal: true,
                        visible:true
                    },
                    confirm: {
                        text: UIMessages.confirmDeletion,
                        closeModal: true,
                        visible: true
                    }
                },
                dangerMode: true,
                className: 'data-retention-swal'
            }).then(
            function (isConfirmed) {
                if (isConfirmed) {
                    clearTimeout(checkInterval);
                    $('#btnStart').hide();
                    $('#btnStop').show();
                    $.ajax({
                        type: 'POST',
                        url: 'DataRetention.aspx/StartDataRetentiton',
                        data: JSON.stringify({
                            config: {
                                retentionType: retentionType,
                                scansToKeep: scansToKeep,
                                dateFrom: dateFrom,
                                dateTo: dateTo,
                                durationLimit: duration
                            }
                        }),
                        contentType: 'application/json; charset=utf-8',
                        dataType: 'json',
                        success: function (response) {
                            if (response.d == null) {
                                window.top.location.href = UIConsts.loginPageURL;
                            } else if (!response.d.IsSuccesfull) {
                                toastr.error(response.d.ErrorMessage || UIMessages.generalError);
                                updateStatus({ Status: UIConsts.RetentionStages.Configuration });
                            } else {
                                toastr.success(UIMessages.started);
                                updateStatus({ Status: UIConsts.RetentionStages.Cleanup });
                            }
                        },
                        failure: function (response) {
                            toastr.error(UIMessages.generalError);
                            updateStatus({ Status: UIConsts.RetentionStages.Configuration });
                        }
                    });
                }
                $(document).trigger('sweetalert-modal-closed');
            });
        }

        return stopEvent(event);
    });
    $('#data-retention-container input[type="radio"]').click(function (event) {
        updateEnabledPanels();
    });

    updateEnabledPanels();
    checkStatus();


    function convertLocalDateToUTC(date) {
        date = Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
        return new Date(date);
    }

    function formatString(format) {
        var parameters = Array.prototype.slice.call(arguments, 1);
        return format.replace(/\{\d\}/gi, function (m, idx, str) {
            var paramIdx = parseInt(m[1], 10);
            var parameter = parameters[paramIdx];
            return parameter === null || parameter === undefined
                ? ''
                : parameter.toString();
        });
    }

    function convertCultureNameFromDotNetToBootstrapDatePicker(culture) {
        var ieftTag = culture.ieftTag,
            twoLetterIsoName = culture.twoLetterIsoName;
        return twoLetterIsoName == 'zh'
            ? ieftTag
            : twoLetterIsoName;
    }

    function convertDateFormatFromDotNetToBootstrapDatepicker(format) {
        return format
            .replace(/([^d]|\b)ddd([^d]|\b)/, '$1D$2')
            .replace(/([^d]|\b)dddd([^d]|\b)/, '$1DD$2')
            .replace(/([^M]|\b)M([^M]|\b)/, '$1m$2')
            .replace(/([^M]|\b)MM([^M]|\b)/, '$1mm$2')
            .replace(/([^M]|\b)MMM([^M]|\b)/, '$1M$2')
            .replace(/([^M]|\b)MMMM([^M]|\b)/, '$1MM$2')
            .replace(/([^y]|\b)y([^y]|\b)/, '$1yy$2')
            .replace(/([^y]|\b)yyy([^y]|\b)/, '$1yyyy$2')
            .replace(/([^y]|\b)yyyyy([^y]|\b)/, '$1yyyy$2');
    }

    function updateEnabledPanels() {
        parsleyForm.reset();
        $('input[data-input-type="spinner"]').closest('.ui-spinner').removeClass('error-border');
        var checkedValue = $('#data-retention-container input[type="radio"]:checked').val();
        if (checkedValue == 'DateRange') {
            $('#cbxDateRange').prop('checked', true);
            toggleLastXScansPanel(false);
            toggleDateRangePanel(true);
        } else {
            $('#cbxLastScans').prop('checked', true);
            toggleLastXScansPanel(true);
            toggleDateRangePanel(false);
        }
        parsleyForm.validate();
    }

    function toggleLastXScansPanel(enabled) {
        if (enabled) {
            $('#inputScansToKeep').spinner('enable');
        } else {
            $('#inputScansToKeep').spinner('disable');
        }
    }

    function toggleDateRangePanel(enabled) {
        if (enabled) {
            $('#inputDateFrom').removeAttr('disabled');
            $('#inputDateTo').removeAttr('disabled');
        } else {
            $('#inputDateFrom').attr('disabled', 'disabled');
            $('#inputDateTo').attr('disabled', 'disabled');
        }
    }

    function stopEvent(event) {
        if (event.preventDefault)
            event.preventDefault();
        if (event.stopPropagation)
            event.stopPropagation();
        if (event.stopImmediatePropagation)
            event.stopImmediatePropagation();
        return false;
    }

    function checkStatus() {
        $.ajax({
            type: 'POST',
            url: 'DataRetention.aspx/CheckDataRetentitonStatus',
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            success: function (response) {
                if (response.d == null) {
                    window.top.location.href = UIConsts.loginPageURL;
                } else if (!response.d.IsSuccesfull) {
                    toastr.error(response.d.ErrorMessage || UIMessages.generalError);
                    checkInterval = setTimeout(checkStatus, UIConsts.StatusCheckInterval);
                } else {
                    updateStatus(response.d);
                }
            },
            failure: function (response) {
                toastr.error(UIMessages.generalError);
                checkInterval = setTimeout(checkStatus, UIConsts.StatusCheckInterval);
            }
        });
        GetDataRetentionHistory();
    }

    var checkInterval;

    function updateStatus(statusInfo) {
        clearTimeout(checkInterval);

        var stage = parseInt(statusInfo.Status) || UIConsts.RetentionStages.Configuration,
            currentProgress = parseInt(statusInfo.CurrentProgress),
            totalProgress = parseInt(statusInfo.TotalProgress),
            stageError = statusInfo.StageError;

        var $stages = $('#retention-stages-container .stage'),
            $currentStage = $stages.filter('.stage-' + stage),
            $currentStageDetailsTooltip = $currentStage.find('.details-tooltip'),
            $currentStageDetailsTooltipText = $currentStageDetailsTooltip.find('.tooltip-message'),
            $currentStageErrorTooltip = $currentStage.find('.error-tooltip'),
            $currentStageErrorTooltipText = $currentStageErrorTooltip.find('.tooltip-message');

        $stages.find('.details-tooltip, .error-tooltip').hide();

        if (!isNaN(currentProgress) && !isNaN(totalProgress)) {
            if (stage == UIConsts.RetentionStages.Stopped) {
                $currentStageDetailsTooltipText.text(formatString('{0} \n{1} {2} / {3}', UIMessages.stoppedWarning, UIMessages.deleted, currentProgress, totalProgress));
                $currentStageDetailsTooltip.show();
            } else if (stage != UIConsts.RetentionStages.Cleanup) {
                $currentStageDetailsTooltipText.text(formatString('{0} {1} / {2}', UIMessages.deleted, currentProgress, totalProgress));
                $currentStageDetailsTooltip.show();
            } else {
                $currentStageDetailsTooltipText.text('');
                $currentStageDetailsTooltip.hide();
            }
        } else {
            if (stage == UIConsts.RetentionStages.Stopped) {
                $currentStageDetailsTooltipText.text(UIMessages.stoppedWarning);
                $currentStageDetailsTooltip.show();
            } else {
                $currentStageDetailsTooltipText.text('');
                $currentStageDetailsTooltip.hide();
            }
        }

        if (stageError) {
            $currentStageErrorTooltipText.text(stageError);
            $currentStageErrorTooltip.show();
        } else {
            $currentStageErrorTooltipText.text('');
            $currentStageErrorTooltip.hide();
        }

        if (stage == UIConsts.RetentionStages.None ||
            stage == UIConsts.RetentionStages.Configuration ||
            stage == UIConsts.RetentionStages.Stopped ||
            stage == UIConsts.RetentionStages.Failed ||
            stage == UIConsts.RetentionStages.Finished) {
            $('#btnStop').button('disable');
            $('#btnStart').button('enable');
            $('#btnStop').hide();
            $('#btnStart').show();
        } else {
            if (stage == UIConsts.RetentionStages.Stopping) {
                $('#btnStop').button('disable');
            } else {
                $('#btnStop').button('enable');
            }
            $('#btnStart').button('disable');
            $('#btnStart').hide();
            $('#btnStop').show();
        }

        switch (stage) {
            case UIConsts.RetentionStages.Cleanup:
                $stages.filter('.stage-' + UIConsts.RetentionStages.Configuration).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Cleanup).removeClass('error').addClass('inprogress').removeClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Deletion).removeClass('error').removeClass('inprogress').removeClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopping).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopped).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Failed).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Finished).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $('#retention-stages-section').show();
                break;
            case UIConsts.RetentionStages.Deletion:
                $stages.filter('.stage-' + UIConsts.RetentionStages.Configuration).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Cleanup).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Deletion).removeClass('error').addClass('inprogress').removeClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopping).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopped).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Failed).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Finished).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $('#retention-stages-section').show();
                break;
            case UIConsts.RetentionStages.Stopping:
                $stages.filter('.stage-' + UIConsts.RetentionStages.Configuration).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Cleanup).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Deletion).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopping).removeClass('error').addClass('inprogress').removeClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopped).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Failed).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Finished).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $('#retention-stages-section').show();
                break;
            case UIConsts.RetentionStages.Stopped:
                $stages.filter('.stage-' + UIConsts.RetentionStages.Configuration).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Cleanup).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Deletion).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopping).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopped).removeClass('error').removeClass('inprogress').removeClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Failed).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Finished).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $('#retention-stages-section').show();
                break;
            case UIConsts.RetentionStages.Failed:
                $stages.filter('.stage-' + UIConsts.RetentionStages.Configuration).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Cleanup).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Deletion).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopping).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopped).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Failed).addClass('error').removeClass('inprogress').removeClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Finished).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $('#retention-stages-section').show();
                break;
            case UIConsts.RetentionStages.Finished:
                $stages.filter('.stage-' + UIConsts.RetentionStages.Configuration).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Cleanup).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Deletion).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopping).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopped).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Failed).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Finished).removeClass('error').removeClass('inprogress').addClass('ok').show();
                $('#retention-stages-section').show();
                break;
            case UIConsts.RetentionStages.None:
            case UIConsts.RetentionStages.Configuration:
            default:
                $stages.filter('.stage-' + UIConsts.RetentionStages.Configuration).removeClass('error').removeClass('inprogress').removeClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Cleanup).removeClass('error').removeClass('inprogress').removeClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Deletion).removeClass('error').removeClass('inprogress').removeClass('ok').show();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopping).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Stopped).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Failed).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $stages.filter('.stage-' + UIConsts.RetentionStages.Finished).removeClass('error').removeClass('inprogress').removeClass('ok').hide();
                $('#retention-stages-section').hide();
                break;
        }
        checkInterval = setTimeout(checkStatus, UIConsts.StatusCheckInterval);
    }

    function GetDataRetentionHistory() {
        $.ajax({
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            type: 'POST',
            url: 'DataRetention.aspx/GetLatestFinishedDataRetentionRequest',
            success: function (response) {
                if (response.d == null) {
                    window.top.location.href = UIConsts.loginPageURL;
                } else if (!response.d.IsSuccesfull) {
                    toastr.error(response.d.ErrorMessage || UIMessages.generalError);
                } else {
                    updateDataRetentionHistoryInfo(response.d.LastRequest)
                }
            },
            failure: function (response) {
                toastr.error(UIMessages.generalError);
            }
        });
    };

    function updateDataRetentionHistoryInfo(lastRequest) {
        if (!lastRequest) {
            $('#history-area').hide();
        } else {
            var duration = formatDuration(lastRequest),
                progress = formatProgress(lastRequest);

            $('#history-initiator').text(lastRequest.initiatorName);
            $('#history-request-date').text(lastRequest.requestDate);
            $('#history-duration').text(duration);
            $('#history-stage').text(lastRequest.stage);
            $('#history-error').text(lastRequest.stageError);
            $('#history-progress').text(progress);

            if (!!lastRequest.configuration) {
                var scansToKeepString = lastRequest.configuration.scansToKeep,
                    rangeString = formatString('{0} - {1}', lastRequest.configuration.dateFromText, lastRequest.configuration.dateToText),
                    limitString = lastRequest.configuration.durationLimit || '';

                if (lastRequest.configuration.retentionType === UIConsts.RetentionTypes.KeepLastScans) {
                    $('#history-config-retention-type').text(UIMessages.keepLastScansTypeName);
                    $('#history-scans-to-keep').text(scansToKeepString);
                    $('#history-date-range').text('');
                    $('#history-scans-to-keep-container').show();
                    $('#history-date-range-container').hide()
                } else {
                    $('#history-config-retention-type').text(UIMessages.dateRangeTypeName);
                    $('#history-scans-to-keep').text('');
                    $('#history-date-range').text(rangeString);
                    $('#history-scans-to-keep-container').hide();
                    $('#history-date-range-container').show()
                }
                if (!!limitString) {
                    $('#history-duration-limit').text(limitString);
                    $('#history-duration-limit-container').show();
                } else {
                    $('#history-duration-limit').text('');
                    $('#history-duration-limit-container').hide();
                }
                $('#history-config-section').show();
            } else {
                $('#history-config-section').hide();
            }

            if (!!lastRequest.stageError)
                $('#history-error-container').show();
            else
                $('#history-error-container').hide();

            if (!!progress)
                $('#history-progress-container').show();
            else
                $('#history-progress-container').hide();

            $('#history-area').css('visibility', 'visible').show();
        }
    }

    function formatDuration(dataRetentionRequest) {
        var durationText = '';
        if (!!dataRetentionRequest.duration) {
            if (!!dataRetentionRequest.duration.Days)
                durationText += dataRetentionRequest.duration.Days + ' ' + UIMessages.days + ' ';
            if (!!dataRetentionRequest.duration.Hours)
                durationText += dataRetentionRequest.duration.Hours + ' ' + UIMessages.hours + ' ';
            if (!!dataRetentionRequest.duration.Minutes)
                durationText += dataRetentionRequest.duration.Minutes + ' ' + UIMessages.minutes + ' ';
            if (!!dataRetentionRequest.duration.Seconds)
                durationText += dataRetentionRequest.duration.Seconds + ' ' + UIMessages.seconds + ' ';
            if (!durationText)
                durationText += ' 1 ' + UIMessages.seconds + ' ';
        }
        return durationText;
    }

    function formatProgress(dataRetentionRequest) {
        var current = parseInt(dataRetentionRequest.currentProgress),
            total = parseInt(dataRetentionRequest.totalProgress);

        return (!isNaN(current) && !isNaN(total) && total > 0)
            ? formatString('{0} / {1}', current, total)
            : '';
    }
});