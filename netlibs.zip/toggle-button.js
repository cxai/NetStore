var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        // Directive controller implementation
        var ToggleButtonDirective = (function (_super) {
            __extends(ToggleButtonDirective, _super);
            // Constructor (including dependencies that will be inserted automatically by angular)
            function ToggleButtonDirective(scope) {
                var _this = this;
                _super.call(this);
                this.scope = scope;
                //set the selected tab when the data is returned
                this.registerWatch(this.scope, function () { return _this.source; }, function (nv, ov) {
                    if (!!nv) {
                        _this.setSelected();
                    }
                });
            }
            ToggleButtonDirective.prototype.onSelect = function (valueViewModel) {
                for (var i = 0; i < this.source.values.length; i++) {
                    if (this.source.values[i].value == valueViewModel.value) {
                        this.source.values[i].selected = true;
                    }
                    else {
                        this.source.values[i].selected = false;
                    }
                }
            };
            ToggleButtonDirective.prototype.setSelected = function () {
                for (var i = 0; i < this.source.values.length; i++) {
                    var valueViewModel = this.source.values[i];
                    if (valueViewModel.selected) {
                        //there was a problem when a toggle button was initilize as selected and then we
                        //change the selection, there wasn't change in the reference so we used angular.copy
                        //for deep copy
                        this.scope['selectedViewModel'] = angular.copy(valueViewModel);
                        break;
                    }
                }
            };
            // Specify the dependencies for this directive    
            ToggleButtonDirective.$inject = ['$scope'];
            return ToggleButtonDirective;
        }(Directives.BaseController));
        // Directive configuration
        function ToggleButtonDirectiveSettings() {
            return {
                restrict: 'E',
                replace: true,
                controller: ToggleButtonDirective,
                controllerAs: 'root',
                templateUrl: '/CxWebClient/pages/common/ToggleButton',
                bindToController: true,
                scope: {
                    source: '=',
                    onChange: '=?'
                }
            };
        }
        Directives.ToggleButtonDirectiveSettings = ToggleButtonDirectiveSettings;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=toggle-button.js.map