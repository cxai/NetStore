/* This file contains DTOs that are received from the server */
// ReSharper restore InconsistentNaming
//# sourceMappingURL=models.js.map