﻿(function () {
    "use strict";

    checkmarx.ApplicationSettings.value('generalSettingsValues', {
        emailFromExample: 'noreply@checkmarx.com',
        checkmarxKnowledgeCenterURL : 'https://checkmarx.atlassian.net/wiki/display/KC/Checkmarx+Knowledge+Center'
    });

})();
