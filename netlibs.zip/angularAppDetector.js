﻿/*
 * use this util for detect whether an angular app scope is exists or not.
 * api: isAppScopeExists function. this function returns promise.
 */

var AngularAppDetector = {};

(function () {
    "use strict";

    function isDOMReadyForRunningAngularApp(element) {

        return angular
                && angular.element(element)
                    && angular.element(element).scope();
    }
    
    AngularAppDetector.isAppScopeExists = function(element){
    
        var deferred = $.Deferred();

        var checkSelector = setInterval(function () {

            if (isDOMReadyForRunningAngularApp(element)) {
                deferred.resolve();
                clearInterval(checkSelector);
            }

        }, 200);

        return deferred;
    };
})();