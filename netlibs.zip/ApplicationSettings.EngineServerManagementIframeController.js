﻿
(function () {

    "use strict";

    checkmarx.ApplicationSettings.controller('ApplicationSettings.EngineServerManagementIframeController',
        ['$rootScope', '$scope', function ($rootScope, $scope) {

            $rootScope.specificView = "full-screen-content";

            $scope.$on("$destroy", function () {
                $rootScope.specificView = "";
            });
        }]
    );

}());