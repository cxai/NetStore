﻿(function () {
    "use strict";

    checkmarx.Common.constant("appSettings", {
        restAPIVirtualDirectoryName: "cxrestapi"
    });
}());