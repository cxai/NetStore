﻿
(function () {
    "use strict";

    checkmarx.ProjectState.factory('chartConfigurationDataService', ['$translate', 'chartColumnDataNames', function ($translate, chartColumnDataNames) {

        var patterns = [{
            'id': 'high-recurrent',
            'path': {
                d: 'M 0 0 L 10 10 M 9 -1 L 11 1 M -1 9 L 1 11',
                stroke: '#e14d4d',
                strokeWidth: 3
            }
        },
        {
            'id': 'medium-recurrent',
            'path': {
                d: 'M 0 0 L 10 10 M 9 -1 L 11 1 M -1 9 L 1 11',
                stroke: '#ffc000',
                strokeWidth: 3
            }
        },
        {
            'id': 'low-recurrent',
            'path': {
                d: 'M 0 0 L 10 10 M 9 -1 L 11 1 M -1 9 L 1 11',
                stroke: '#fff200',
                strokeWidth: 3
            }
        },
        {
            'id': 'recurrent',
            'path': {
                d: 'M 0 0 L 10 10 M 9 -1 L 11 1 M -1 9 L 1 11',
                stroke: '#5d6166',
                strokeWidth: 3
            }
        }];

        //set dashed property
        Highcharts.seriesTypes.bar.prototype.pointAttrToOptions.dashstyle = 'dashStyle';
        Highcharts.setOptions({
            lang: {
                thousandsSep: ','
            }
        });

        var stackedBarChartconfig = {
            options: {
                chart: {
                    type: 'column',
                    spacingTop: 0,
                    spacingBottom: 0,
                    style: {
                        fontFamily: 'Roboto',
                        color: '#343a41',
                        fontWeight: '400'
                    },
                    events: {
                        load: function () {
                            load();
                        },
                        redraw: function () {
                            load();
                        }
                    } 
                },
                plotOptions: {
                    column: {
                        stacking: 'normal',
                        pointPadding: 0,
                        borderWidth: 0,
                        dataLabels: {
                            enabled: false,
                            color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white',
                            style: {
                                textShadow: '0 0 3px black, 0 0 3px black'
                            }
                        },
                        events: {
                            legendItemClick: function () {
                                return false; 
                            }
                        }
                    },
                    series: {
                        states: {
                            hover: {
                                enabled: false
                            }
                        }
                    }
                },
                tooltip: {
                    formatter: function () {
                        if (this.series.name == $translate.instant(chartColumnDataNames.Solved)) {
                            if (this.y != 0) {
                                return '<span>' + $translate.instant(chartColumnDataNames.PrevScan) + ': ' + this.total +
                                    '</span><br/><span>( ' + $translate.instant(chartColumnDataNames.Solved) + ': ' + this.y + ' )</span>';
                            }
                            else {
                                return false;
                            }
                        }
                        else if (this.series.name == $translate.instant(chartColumnDataNames.PrevScan)) {
                            return '<span>' + $translate.instant(chartColumnDataNames.PrevScan) + ': ' + this.total +
                                    '</span><br/><span>( ' + $translate.instant(chartColumnDataNames.Solved) + ': ' + (this.total - this.y) + ' )</span>';
                        }
                        else{
                            return '<span>' + this.series.name + ': ' + this.y + '</span>';
                        }
                    },
                    style: {
                        padding: 10,
                        fontWeight: 'normal',
                        color: '#343a41'
                    }
                },
                exporting: {
                    enabled: false
                },
                defs: {
                    patterns: patterns
                },
                legend: {
                    align: 'left',
                    verticalAlign: 'top',
                    layout: 'horizontal',
                    itemStyle: {
                        fontWeight: 'normal',
                        fontFamily: 'Roboto',
                        color: '#343a41',
                        fontSize: 12
                    },
                    itemHoverStyle: {
                        cursor: 'text'
                    },
                    symbolHeight: 15,
                    symbolWidth: 15,
                    itemDistance: 12,
                    marginTop: 0,
                    itemMarginBottom: 4
                },
            },
            title: {
                text: ''
            },
            loading: false,
            yAxis: {
                allowDecimals: false,
                min: 0,
                title: {
                    text: '',
                },
                labels:{
                    style: {
                        fontFamily: 'Roboto',
                        fontWeight: 400,
                        color: '#979ca2',
                        fontSize: 14
                    }
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontFamily: 'Roboto Condensed',
                        fontWeight: 400,
                        color: '#343a41',
                        fontSize: 14
                    }
                }
            }
        };
    
        function isBiggerThanZero(obj) {
            if(obj) {
                return parseFloat(obj.innerHTML) > 0;
            }
            return false;
        };

        function setHeight(labels, labelIndex, columns, columnIndex) {
            if (isBiggerThanZero(labels[labelIndex])) {
                if(columns[columnIndex].height.baseVal.value <= 1) {
                    columns[columnIndex].height.baseVal.value = 2;
                    columns[columnIndex].y.baseVal.value = 179;
                }
            }
        };

        function load() {
            //set solved style for legend
            var element = $(".highcharts-legend-item rect:eq(1)");
            element.attr('stroke-width', 1).attr('stroke', '#b1cc49').attr('fill', '#ffffff').attr('stroke-dasharray', '5,5');

            var columns = $(".highcharts-tracker rect");
            if (columns.length != 0) {
                var labels = $(".highcharts-stack-labels text tspan");
                if (labels.length != 0) {
                    setHeight(labels, 3, columns, 3);
                    setHeight(labels, 4, columns, 4);
                    setHeight(labels, 5, columns, 5);
                    setHeight(labels, 0, columns, 6);
                    setHeight(labels, 1, columns, 7);
                    setHeight(labels, 2, columns, 8);
                }
            }
        };

        return {
            patterns: patterns,
            stackedBarChartconfig: stackedBarChartconfig
        };

    }]);

})();