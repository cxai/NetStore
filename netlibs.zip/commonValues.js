﻿(function () {
    "use strict";

    checkmarx.Common.value('httpStatusCodes', {
        /* 1×× Informational */
        continue: 100,
        switchingProtocols: 101,
        Processing: 102,
        /* 2×× Success */
        ok: 200,
        created: 201,
        accepted: 202,
        nonAuthoritativeInformation: 203,
        noContent: 204,
        resetContent: 205,
        partialContent: 206,
        multiStatus: 207,
        alreadyReported: 208,
        imUsed: 226,
        /* 3×× Redirection */
        multipleChoices: 300,
        movedPermanently: 301,
        found: 302,
        seeOther: 303,
        notModified: 304,
        useProxy: 305,
        temporaryRedirect: 307,
        permanentRedirect: 308,
        /* 4×× Client Error */
        badRequest: 400,
        unauthorized: 401,
        forbidden: 403,
        notFound: 404,
        methodNotAllowed: 405,
        /* 5×× Server Error */
        serverError: 500,
        notImplemented: 501,
        badGateway: 502,
        serviceUnavailable: 503
    });

})();