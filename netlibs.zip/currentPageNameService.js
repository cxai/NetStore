﻿(function () {
    "use strict";

    checkmarx.Common.factory('currentPageNameService', [function () {

        function getCurrentPageName() {
            //get only the page name

            var pageName = location.pathname;
            pageName = pageName.substring(pageName.lastIndexOf("/") + 1);
            pageName = pageName.substring(0, pageName.indexOf("."));

            return pageName;
        };

        return {
            getCurrentPageName: getCurrentPageName
        };
    }]);


})();