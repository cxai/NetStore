﻿if (window["Type"] != undefined) {

    Type.registerNamespace('Cx');

    Cx.SourceFilterPatternControl = function (element) {
        Cx.SourceFilterPatternControl.initializeBase(this, [element]);
    };

    Cx.SourceFilterPatternControl.prototype = {

        set_enabled: function (value) {

            if (value) {
                $telerik.$('#' + this.get_ExcludeFoldersTextElementId()).removeAttr('disabled');
                $telerik.$('#' + this.get_ExcludeFilesTextElementId()).removeAttr('disabled');
            }
            else {
                $telerik.$('#' + this.get_ExcludeFoldersTextElementId()).attr('disabled', 'disabled');
                $telerik.$('#' + this.get_ExcludeFilesTextElementId()).attr('disabled', 'disabled');
            }
        },
        get_ExcludeFoldersTextElementId: function () {
            return this._excludeFoldersTextElementId;
        },
        set_ExcludeFoldersTextElementId: function (value) {
            this._excludeFoldersTextElementId = value;
        },
        get_ExcludeFilesTextElementId: function () {
            return this._excludeFilesTextElementId;
        },
        set_ExcludeFilesTextElementId: function (value) {
            this._excludeFilesTextElementId = value;
        }
    };

    Cx.SourceFilterPatternControl.registerClass("Cx.SourceFilterPatternControl", Sys.UI.Control);
}

function ValidateExcludepatternInput(sender, args) {

    var inputPattern = args.Value;

    if (inputPattern && inputPattern > '' && inputPattern.length > 0) {

        args.IsValid = checkAsterisksInArray(inputPattern);

        if (args.IsValid) {
            checkFieldXSSByRegularExpression(sender, args);
        }
    }
}

function checkAsterisksInArray(inputPattern) {

    inputPattern = inputPattern.trim();
    var array = inputPattern.split(',');

    for (i = 0; i < array.length; i++) {

        pattern = array[i].trim();

        if (pattern.length > 0) {
            var pattern = substringPattern(pattern);
            pattern = pattern.trim();
            if (pattern.length > 255 || pattern.indexOf('*') !== -1 || pattern === "") {
                return false;
            }
        }
    }

    return true;
}

function substringPattern(pattern) {

    if(pattern.charAt(0) == '*')
    {
        pattern = pattern.slice(1);
    }

    if (pattern.charAt(pattern.length-1) == '*') {
        pattern = pattern.substring(0, pattern.length - 1); //removes last character
    }

    return pattern;
}