﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxPortal.directive('loadingSpinner', [function () {

        return {
            template: '<div class="spinner-loader"><span class="spinner-loader-message"></span></div>',
            restrict: 'E'
        };
    }]);
})();