﻿/// <reference path="../../app.js" />

(function () {
    "use strict";

    checkmarx.Queries.factory('Queries.QueryDescriptionDataService', ['$q', 'ajaxService', 'apiBaseURLService', 'queryDescriptionType',
        function ($q, ajaxService, apiBaseURLService, queryDescriptionType) {

            function resolveData(result, queryTypeId, deferred) {

                var data = {
                    queryTypeId: queryTypeId,
                    html: null
                };

                if (result && result.data) {
                    data.html = result.data;
                }

                deferred.resolve(data);
            }

            function loadQueryDescription(url, queryTypeId, deferred) {

                ajaxService.get(apiBaseURLService.getAPIVirtualDirectory() + url).then(function (result) {

                    resolveData(result, queryTypeId, deferred);

                }).catch(function (error) {
                    deferred.reject(error);
                });
            }

            function loadExternalQueryDescription(url, queryTypeId, deferred) {

                return ajaxService.get(apiBaseURLService.getAPIVirtualDirectory() + url);
            }

            function loadCxOrCWRDescription(result, queryId, deferred) {

                if (result.cx != null) {
                    loadQueryDescription(result.cx, queryDescriptionType.cxDescription, deferred);
                }
                else if (result.cwe != null) {
                    loadQueryDescription(result.cwe, queryDescriptionType.CWEDescription, deferred);
                }
                else {
                    deferred.resolve({
                        html: null
                    });
                }
            }

            function getQueryDescription(queryId, descriptions, deferred) {
                
                var url = null;

                if (descriptions.customDescription) {
                    loadQueryDescription(descriptions.customDescription, queryDescriptionType.customDescription, deferred);
                }
                else if (descriptions.externals.teamMentor) {

                    loadExternalQueryDescription(descriptions.externals.teamMentor, queryDescriptionType.externals, deferred).then(function (result) {
                        deferred.resolve({
                            html: result.data
                        });
                    })
                    .catch(function (error) {
                        loadCxOrCWRDescription(descriptions, queryId, deferred);
                    });
                }
                else {
                    loadCxOrCWRDescription(descriptions, queryId, deferred);
                }
            }

            function getQuery(queryId, data) {

                var deferred = $q.defer();

                getQueryDescription(queryId, data.descriptions, deferred);

                return deferred.promise;
            }

            return {
                getQuery: getQuery,
                loadQueryDescription: loadQueryDescription
            };
        }]);

})();