var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        var C = Checkmarx.Constants;
        var BaseFilter = (function () {
            function BaseFilter(scope, $timeout) {
                var _this = this;
                this.scope = scope;
                this.$timeout = $timeout;
                this.dependencies = {};
                this.filtering = false;
                this.awaitingFiltering = false;
                this.clientInitialized = false;
                this.scope.$watch(function () { return _this.source; }, function (nv, ov) {
                    if (!!nv) {
                        _this.initialize();
                    }
                });
                if (this.source.dependencies && this.source.dependencies.length > 0) {
                    this.scope.$root.$on(C.Events.FilterChangedEvent, function (event, dependencyName, dependencyValues) {
                        var index = _this.source.dependencies.indexOf(dependencyName);
                        if (index >= 0) {
                            _this.dependencies['_' + index] = dependencyValues;
                            _this.filterData();
                        }
                    });
                }
                this.scope.$on("$destroy", function () {
                    if (_this.filtersTimeout) {
                        _this.$timeout.cancel(_this.filtersTimeout);
                        _this.filtersTimeout = undefined;
                    }
                });
            }
            BaseFilter.prototype.onFilteringData = function (valuesToRemove, valuesToKeep) { };
            BaseFilter.prototype.onInitialization = function () { };
            BaseFilter.prototype.initialize = function () {
                var _this = this;
                this.filtersTimeout = this.$timeout(function () {
                    _this.onInitialization();
                    _this.clientInitialized = true;
                    if (_this.awaitingFiltering) {
                        _this.awaitingFiltering = false;
                        _this.filterData();
                    }
                    _this.notifyChange();
                    _this.$timeout.cancel(_this.filtersTimeout);
                    _this.filtersTimeout = undefined;
                }, 100);
            };
            BaseFilter.prototype.filterData = function () {
                var _this = this;
                if (!this.clientInitialized) {
                    this.awaitingFiltering = true;
                }
                else {
                    this.filtering = true;
                    var valuesToRemove = [];
                    var valuesToKeep = [];
                    this.source.values.forEach(function (value, index, arr) {
                        var shouldRemove = false;
                        _this.source.dependencies.forEach(function (dependencyName, dependencyIndex, dependencyArray) {
                            if (_this.dependencies['_' + dependencyIndex].indexOf(value.dependencies[dependencyIndex]) == -1) {
                                shouldRemove = true;
                                return;
                            }
                        });
                        if (shouldRemove) {
                            value.selected = false;
                            valuesToRemove.push(value);
                        }
                        else {
                            valuesToKeep.push(value);
                        }
                    });
                    this.onFilteringData(valuesToRemove, valuesToKeep);
                    this.filtering = false;
                    this.notifyChange();
                }
            };
            BaseFilter.prototype.notifyChange = function () {
                if (this.filtering)
                    return;
                this.scope.$root.$broadcast(C.Events.FilterChangedEvent, this.source.parameterName, this.source.values.filter(function (val, idx, arr) { return val.selected; })
                    .map(function (val, idx) { return val.value; }));
            };
            return BaseFilter;
        }());
        Directives.BaseFilter = BaseFilter;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=base-filter.js.map