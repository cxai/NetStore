﻿(function () {
    'use strict';

    checkmarx.CxAcademy.factory('AppSecCoach.AcademyLessonsDataService',
        ['AppSecCoach.LessonsRequestDataService',
        '$q',
        'Common.JSONP',
        'Common.ExpirableLocalStorageService',
        'AppSecCoach.LocalStorageKeys',
        function (lessonsRequestDataService,
            $q,
            jsonp,
            expirableLocalStorageService,
            localStorageKeys) {
            
            function getAcademyLessons() {

                var deferred = $q.defer();
                
                var lessons = expirableLocalStorageService.getJSONItem(localStorageKeys.availableLessons);
                if (lessons) {
                    deferred.resolve(lessons);
                }
                else {
                    loadAcademyLessons().then(function () {
                        deferred.resolve(expirableLocalStorageService.getJSONItem(localStorageKeys.availableLessons));
                    });
                }

                return deferred.promise;
            }

            function loadAcademyLessons() {
                
                return lessonsRequestDataService.getLessonsQueriesRequestData().then(function (lessonsQueriesRequestData) {
                    var url = lessonsQueriesRequestData.url;
                    return jsonp.get(url).then(function (data) {
                        var cacheTimeInHours = 24;
                        expirableLocalStorageService.setJSONItem(localStorageKeys.availableLessons, data.data.available, cacheTimeInHours * 60);
                    }).catch(function (error) {
                        console.log(error);
                    });
                });
            }

            return {
                getAcademyLessons: getAcademyLessons
            };
        }]);
})();