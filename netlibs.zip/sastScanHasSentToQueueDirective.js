﻿(function () {
    "use strict";

    checkmarx.ProjectState.directive('sastScanHasSentToQueue', [function () {

        return {
            controller: ['$scope', 'modalService', 'scanTypes', '$translate',
                function ($scope, modalService, scanTypes, $translate) {

                    var modalTitleKeyTranslation = "";

                    var modal = null;

                    function setModalTitle(scanType) {

                        modalTitleKeyTranslation = (scanType == scanTypes.full)
                            ? $translate.instant('SAST_FULL_SCAN_HAS_SENT_TO_QUEUE')
                                : $translate.instant('SAST_INCREMENTAL_SCAN_HAS_SENT_TO_QUEUE');
                    }

                    function openModal() {

                        var template = '<div class="modal-sast-scan-sent-to-queue">'
                                    + '     <table>'
                                    + '         <tr>'
                                    + '             <td>'
                                    + '                 <img src="app/projectState/style/images/sast_sent_queue.png" />'
                                    + '             </td>'
                                    + '             <td>'
                                    + '                 <span>' + modalTitleKeyTranslation + '</span><br />'
                                    + '                 <a ng-href="/CxWebClient/UserQueue.aspx" class="blue-link">{{"SCAN_QUEUE_DETAILS" | translate}} ></a>'
                                    + '             </td>'
                                    + '         </tr>'
                                    + '     </table>'
                                    + '</div>';

                        modal = modalService.openModalHTMLTemplate(template, 'sast-scan-sent-to-queue');
                    }

                    $scope.$on('openSASTScanHasSentToQueueModal', function (event, scanType) {

                        setModalTitle(scanType);
                        openModal();
                    });
                }]
        };

    }]);

})();