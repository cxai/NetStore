﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.Common.filter('dateByUTCFilter', ['dateTimeFormatterService', 'browserService', 'siteGlobalVariablesProvider',
        function (dateTimeFormaterService, browserService, globalVariables) {
            /* filter for formatting date (not time) based on a given locale. */

            return function (date) {

                var locelizedDate = "";
                var locale = globalVariables.basicVariables().currentCulture;

                if (date) {

                    if (browserService.isIE9() || browserService.isIE10()) {

                        locelizedDate = dateTimeFormaterService.getLocalizedDate(date, {
                            locale: 'UTC'
                        });
                    }
                    else {
                        var dateTime = new Date(date);
                        locelizedDate = dateTime.toLocaleDateString();
                    }
                }

                return locelizedDate;
            };
        }]);

})();