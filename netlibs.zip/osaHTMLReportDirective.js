﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.directive('osaHtmlReport', ['$sce', function ($sce) {

        return {
            template: '<div>'
                        + '<div id="divOSAReport" ng-bind-html="osaDataHTML"></div>'
                    + '</div>',
            scope: {
                osaReportData: '='
            },
            link: function (scope) {
                        
                scope.$watch('osaReportData', function (result) {

                    scope.osaDataHTML = $sce.trustAsHtml(result.osaHTML);
                });
            },
            controller: ['$rootScope', '$scope',
                function ($rootScope, $scope) {
                    
                    function broadcastElementLoaded() {
                        $rootScope.$broadcast('elementLoaded', 'divOSAReport');
                    }

                    function handleUIIndicators() {

                        $scope.showLoading = false;
                        $scope.openSourceAnalyseSpinnerLoading = $rootScope.openSourceAnalyseSpinnerLoading;
                    }

                    $(window).resize(function () {
                        broadcastElementLoaded();
                    });

                    $scope.$on("$destroy", function () {
                        $rootScope.$broadcast('elementDistroyed');
                    }); 

                    broadcastElementLoaded();
                    handleUIIndicators();
            }]
        };
    }]);

})();