﻿
(function () {
    "use strict";

    checkmarx.ProjectState.factory('osaProcessPreventPageNavigationMessage', ['$translate', 'browserService',
        function ($translate, browserService) {

            function getMessage(message) {

                if (browserService.isChrome()) {
                    return $translate.instant('OSA_IS_RUNNING_CONFIRM_MESSAGE'); 
                }
                
                return $translate.instant('OSA_IS_RUNNING_CONFIRM_MESSAGE') + ' '
                            + $translate.instant('LEAVING_PAGE_WARNING_MESSAGE');
            }

            return {
                getMessage: getMessage
            };
        }]);

})();