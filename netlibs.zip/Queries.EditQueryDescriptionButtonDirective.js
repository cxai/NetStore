﻿/// <reference path="app.js" />

(function () {
    "use strict";

    checkmarx.Queries.directive('editQueryDescriptionButton',
        [function () {

            return {
                restrict: 'E',
                template: '<div class="dropdown-container">'
                            + '<button type="button" class="import-button position-right dropdown-menu-button">'
                                + '<img src="app/portal/styles/images/pen.png" />'
                                + '<span class="button-text">{{"CUSTOM_DESCRIPTION_EDIT" | translate}}</span> <span class="caret"></span>'
                            + '</button>'
                            + '<div class="dropdown-menu-content">'
                                + '<span ng-click="updateQueryDiscription()">{{"CUSTOM_DESCRIPTION_UPDATE" | translate}}</span>'
                                + '<span ng-click="deleteQueryDiscription()" class="delete">{{"CUSTOM_DESCRIPTION_DELETE" | translate}}</span>'
                            + '</div>'
                        + '</div>',
                scope: {
                    onDeleteQueryDiscription: '&'
                },
                controller: ['$rootScope', '$scope', function ($rootScope, $scope) {

                    var dropdown = $(".dropdown-menu-content");

                    $('.dropdown-menu-button').click(function(e) {
                        dropdown.toggle();
                    });

                    $(document).mouseup(function (e) {
                        if (dropdown.is(":visible") && $(e.target).parents('.dropdown-container').length == 0) {
                            dropdown.hide();
                        }
                    });

                    $scope.updateQueryDiscription = function () {
                        $rootScope.$broadcast('dialog-open', 'edit');
                        $('.dropdown-menu-content').hide();
                    };

                    $scope.deleteQueryDiscription = function () {
                        $scope.onDeleteQueryDiscription();
                        $('.dropdown-menu-content').hide();
                    };
                }]
            };
        }]);
})();