﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('osaNotificationService', ['notificationService',
        function (notificationService) {
        
            function success(message) {

                notificationService.success(message, {
                    timeOut: 5000,
                    progressBar: true
                });
            }

            function error(message) {

                notificationService.error(message, {
                    timeOut: 5000,
                    progressBar: true,
                    allowHtml: true
                });
            }

            return {
                success: success,
                error: error
            };
    }]);

})();