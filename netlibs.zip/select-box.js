var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Checkmarx;
(function (Checkmarx) {
    var Directives;
    (function (Directives) {
        // Directive controller implementation
        var SelectBoxDirective = (function (_super) {
            __extends(SelectBoxDirective, _super);
            // Constructor (including dependencies that will be inserted automatically by angular)
            function SelectBoxDirective(scope, $timeout, element, parse) {
                _super.call(this, scope, $timeout);
                this.element = element;
                this.parse = parse;
                this.multiSelectedElement = null;
                this.width = element.attr('select-width');
                this.selectBoxWidth = this.width || '200px';
            }
            SelectBoxDirective.prototype.onInitialization = function () {
                this.createSelectBox();
            };
            SelectBoxDirective.prototype.onFilteringData = function (valuesToRemove, valuesToKeep) {
                var _this = this;
                valuesToRemove.forEach(function (value, index, arr) {
                    _this.multiSelectedElement.multiselect('deselect', value.value);
                });
                var $element = angular.element(this.element);
                var listItems = $element.next().find('li').not('.filter').not('.multiselect-all');
                listItems.removeClass('filtered-out');
                listItems.each(function (idx, listItem) {
                    var $listItem = angular.element(listItem);
                    var $checkbox = $listItem.find('input[type = checkbox]');
                    if (valuesToRemove
                        .map(function (val, idx, arr) { return val.value.toString(); })
                        .indexOf($checkbox.val().toString()) != -1) {
                        $listItem.addClass('filtered-out');
                        $checkbox.prop("checked", false).removeAttr("checked");
                    }
                });
                this.multiSelectedElement.multiselect('refresh');
            };
            SelectBoxDirective.prototype.createSelectBox = function () {
                var _this = this;
                this.multiSelectedElement = this.element.multiselect({
                    enableFiltering: true,
                    enableCaseInsensitiveFiltering: true,
                    inheritClass: true,
                    includeSelectAllOption: true,
                    filterBehavior: 'text',
                    onChange: function (element, selected) {
                        if (!element) {
                            if (selected) {
                                _this.selectItem(null);
                            }
                            else {
                                _this.deselectItem(null);
                            }
                        }
                        else {
                            var optionViewModel = { label: element.text(), value: element.val(), selected: selected };
                            if (selected === true) {
                                _this.selectItem(optionViewModel);
                            }
                            else {
                                _this.deselectItem(optionViewModel);
                            }
                        }
                        if (_this.onChange) {
                            _this.onChange();
                        }
                        _this.notifyChange();
                    },
                    maxHeight: 200,
                    buttonWidth: this.selectBoxWidth,
                    buttonText: function (options, select) {
                        if (options.length === 0) {
                            return _this.source.title;
                        }
                        else {
                            var labels = [];
                            options.each(function () {
                                if ($(this).attr('label') !== undefined) {
                                    labels.push($(this).attr('label'));
                                }
                                else {
                                    labels.push($(this).html());
                                }
                            });
                            return labels.join(', ') + '';
                        }
                    }
                });
            };
            SelectBoxDirective.prototype.selectItem = function (option) {
                for (var i = 0; i < this.source.values.length; i++) {
                    if (!option || this.source.values[i].value == option.value) {
                        this.source.values[i].selected = true;
                        if (!!option)
                            break;
                    }
                }
            };
            SelectBoxDirective.prototype.deselectItem = function (option) {
                for (var i = 0; i < this.source.values.length; i++) {
                    if (!option || this.source.values[i].value == option.value) {
                        this.source.values[i].selected = false;
                        if (!!option)
                            break;
                    }
                }
            };
            // Specify the dependencies for this directive    
            SelectBoxDirective.$inject = ['$scope', '$timeout', '$element', '$parse'];
            return SelectBoxDirective;
        }(Directives.BaseFilter));
        // Directive configuration
        function SelectBoxDirectiveSettings() {
            return {
                restrict: 'E',
                replace: true,
                controller: SelectBoxDirective,
                controllerAs: 'root',
                templateUrl: '/CxWebClient/pages/common/SelectBox',
                bindToController: true,
                scope: {
                    source: '=',
                    onChange: '='
                }
            };
        }
        Directives.SelectBoxDirectiveSettings = SelectBoxDirectiveSettings;
    })(Directives = Checkmarx.Directives || (Checkmarx.Directives = {}));
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=select-box.js.map