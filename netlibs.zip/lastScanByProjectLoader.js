﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('lastScanByProjectLoader', [
        'projectLastScanDataService',
        'lastScanByProjectDataService',
        '$q',
        'cacheService',
        'projectsCacheKeys',
        function (projectLastScanDataService, lastScanByProjectDataService, $q, cacheService, projectsCacheKeys) {
            /* loader for last scan data by project id.
             * NOTE: by default caches the data via cacheService.
             * return promise.
            */

            function shouldLoadFromServer(noCache, result) {

                return noCache == true || result == null || result == undefined;
            }

            function load(projectId, noCache) {

                var deferred = $q.defer();
                var cacheKey = projectsCacheKeys.projectStatusModel;
                var result = cacheService.get(cacheKey);

                if (shouldLoadFromServer(noCache, result)) {

                    lastScanByProjectDataService.getLastScanByProjectId(projectId).then(function (lastScanData) {

                        var scanId = lastScanData.data.id;

                        return projectLastScanDataService.getLastScan(scanId).then(function (scanData) {

                            result = scanData.data;
                            cacheService.put(cacheKey, result);

                            deferred.resolve(result);
                        });

                    }).catch(function (data, status, headers, config) {
                        deferred.reject(data.data);
                    });
                }
                else {
                    deferred.resolve(result);
                }

                return deferred.promise;
            }

            return {
                load: load
            };

        }]);

})();