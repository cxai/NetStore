﻿(function () {
    "use strict";

    checkmarx.Common.factory('Common.Timer', ['$interval', function ($interval) {
        /* generic service that wraps $interval and executes a given function */

        var TimerExecutor = function (interval) {

            this.timerInstance = null;

            if (Number(interval) == NaN) {
                throw "interval is not a number!";
            }

            function start(action) {

                this.timerInstance = $interval(function () {
                    action();
                }, interval);

                return this.timerInstance;
            }

            function stop() {

                if (this.timerInstance) {
                    $interval.cancel(this.timerInstance);
                }
            }

            return {
                start: start,
                stop: stop
            };

        };

        return TimerExecutor;

    }]);
})();