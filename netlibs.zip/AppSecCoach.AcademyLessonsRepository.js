﻿(function () {
	"use strict";

	checkmarx.CxAcademy.value('AppSecCoach.AcademyLessonsRepository', [594, 3522, 595, 145, 430, 75, 3685, 146, 431, 1317,
                                                                       1318, 3653, 2984, 2987, 1508, 1509, 3106, 3424, 3977]);
})();