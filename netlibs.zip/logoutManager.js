﻿var cxLogout = {};

(function () {

    cxLogout.logout = function (urlToOpen) {

        var data = {
            url: Core.REST.getRestBaseUrl() + Core.REST.restUrlPrefix + 'auth/logout',
            success: function (response) {

                window.location.href = urlToOpen;
            },
            error: function () { }
        };

        Core.web.ajax.post(data);
    };

})();