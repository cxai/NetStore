﻿function loadAutoCompleteValues(fieldId, element) {
    $.ajax({
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        type: 'POST',
        data: '{\'id\':' + fieldId + '}',
        url: 'CustomFieldsManagement.aspx/GetCustomFieldAutocompleteValues',
        success: function (response) {
            if (response.d) {
                fillAutoComplete(response.d, element);
            }
        },
        failure: function (response) {
        }
    });
}

function fillAutoComplete(customFieldValuesJSON, element) {
    try {
        var customFieldValues = $.parseJSON(customFieldValuesJSON);
        if (customFieldValues.length > 0) {
            $(element).autocomplete({ source: customFieldValues });
        }
    }
    catch (ex) {
    }
}

function initAutoComplete() {
    $(".customFieldValue").each(function (index, element) {
        $(element).one('focus', function () {
            var fieldId = $(element).attr("field-id");
            loadAutoCompleteValues(fieldId, element);
        });
    });
}