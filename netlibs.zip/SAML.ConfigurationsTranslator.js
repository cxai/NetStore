﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.SAML.factory('SAML.ConfigurationsTranslator', ['$translate', function ($translate) {

        function translate(key) {

            return $translate.instant(key);
        }

        function getTranslations() {

            var translations = {
                titles: {
                    enabledOrDisabled: translate('ENABLE_OR_DISABLE'),
                    authentication: translate('AUTHENTICATION'),
                    userManagement: translate('SAML_USER_MANAGMENT'),
                    idPCertificateFile: translate('IDP_CERTIFICATE'),
                    selectPreferedUserManagementMethod: translate('SELECT_PREFERED_USER_MANAGEMENT_METHOD'),
                    AutomaticDownloadLink: translate('DOWNLOAD_METADATA'),
                    ManualDownloadLink: translate('DOWNLOAD_METADATA'),
                    clientSignatureRequired: translate('SAML_SIGN'),
                    cxCertificateFile: translate('DOWNLOAD_CX_CERTIFICATION_FILE')
                },
                inputTitles: {
                    enabled: translate('ENABLE_SAML'),
                    disabled: translate('DISABLE_SAML'),
                    apiName: translate('ADD_SAML_NAME'),
                    identityProvider: translate('IDENTITY_PROVIDER'),
                    samlVersion: translate('SAML_VERSION'),
                    loginURL: translate('LOGIN_URL'),
                    logoutURL: translate('LOGOUT_URL'),
                    errorURL: translate('ERROR_URL'),
                    encryptSAMLAssertion: translate('ENCRYPT_SAML_ASSERTION'),
                    forceSSOLogin: translate('FORCE_SSO_LOGIN'),
                    idPCertificateFile: translate('IDP_CERTIFICATE_FILE'),
                    certificateFile: translate('CERTIFICATE_FILE'),
                    manualyUserManagement: translate('MANUALY_USER_MANAGMENT'),
                    automaticUserAuthorization: translate('AUTOMATIC_USER_AUTHORIZATION'),
                    manualyUserManagementDefaultTeam: translate('DEFAULT_TEAM'),
                    manualyUserManagementDefaultRole: translate('DEFAULT_ROLE'),
                    allowChanges: translate('MANUALY_USER_MANAGEMENT_ALLOW_CHANGES'),
                    allowNotExploitable: translate('MANUALY_USER_MANAGEMENT_ALLOW_NOT_EXPLOITABLE'),
                    allowDelete: translate('MANUALY_USER_MANAGEMENT_ALLOW_DELETE'),
                    cxCertificationFile: translate('CX_CERTIFICATION_FILE'),
                    externalCertificationFile: translate('EXTERNAL_CERTIFICATION_FILE'),
                    certificatePassword: translate('CERTIFICATE_PASSWORD'),
                    spCertificateFile: translate('SP_CERTIFICATE_FILE')
                },
                placeholder: {
                    apiName: translate('ADD_SAML_NAME_PLACEHOLDER'),
                    identityProvider: translate('IDENTITY_PROVIDER_PLACEHOLDER'),
                    samlVersion: translate('SAML_VERSION_PLACEHOLDER'),
                    loginURL: translate('LOGIN_URL_PLACEHOLDER'),
                    logoutURL: translate('LOGOUT_URL_PLACEHOLDER'),
                    idPCertificateFile: translate('IDP_CERTIFICATE_FILE_PLACEHOLDER'),
                    automaticUserManagement: translate('AUTOMATIC_USER_MANAGEMENT_DISCRIPTION'),
                    certificatePassword: translate('PASSWORD')
                },
                toolTips: {
                    enabledDisabled: translate('ENALBE_DISABLE_SAML_TOOLTIP'),
                    disabled: translate('CONNECT_IDP_WHEN_SAML_ENABLED'),
                    apiName: translate('ADD_SAML_NAME_TOOLTIP'),
                    identityProvider: translate('IDENTITY_PROVIDER_TOOLTIP'),
                    samlVersion: translate('SAML_VERSION_TOOLTIP'),
                    loginURL: translate('LOGIN_URL_TOOLTIP'),
                    logoutURL: translate('LOGOUT_URL_TOOLTIP'),
                    errorURL: translate('ERROR_URL_TOOLTIP'),
                    encryptSAMLAssertion: translate('ENCRYPT_SAML_ASSERTION_TOOLTIP'),
                    forceSSOLogin: translate('FORCE_SSO_LOGIN_TOOLTIP'),
                    idPCertificateFile: translate('IDP_CERTIFICATE_FILE_TOOLTIP'),
                    externalCertificateFile: translate('IDP_CERTIFICATE_FILE_TOOLTIP'),
                    manualyUserManagement: translate('MANUALY_USER_MANAGEMENT_TOOLTIP'),
                    manualyUserManagementDefaultTeam: translate('DEFAULT_TEAM_TOOLTIP'),
                    manualyUserManagementDefaultRole: translate('DEFAULT_ROLE_TOOLTIP'),
                    clientSignatureRequired: translate('SAML_SIGN_TOOLTIP'),
                    clientSignatureCertificateFormat: translate('SAML_SIGN_CERTIFICATE_FORMAT_TOOLTIP')
                },
                validations: {
                    enabled: translate('ENABLE_SAML'),
                    disabled: translate('DISABLE_SAML'),
                    apiName: translate('ERROR_VALUE_INVALID'),
                    apiNameInvalid: translate('IDP_NAME_INVALID'),
                    apiNameRequired: translate('ERROR_VALUE_REQUIRED'),
                    identityProvider: translate('ERROR_VALUE_INVALID'),
                    identityProviderRequired: translate('ERROR_VALUE_REQUIRED'),
                    samlVersion: translate('ERROR_VALUE_INVALID'),
                    loginURL: translate('ERROR_VALUE_INVALID'),
                    loginURLRequired: translate('ERROR_VALUE_REQUIRED'),
                    logoutURL: translate('ERROR_VALUE_INVALID'),
                    errorURL: translate('ERROR_VALUE_INVALID'),
                    encryptSAMLAssertion: translate('ERROR_VALUE_INVALID'),
                    forceSSOLogin: translate('ERROR_VALUE_INVALID'),
                    idPCertificateFile: translate('ERROR_VALUE_INVALID'),
                    idPCertificateFileRequired: translate('ERROR_VALUE_REQUIRED'),
                    defaultTeamRequired: translate('ERROR_VALUE_REQUIRED'),
                    certificatePasswordRequired: translate('ERROR_VALUE_REQUIRED'),
                    certificatePassword: translate('ERROR_VALUE_INVALID')
                }
            };

            return translations;
        }

        return {
            getTranslations: getTranslations
        };

    }]);

})();