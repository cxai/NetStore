var Checkmarx;
(function (Checkmarx) {
    checkmarx = angular.module("CxPortalApp", [
        'ui.bootstrap',
        'perfect_scrollbar',
        'ui.router',
        'ngSanitize',
        'ngFileSaver',
        'pascalprecht.translate',
        'toastr',
        'csrf-cross-domain',
        'highcharts-ng',
        'ngCookies',
        'ngResource',
        'Common',
        'CxPortal',
        'ProjectState',
        'SAML',
        'ApplicationSettings',
        'CxAcademy'
    ]);
    checkmarx.run(['$state', '$rootScope', '$window', '$http', 'httpStatusCodes', 'siteGlobalVariablesProvider', 'authorizationNeeded',
        function ($state, $rootScope, $window, $http, httpStatusCodes, globalVariables, authorizationNeeded) {
            $rootScope.$on('$stateChangeError', function (event, toState, toParams, fromState, fromParams, error) {
                if (error.status === httpStatusCodes.unauthorized) {
                    window.location.href = "Login.aspx";
                }
                else if (error.status === httpStatusCodes.forbidden) {
                    window.location.href = "Error.aspx?errorcode=403";
                }
                console.log("change error: " + error);
            });
            $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams, error) {
                if (toState.metadata != undefined && fromState.metadata != undefined && toState.metadata.spaPagesGroups != fromState.metadata.spaPagesGroups) {
                    $rootScope.CxReferrer = fromState.name;
                }
            });
            $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams, options) {
                if (toState.metadata.auth === authorizationNeeded.admin && !globalVariables.basicVariables().isAdmin) {
                    window.location.href = "Error.aspx?errorcode=403";
                }
            });
            $rootScope.$on('$stateNotFound', function (event, unfoundState, fromState, fromParams) {
                console.log("not found");
            });
        }]);
    angular.element(document).ready(function () {
        $.when(translationService.initCxTranslations()).then(function () {
            angular.bootstrap(document, ['CxPortalApp']);
        });
    });
})(Checkmarx || (Checkmarx = {}));
//# sourceMappingURL=app.js.map