﻿(function () {
    "use strict";

    checkmarx.Common.factory('Common.MegabytesToBytesConvertor', [function () {

        function convert(megabytes) {

            var oneMegaInBytes = 1000000;

            return (megabytes * oneMegaInBytes);
        }

        return {
            convert: convert
        };

    }]);

})();