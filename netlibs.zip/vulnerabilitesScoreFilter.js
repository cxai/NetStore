﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.filter('vulnerabilitesScoreFilter', ['oasVulnerabilityScore',
        function (oasVulnerabilityScore) {

        return function (vulnerabilityScore) {

            var score = null;

            if (vulnerabilityScore) {

                return vulnerabilityScore.toLowerCase();
            }

            return oasVulnerabilityScore.high;
        };
    }]);
})();