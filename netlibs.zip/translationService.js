﻿/* translation service for get and set tranalstion in the browser local storage */

var _translationObject = {
    versionNumber: null,
    cultureName: null,
    translations: null
};

var translationService = function () {
    "use strict";

    var keyCheckmarxTranslations = "CheckmarxTranslations";
    var keyCheckmarxVersionNumber = "CheckmarxVersionNumber";
    var keyCheckmarxCultureName = "CheckmarxCultureName";

    function loadTranslationsFromServer() {

        return $.ajax({
            type: "GET",
            url: "api/translation/GetTranslationData",
            success: function (response) {

                if (response !== null) {
                    return response;
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
    }

    function loadCheckmarxTranslationFromLocalStorage() {

        if (localStorage.getItem(keyCheckmarxTranslations)) {
            _translationObject.translations = JSON.parse(localStorage.getItem(keyCheckmarxTranslations));
        }
        else {
            return null;
        }

        if (localStorage.getItem(keyCheckmarxVersionNumber)) {
            _translationObject.versionNumber = JSON.parse(localStorage.getItem(keyCheckmarxVersionNumber));
        }

        if (localStorage.getItem(keyCheckmarxCultureName)) {
            _translationObject.cultureName = JSON.parse(localStorage.getItem(keyCheckmarxCultureName));
        }
    }

    function setCheckmarxTranslationIntoLocalStorage(tranlsationObject, versionNumber, cultureName) {

        localStorage.setItem(keyCheckmarxTranslations, JSON.stringify(tranlsationObject));
        localStorage.setItem(keyCheckmarxVersionNumber, JSON.stringify(versionNumber));
        localStorage.setItem(keyCheckmarxCultureName, JSON.stringify(cultureName));
    }

    function reloadTranslationsFromServer() {

        _translationObject.versionNumber = _cxGlobalVariables.buildVersionNumber;
        _translationObject.cultureName = _cxGlobalVariables.currentCulture;

        return loadTranslationsFromServer(_translationObject.versionNumber, _translationObject.cultureName).then(function (translations) {

            _translationObject.translations = translations;
            setCheckmarxTranslationIntoLocalStorage(translations, _translationObject.versionNumber, _translationObject.cultureName);
        });
    }

    function isVersionOrLanguageChanged(response) {

        return _translationObject.versionNumber != _cxGlobalVariables.buildVersionNumber ||
                _translationObject.cultureName != _cxGlobalVariables.currentCulture;
    }

    function initCxTranslations() {

        var deferred = new $.Deferred();

        loadCheckmarxTranslationFromLocalStorage();
        var versionNumber = null;
        var cultureName = null;

        if (_translationObject == null) {

            reloadTranslationsFromServer().then(function (response) {
                deferred.resolve();
            });
        }
        else {

            if (isVersionOrLanguageChanged()) {

                reloadTranslationsFromServer().then(function (response) {
                    deferred.resolve();
                });
            }
            else {
                deferred.resolve();
            }
        }

        return deferred.promise();
    }

    return {
        initCxTranslations: initCxTranslations
    };
}();