﻿/*
 * bread crumbs directive flow:
 * 
 *  1. parse the current state name and return array wraped in promise object
 *      - split state name into parts ('project.osa' -> ['project', 'osa'])
 *      - map: for every part of the name, construct a partial path ['project', 'osa'] -> ['project', 'project.osa']
 *      - if title is a string, use the string, if not (function or array) invoke using $injector
 *      - turn all titles into a promise and return it
 *  2. handle the promise
 *      - concat all path path with a ' / '
 *  3. print the path
 *  4. timeout in case the $stateChangeSuccess is not called (fix bug: 78431)
 * 
 */
(function () {
    "use strict";

    checkmarx.Common.directive('breadCrumbs', function () {

        return {
            template: '{{name}}',
            controller: ['$state', '$scope', '$injector', '$timeout',
                function ($state, $scope, $injector, $timeout) {

                    $scope.stateChangeSuccessCalled = false;

                    function parseStateNameIntoPromiseArray(state) {

                        return state.name.split('.').map(function (part, idx, arr) {
       
                            var name = arr.slice(0, idx + 1).join('.');
                            var state = $state.get(name);

                            var name = typeof state.metadata.name === typeof '' ?
                                    state.metadata.name : $injector.invoke(state.metadata.name);

                            var promise = null;

                            if (!(name instanceof Promise)) {
                                promise = Promise.resolve(name);
                            }

                            return promise;
                        });
                    }

                    function handlePromise(titleParts) {

                        Promise.all(titleParts).then(function (parts) {

                            return parts.join(' / ');
                        })
                        .then(function (breadcrumbsPath) {

                            if (breadcrumbsPath) {

                                $scope.$apply(function () {
                                    $scope.name = breadcrumbsPath;
                                });
                            }
                            else {
                                // if the promises finished in the middle of a digest (can happen if all promises are initially resolved) just assign the title
                                if ($scope.$$phase) {
                                    $scope.name = breadcrumbsPath;
                                }
                                else {
                                    // if promises are done after the digest (will happen with with async promises) apply needs to be called
                                    $scope.$apply(function () {
                                        $scope.name = breadcrumbsPath;
                                    });
                                }
                            }
                        });
                    }

                    $scope.generateBreadcrumbs = function(state) {

                        if (!state.name) {
                            return;
                        }

                        var titleParts = parseStateNameIntoPromiseArray(state);

                        handlePromise(titleParts);
                    }

                    $scope.$on('$stateChangeSuccess', function (event, toState) {
                        
                        $scope.stateChangeSuccessCalled = true;

                        return $scope.generateBreadcrumbs(toState);
                    });

                    $timeout(function () {

                        if ($scope.stateChangeSuccessCalled == false) {

                            console.info('$stateChangeSuccess is not called');

                            $scope.generateBreadcrumbs($state.current);
                        }

                    }, 1000);
                }]
        }
    });
})();