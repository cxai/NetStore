﻿var originalFieldValues = new Object();
var fieldValueArray = [];
var parsley = null;

window.ParsleyConfig = {
    validators: {
        unique: {
            fn: function (value, index) {
                for (var i = 0; i < fieldValueArray.length; i++) {
                    if (i !== index) {
                        if (fieldValueArray[i].toLowerCase() === value.toLowerCase()) {
                            return false;
                        }
                    }
                }
                return true;
            },
            priority: 32
        }
    }
};

$(function () {
    getCustomFields();
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": true,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
});

function getCustomFields() {
    $.ajax({
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        type: 'POST',
        url: 'CustomFieldsManagement.aspx/GetCustomFields',
        success: function (response) {
            if (response.d !== null && response.d != "error") {
                originalFieldValues = new Object();
                $("#accordion").empty();
                fillCustomFields(response.d);
            }
            else {
                toastr.error($("#hdnGeneralError").val());
            }
        },
        failure: function (response) {
            toastr.error($("#hdnGeneralError").val());
        }
    });
};

function deleteCustomField(id, element) {
    $.ajax({
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        type: 'POST',
        data: '{\'id\':' + id + '}',
        url: 'CustomFieldsManagement.aspx/DeleteCustomField',
        success: function (response) {
            if (response.d !== null && response.d != false) {

                removeCustomField(element);                
            }
            else {
                toastr.error($("#hdnCustomFieldDeleteError").val());
            }
        },
        failure: function (response) {
            toastr.error($("#hdnCustomFieldDeleteError").val());
        }
    });


}

function removeCustomField(element) {
    var accordionHeader = $(element).parents(".customFieldHeader");
    var accordionBody = $(accordionHeader).next();

    $(accordionBody).remove();
    $(accordionHeader).remove();

    swal({
        title: $("#hdnDeleted").val(),
        text:$("#hdnSuccessfulServerDeletion").val(),
        icon:"success"
    }).then(function () {
        $(document).trigger('sweetalert-modal-closed');
    })


    if ($(".customField").length == 0) {
        addCustomField();
    }
}

function setFieldValueArray() {
    fieldValueArray = [];
    $(".customFieldInput").each(function (index, element) {
        fieldValueArray[index] = $(element).val();
        $(element).attr("data-parsley-unique", index);
    });
}

function fillCustomFields(customFieldsJSON) {
    try {
        var customFields = $.parseJSON(customFieldsJSON);
        if (customFields.length > 0) {
            $.get("CustomFieldEditTemplate.html", function (data) {
                for (var i = 0; i < customFields.length; i++) {
                    var findServerId = '{ServerId}';
                    var serverIdRegEx = new RegExp(findServerId, 'g');
                    var findFieldName = '{FieldName}';
                    var fieldNameRegEx = new RegExp(findFieldName, 'g');

                    var field = customFields[i];
                    var html = data.replace(fieldNameRegEx, field.Name)
                     .replace("{PlaceholderValue}", $("#hdnNameLocalization").val())
                     .replace("{Delete}", $("#hdnDelete").val())
                     .replace("{DeleteToolTip}", $("#hdnDelete").val())
                     .replace("{FieldValue}", field.Name)
                     .replace(serverIdRegEx, field.Id)
                     .replace("{UniqueErrorMessage}", $("#hdnFieldMustBeUniqueLocalization").val())
                    originalFieldValues[field.Id] = field.Name;
                    $("#accordion").append(html);
                }
                $("#accordion").accordion('destroy').accordion({ collapsible: true, active: false });
                $(".customFieldDeleteButton").unbind("click").click(deleteClick);
                $(".customFieldInput").unbind("blur").blur(loseFocus);
            });
        }
        else {
            addCustomField();
        }
    }
    catch (ex) {
        toastr.error(customFieldsJSON);
    }
}

function loseFocus(event) {
    var element = event.target;

    var text = $(element).val();
    if (text) {
        var header = $(element).closest(".customField").prev();
        $(header).children(".customFieldTitle").text(text).attr('title', text);
    }    
}

function deleteClick(event) {
    var deleteButtonElement = event.target;
    event.stopImmediatePropagation();
    event.preventDefault();
    var serverId = $(deleteButtonElement).attr("data-serverid");


    swal({
        title: $("#hdnAreYouSure").val(),
        text: $("#hdnCustomFieldConfirmDeletion").val(),
        icon: "warning",
        buttons: {
            cancel: {
                text:$("#hdnCustomFieldCancelDeletionButtonText").val(),
                closeModal: true,
                visible:true
            },
            confirm: {
                text: $("#hdnCustomFieldDeleteButtonText").val(),
                closeModal: false,
                visible: true
            }
        },
        dangerMode: true
    }).then(
    function (isConfirm) {
    if (isConfirm) {
        if (serverId == 0) {
            removeCustomField(deleteButtonElement);
        }
        else {
            deleteCustomField(serverId, deleteButtonElement);
            $(document).trigger('sweetalert-modal-closed');
        }
    }
});
}

function canAddCustomField() {
    var maxFields = parseInt($("#hdnMaxCustomFields").val());
    if (maxFields != NaN && $(".customFieldInput").length >= maxFields) {
        toastr.error($("#hdnMaxCustomFieldError").val());
        return false;
    }
    return true;
}

function addCustomField() {
    var isValid = parsley.validate();
    if (canAddCustomField() && isValid) {
        $.get("CustomFieldEditTemplate.html", function (data) {
            var findServerId = '{ServerId}';
            var serverIdRegEx = new RegExp(findServerId, 'g');
            var findFieldName = '{FieldName}';
            var fieldNameRegEx = new RegExp(findFieldName, 'g');

            data = data.replace(fieldNameRegEx, $("#hdnNewFieldNameLocalization").val())
                .replace("{PlaceholderValue}", $("#hdnNameLocalization").val())
                .replace("{Delete}", $("#hdnDelete").val())
                .replace("{DeleteToolTip}", $("#hdnDelete").val())
                .replace("{FieldValue}", "")
                .replace(serverIdRegEx, "0")
                .replace("{UniqueErrorMessage}", $("#hdnFieldMustBeUniqueLocalization").val());
            var newTabIndex = $(".customFieldInput").length;
            var $element = $(data);
            $("#accordion").append($element).accordion('destroy').accordion({ active: newTabIndex, collapsible: true });
            $element.find(".customFieldDeleteButton").unbind("click").click(deleteClick);
            $element.find(".customFieldInput").unbind("blur").blur(loseFocus);
        });
    }
}

function save() {
    var isValid = parsley.validate();
    if (isValid) {
        var data = [];
        $(".customFieldInput").each(function (index, element) {
            var fieldName = $(element).val();
            var fieldId = $(element).attr("data-serverid");
            if (fieldName !== originalFieldValues[fieldId]) {
                var field = new Object();
                field.Name = fieldName;
                field.Id = fieldId;
                data.push(field);
            }
        });
        if (data.length > 0) {
            data = JSON.stringify({ customFieldsJSON: data });
            $.ajax({
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                type: 'POST',
                data: data,
                url: 'CustomFieldsManagement.aspx/SaveCustomFields',
                success: function (response) {
                    if (response.d !== null && response.d != false) {
                        toastr.success($("#hdnCustomFieldSaved").val());
                        getCustomFields();
                    }
                    else {
                        toastr.error($("#hdnCustomFieldSaveError").val());
                    }
                },
                failure: function (response) {
                    toastr.error($("#hdnCustomFieldSaveError").val());
                }
            });
        }
    }
}

function unHighlightValidSections(control) {
    var elementsWithoutErrors = $(".customField > input").filter(function () { return !($(this).children().is('.parsley-error')); });
    elementsWithoutErrors.each(function (index, element) {
        var header = $(element).closest(".customField").prev();
        if (header.hasClass("error-border")) {
            header.removeClass("error-border");
        }
    });
}

function highlightInvalidSections() {
    $(".parsley-error").each(function (index, element) {
        var header = $(element).closest(".customField").prev();
        if (!header.hasClass("error-border")) {
            header.addClass("error-border");
        }
    });
}


$(document).ready(function () {
    $(".btnAddCustomField").click(addCustomField);
    $(".btnSave").click(save);
    $("#accordion").accordion({ collapsible: true, active: false });
    parsley = $('form').parsley();
    $.listen('parsley:field:success', function (control) {
        unHighlightValidSections(control);
    });
    $.listen("parsley:form:validate", function (evt, formInstance) {
        setFieldValueArray();
    });
    $.listen("parsley:form:validated", function (evt, formInstance) {
        highlightInvalidSections();
    });
});