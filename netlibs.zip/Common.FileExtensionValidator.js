﻿(function () {
    "use strict";

    checkmarx.Common.factory('Common.FileExtensionValidator', [function () {

        function validate(fileName, validFileExtensions) {

            if (fileName.length > 0) {

                for (var i = 0; i < validFileExtensions.length; i++) {

                    var validFileExtension = validFileExtensions[i];

                    if (fileName.substr(fileName.length - validFileExtension.length, validFileExtension.length).toLowerCase() == validFileExtension.toLowerCase()) {
                        return true;
                    }
                }
            }

            return false;
        }

        return {
            validate: validate
        };

    }]);

})();