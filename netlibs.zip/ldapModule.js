﻿/// <reference path="../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.LDAP = angular.module('LDAP', []);

})();
