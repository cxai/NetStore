﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    'use strict';

    checkmarx.ProjectState.factory('osaRequestErrorFormatService', ['$stateParams', 'osaNotificationService', '$translate', 'restAPIErrorMessageCodes',
        function ($stateParams, osaNotificationService, $translate, restAPIErrorMessageCodes) {

            function format(data) {

                if (data && data.errorCode == restAPIErrorMessageCodes.osaHasNotConfigured) {
                    var message = data.message + ' ' + formatSpecifyOsaLibrariesMessage();
                    osaNotificationService.error(message);
                }
                else {
                    osaNotificationService.error((data && data.message) || "");
                }
            }

            function formatSpecifyOsaLibrariesMessage() {
                var link = ' <a class="blue-link" href="/CxWebClient/Projects.aspx?projectId=' + $stateParams.id + '&osaTab=true&ProjectState=true">' + $translate.instant('OSA_CONFIGURE_MESSAGE') + '</a>';
                return $translate.instant('SPECIFY_OSA_LIBRARIES').replace('{link}', link);
            }

            return {
                format: format,
                formatSpecifyOsaLibrariesMessage: formatSpecifyOsaLibrariesMessage
            };

        }]);
})();