﻿/// <reference path="../../app.js" />

(function () {
    "use strict";

    checkmarx.Queries.factory('Queries.QueryDescriptionProcessorHandler', [
        '$rootScope',
        'Queries.QueryDescriptionProcessor',
        'httpStatusCodes',
        '$translate',
        'Queries.TabObjectsBuilderService',
        function ($rootScope, queryDescriptionProcessor, httpStatusCodes, $translate, tabObjectsBuilderService) {

            var _queryId;

            function loadQueryDescription() {

                queryDescriptionProcessor.loadQueryDescription(_queryId).then(function (result) {

                    $rootScope.currentQueryId = _queryId;
                    
                    if (result.isSuccess == true) {
                        tabObjectsBuilderService.calculate(result.descriptions).then(function (tabDescriptions) {
                            $rootScope.$broadcast('query-descriptions-loaded', tabDescriptions);
                            $rootScope.$broadcast('query-description-HTML-loaded', result.selectedQueryDescription);
                        });
                    }
                    else {

                        if (result.error && result.error.status == httpStatusCodes.serverError) {
                            $rootScope.$broadcast('queryDescriptionError', $translate.instant('QUERY_DESCRIPTION_ERROR'));
                        }
                        else {
                            $rootScope.$broadcast('query-description-HTML-loaded', "");
                            $rootScope.$broadcast('query-descriptions-loaded', "");
                        }
                    }
                });
            }

            function runProcess(queryId) {
                
                _queryId = queryId;
                $rootScope.$broadcast('queryDescriptionReset');
                loadQueryDescription();
            }

            return {
                runProcess: runProcess
            };
        }]);

})();