﻿/// <reference path="../../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('scanRequestRefreshPageCalculator', ['$state', '$stateParams', 'scanRequestGeneralStages', 'lastScanByProjectLoader',
        function ($state, $stateParams, scanRequestGeneralStages, lastScanByProjectLoader) {

        var alreadyReloded = false;

        function calcualte(scanId, scanStatusId) {

            if (scanStatusId == scanRequestGeneralStages.success && !alreadyReloded) {

                lastScanByProjectLoader.load($stateParams.id).then(function () {
                    $state.reload();
                    alreadyReloded = true;
                });
            }
            else if (scanStatusId == scanRequestGeneralStages.progress) {
                alreadyReloded = false;
            }
        }

        return {
            calcualte: calcualte
        };
    }]);

})();