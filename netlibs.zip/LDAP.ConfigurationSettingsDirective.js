﻿
(function () {
    "use strict";

    checkmarx.LDAP.component('ldapSettings', {
        templateUrl: "app/ldap/views/ldapSettingsView.html",
        bindings: {},
        controller: ['$scope', '$translate', 'LDAP.ConfigurationDataService', 'CxPortal.NotificationService',
            function ($scope, $translate, ldapConfigurationDataService, notificationService) {

                var ldapSettingsValues = {
                    ldapRoleAuth: 'ldapRoleAuth',
                    manualRoleAuth: 'manualRoleAuth'
                };
                $scope.syncLdapChoice;
                var loadedValue = ldapSettingsValues.manualRoleAuth;

                function buildData(data) {
                    var result;
                    switch (data) {
                        case ldapSettingsValues.ldapRoleAuth: result = "True";
                            break;
                        case ldapSettingsValues.manualRoleAuth:
                        default: result = "False";
                    }
                    return { 'ldapSyncUpdatesUserRole': result }
                };

                function getDataFromResult(data) {
                    var result;
                    switch (data.ldapSyncUpdatesUserRole) {
                        case "True": return ldapSettingsValues.ldapRoleAuth;
                        case "False":
                        default: return ldapSettingsValues.manualRoleAuth;
                    }
                };

                $scope.save = function () {
                    ldapConfigurationDataService.put(buildData($scope.syncLdapChoice)).then(function () {
                        notificationService.success($translate.instant("LDAP_SAVED_SUCCESSFULLY"));
                        loadedValue = $scope.syncLdapChoice;
                    }).catch(function (error) {
                        notificationService.error(error.data.messageDetails);
                    });
                };

                $scope.cancel = function () {
                    $scope.syncLdapChoice = loadedValue;
                };

                var loadSyncSettings = function () {
                    ldapConfigurationDataService.get().then(function (result) {
                        loadedValue = getDataFromResult(result.data);
                        $scope.syncLdapChoice = loadedValue;
                    }).catch(function (error) {
                        notificationService.error(error.data.messageDetails);
                        $scope.syncLdapChoice = loadedValue;
                    });
                };

                loadSyncSettings();
            }]
    });
})();