﻿(function () {
    "use strict";

    checkmarx.Common.factory('Common.EncryptionTypes', ['$translate', function ($translate) {

        var encryptionTypes = [
            $translate.instant("None"),
            $translate.instant("TLS"),
            $translate.instant("SSL")
        ];

        return encryptionTypes;
    }]);

})();