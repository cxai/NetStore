﻿"use strict";

(function () {

    //#region api

    function shouldDisplaySAMLButton() {

        Core.web.ajax.get(buildAjaxParams());
    };

    //#endregion

    //#region private methods

    function success(response) {

        if (response !== null) {

            if (response.isEnabled) {
                redirectIfSAMLUserLogedIn(response.logoutUrl);
                displaySAMLButton();
            }
        }
    }

    function redirectIfSAMLUserLogedIn(logoutUrl) {

        if (!_cxGlobalVariables || Core.isStringEmpty(_cxGlobalVariables.isSAMLUser)) {
            return;
        }

        if (_cxGlobalVariables.isSAMLUser && !Core.isStringEmpty(logoutUrl) && isLogoutExists()) {
            window.location.href = logoutUrl;
        }
    }

    function isLogoutExists() {

        return Core.web.QueryString.isParameterExists('logout', window.location.href);
    }

    function displaySAMLButton() {

        var deferred = $.Deferred();

        var checkSelector = setInterval(function () {

            if ($('#btnSAMLLogin').length) {
                deferred.resolve();
            }

        }, 200);

        deferred.done(function () {
            $('#divLoginInnerContainer').width("550px");
            $('#spnLoginAdditionalButtonsDivider').show();
            $('#btnSAMLLogin').show();
        });
    }

    function buildAjaxParams() {

        return {
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            url: Core.REST.getRestBaseUrl() + Core.REST.restUrlPrefix + 'anonymoussamlidentityprovider',
            success: success,
            error: function () { }
        };
    }

    //#endregion

    //#region bootstrap

    shouldDisplaySAMLButton();

    //#endregion

})();