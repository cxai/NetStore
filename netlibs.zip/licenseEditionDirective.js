﻿
(function () {
    "use strict";

    checkmarx.CxPortal.directive('licenseEditionDirective', ['siteGlobalVariablesProvider', 'licenseService',
        function (globalVariables, licenseService) {

            return {
                template: '<span class="license-edition" ng-show="licenseEditionView">'
                            + '<span class="inner-license-edition">[{{ licenseEdition | licenseEditionFilter | translate }}]</span>'
                        + '</span>',
                controller: ['$scope', '$element', function ($scope, $element) {
                    $scope.licenseEditionView = false;

                    function loadLicenseDetailsSuccess(response) {

                        if (response) {
                            $scope.licenseEdition = response.edition;
                            $scope.licenseEditionView = true;
                        }
                    }                   

                    function init() {
                        licenseService.getLicenseDetails().then(loadLicenseDetailsSuccess);
                    }

                    if (globalVariables.basicVariables().isAdmin) {
                        init();
                    }
                }]
            };

        }]);

})();