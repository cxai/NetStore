﻿/// <reference path="app.js" />

(function () {
    "use strict";

    checkmarx.Queries.directive('queryDescriptionTabs',
        [function () {

            var _selectedTabIndex = 0;

            return {
                templateUrl: "app/queries/views/queryDescriptionTabs.html",
                restrict: 'E',
                scope: {
                    descriptions: '='
                },
                link: function (scope, element, attrs) {

                    scope.tabClick = function (index, url, queryTypeId) {

                        if (_selectedTabIndex == index) {
                            return;
                        }
                        
                        setSelectedTabIndex(index);
                        scope.$emit('query-description-tab-clicked', buildDescriptionData(url, queryTypeId));
                    };
                    
                    scope.$on('query-description-changed', function () {
                        resetSelectedTabIndex();
                    });
    
                    function resetSelectedTabIndex() {
                        setSelectedTabIndex(0);
                    }

                    function setSelectedTabIndex(index) {
                        _selectedTabIndex = index;
                    }

                    function buildDescriptionData(url, queryTypeId) {
                        
                        return {
                            url: url,
                            queryTypeId: queryTypeId
                        };
                    }
                }
            };
        }]);
})();