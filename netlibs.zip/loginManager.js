﻿var cxLogin = {};

(function () {

    var isSSO = false;

    cxLogin.doPostback = function () {
        if (isSSO)
            __doPostBack('btnSSOLogin', 'OnClick');
        else
            __doPostBack('btnLogin', 'OnClick');
    };

    cxLogin.isXHRResultValid = function (xhr) {

        return xhr && xhr.responseText && xhr.responseText != "";
    };

    cxLogin.getRESTLoginURL = function () {
        return Core.REST.getRestBaseUrl() + Core.REST.restUrlPrefix;
    };

    cxLogin.getRESTURL = function () {

        if (isSSO) {
            return cxLogin.getRESTLoginURL() + "auth/ssologin";
        }

        return cxLogin.getRESTLoginURL() + "auth/login";
    };

    cxLogin.loginFailure = function (xhr, ajaxOptions, thrownError) {

        if (cxLogin.isXHRResultValid(xhr)) {

            var json = JSON.parse(xhr.responseText);
            $('#trerror').text(json.messageDetails);
        }
    };

    cxLogin.loginSuccess = function (btnLoginId) {

        cxLogin.doPostback();
    }

    cxLogin.getUserNameAndPassword = function () {
    
        var userName = $telerik.$("#txtUserName").val();
        var password = $telerik.$("#txtPassword").val();
        var ddl = $find('cmbDomain');

        if (!isSSO && ddl.get_selectedItem().get_value() != 'APPLICATION_USER') {

            userName = ddl.get_selectedItem().get_value() + '\\' + userName;
        }

        return {
            username: userName,
            password: password
        };
    };

    cxLogin.login = function (isSSOLogin) {

        isSSO = isSSOLogin;

        var credencials = cxLogin.getUserNameAndPassword();

        var ajaxParams = {
            url: cxLogin.getRESTURL(),
            data: cxLogin.getUserNameAndPassword(),
            success: function (data) {
                cxLogin.loginSuccess();
            },
            error: function (xhr, ajaxOptions, thrownError) {
                hideLoading();
                cxLogin.loginFailure(xhr, ajaxOptions, thrownError);
            },
            xhrFields: {
                withCredentials: true
            }
        };

        Core.web.ajax.post(ajaxParams);
    };

})();