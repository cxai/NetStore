﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.provider('projectDetailsDataService', [function () {

        var _projectDetails = null;

        this.$get = ['ajaxService', 'apiBaseURLService', function (ajaxService, apiBaseURLService) {

            function getProject(projectId) {

                var url = apiBaseURLService.getAPIBaseURL() + '/projectsInternal/' + projectId;

                return ajaxService.get(url, {
                    projectId: projectId
                });
            }

            return {
                getProject: getProject
            };

        }];

        this.setProjectDetails = function (data) {
            _projectDetails = data;
        }

    }]);

})();