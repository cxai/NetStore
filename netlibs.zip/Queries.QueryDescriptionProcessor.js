﻿/// <reference path="../../app.js" />

(function () {
    "use strict";

    checkmarx.Queries.factory('Queries.QueryDescriptionProcessor', ['$q', 'Queries.QueryDescriptionsDataService', 'Queries.QueryDescriptionDataService',
        function ($q, queryDescriptionsDataService, queryDescriptionDataService) {

            function result() {

                return {
                    descriptions: null,
                    selectedQueryDescription: null,
                    isSuccess: true,
                    error: null
                };
            }

            function isSuccess(resultModel) {

                return (resultModel.error == null && resultModel.descriptions != null);
            }

            function loadSingleQueryDescription(queryId, data, resultModel) {

                return queryDescriptionDataService.getQuery(queryId, data).then(function (data) {

                    resultModel.selectedQueryDescription = data;
                    resultModel.isSuccess = isSuccess(resultModel)

                    return resultModel;
                })
                .catch(function (error) {

                    resultModel.isSuccess = false;
                    resultModel.error = error;

                    return resultModel;
                });
            }

            function loadQueryDescription(queryId) {

                var deferred = $q.defer();
                var resultModel = new result();

                // 1. load all query descriptions
                queryDescriptionsDataService.getQueryDescriptions(queryId).then(function (data) {

                    resultModel.descriptions = data.data.descriptions;

                    // 2. load single query description by priority
                    loadSingleQueryDescription(queryId, data.data, resultModel).then(function (result) {

                        deferred.resolve(result);

                    });
                });

                return deferred.promise;
            }

            return {
                loadQueryDescription: loadQueryDescription
            };
        }]);

})();