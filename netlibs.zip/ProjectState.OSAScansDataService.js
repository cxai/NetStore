﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('ProjectState.OSAScansDataService',
        ['$q',
         'ajaxService',
         'apiBaseURLService',
         'ProjectState.OSAScanProcessStatus',
        function ($q, ajaxService, apiBaseURLService, OSAScanProcessStatus) {

            function get(projectId, itemsPerPage) {

                var deferred = $q.defer();

                itemsPerPage = itemsPerPage == undefined ? 5 : itemsPerPage;
                var url = apiBaseURLService.getAPIBaseURL() + '/osa/scans?projectid=' + projectId + '&itemsperpage=' + itemsPerPage;

                ajaxService.get(url).then(function (response) {

                    var scans = response.data;

                    if (scans.length > 0) {

                        deferred.resolve(scans);
                    }
                    else {
                        deferred.reject("Open Source Analysis for this project has not yet been performed, select Analyze");
                    }
                })
                .catch(function (data, status, headers, config) {
                    deferred.reject((data && data.data.messageDetails) || "");
                });

                return deferred.promise;
            }

            return {
                get: get
            };

        }]);
})();