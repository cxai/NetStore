﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxPortal.factory('apiBaseURLService', ['siteGlobalVariablesProvider', 'appSettings',
        function (siteGlobalVariablesProvider, appSettings) {
            /* service for loading the REST API base URL. */

            var RESTBaseURL = window.location.origin ? window.location.origin : (window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : ''));

            function getAPIOriginURL() {

                return RESTBaseURL;
            }

            function getAPIVirtualDirectory() {

                return RESTBaseURL + "/" + appSettings.restAPIVirtualDirectoryName;
            }

            function getAPIBaseURL() {

                return RESTBaseURL + "/" + appSettings.restAPIVirtualDirectoryName;
            }

            return {
                getAPIOriginURL: getAPIOriginURL,
                getAPIVirtualDirectory: getAPIVirtualDirectory,
                getAPIBaseURL: getAPIBaseURL
            };
        }]);

})();