﻿/// <reference path="../../libs/angular/angular.js" />
/// <reference path="../services/dataServices/Queries.CustomDescriptionDataService.js" />

(function () {
    "use strict";

    checkmarx.Queries.directive('importQueryDescriptionPopupForm',
        ['$rootScope', 'siteGlobalVariablesProvider', function () {

            return {
                templateUrl: "app/queries/views/importQueryDescriptionPopupForm.html",
                transclude: true,
                controller: ['$rootScope',
                    '$scope',
                    'Queries.CustomDescriptionDataService',
                    'Queries.ImportCustomDescriptionValidatorService',
                    'CxPortal.NotificationService',
                    'Queries.QueryDescriptionProcessorHandler',
                    'customDescriptionCommandMode',
                    '$translate',
                    'siteGlobalVariablesProvider',
                    function ($rootScope,
                        $scope,
                        customDescriptionDataService,
                        importCustomDescriptionValidator,
                        notificationService,
                        queryDescriptionProcessorHandler,
                        commandModeValue,
                        $translate,
                        globalVariables) {

                        $scope.mainTitle;

                        $scope.dialogSetup = {
                            mainTitle: null,
                            showUpdateNotification: false,
                            command: null
                        };

                        resetDialogMessages();
                        resetFileUpload();

                        //#region scope extensions

                        $scope.$on('dialog-close', function (e) {
                            resetDialogMessages();
                            resetFileUpload();
                        });

                        $scope.$watchCollection('files', function () {

                            resetDialogMessages();

                            if ($scope.files && $scope.files.length > 0) {
                                validateForm();
                            }
                        });

                        $rootScope.$watch('customDescriptionCommandMode', function (customDescriptionCommandMode) {

                            buildDialogSetup(customDescriptionCommandMode);

                        });

                        $scope.importCustomQueryDescription = function () {

                            resetDialogMessages();

                            if (!validateForm()) {
                                return;
                            }

                            runCommand();
                        };

                        //#endregion

                        //#region private functions

                        function runCommand() {

                            if ($scope.dialogSetup.command == commandModeValue.import) {
                                postNewCustomDescription();
                            }
                            else if ($scope.dialogSetup.command == commandModeValue.update) {
                                updateCustomDescription();
                            }
                        }

                        function validateForm() {

                            var validatorResult = importCustomDescriptionValidator.validate($scope.files[0]);

                            if (!validatorResult.isValid) {

                                $scope.uploadFileErrorMessage = validatorResult.uploadFileErrorMessage;
                                return false;
                            }

                            return true;
                        }

                        function postNewCustomDescription() {

                            var dataToSend = buildDataToPost();

                            customDescriptionDataService.postNewCustomDescription(dataToSend).then(function (result) {

                                closeDialogAndResetItsMessages();
                                displaySuccessToaster();
                                getCustomDescription(result);

                            }).catch(function (result) {
                                closeDialogAndResetItsMessages();
                            });
                        }

                        function updateCustomDescription() {

                            var dataToSend = buildDataToPost();

                            customDescriptionDataService.updateCustomDescription(dataToSend).then(function (result) {

                                closeDialogAndResetItsMessages();
                                displaySuccessToaster();
                                getCustomDescription(result);

                            }).catch(function (result) {
                                closeDialogAndResetItsMessages();
                            });
                        }

                        function getCustomDescription(result) {

                            queryDescriptionProcessorHandler.runProcess($rootScope.currentQueryId, $scope);
                        }

                        function buildDataToPost() {

                            var formData = new FormData();
                            formData.append('customQueryDescription', $scope.files[0]);

                            return {
                                queryId: $rootScope.currentQueryId,
                                acceptLanguage: globalVariables.currentCulture(),
                                formData: formData,
                            };
                        }

                        function displaySuccessToaster() {
                            notificationService.success($translate.instant('CUSTOM_DESCRIPTION_CREATED'));
                        }

                        function resetDialogMessages() {

                            $scope.uploadFileErrorMessage = '';
                        }

                        function closeDialogAndResetItsMessages() {
                            resetDialogMessages();
                            $rootScope.$broadcast('dialog-close');
                        }

                        function resetFileUpload() {

                            $('#flpImportCustomDescription').val('');
                            $scope.$broadcast('clear-upload-files');
                        }

                        function buildDialogSetup(customDescriptionCommandMode) {

                            if (customDescriptionCommandMode) {

                                $scope.dialogSetup.command = customDescriptionCommandMode;

                                if (customDescriptionCommandMode == commandModeValue.import) {
                                    $scope.dialogSetup.showUpdateNotification = false;
                                    $scope.dialogSetup.mainTitle = $translate.instant("UPLOAD_CUSTOM_DESCRIPTION");

                                }
                                else if (customDescriptionCommandMode == commandModeValue.update) {
                                    $scope.dialogSetup.mainTitle = $translate.instant("UPDATE_CUSTOM_DESCRIPTION");
                                    $scope.dialogSetup.showUpdateNotification = true;
                                }
                            }
                        }

                        //#endregion
                    }]
            };

        }]);

})();