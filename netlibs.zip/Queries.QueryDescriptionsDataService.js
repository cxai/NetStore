﻿/// <reference path="../../app.js" />

(function () {
    "use strict";

    checkmarx.Queries.factory('Queries.QueryDescriptionsDataService', ['ajaxService', 'apiBaseURLService',
        function (ajaxService, apiBaseURLService) {

            function getQueryDescriptions(queryId) {

                return ajaxService.get(apiBaseURLService.getAPIBaseURL() + '/Queries/' + queryId);
            }

            return {
                getQueryDescriptions: getQueryDescriptions
            };
    }]);

})();