﻿(function () {
    "use strict";

    checkmarx.LDAP.factory('LDAP.ConfigurationDataService', ['ajaxService', 'apiBaseURLService',
        function (ajaxService, apiBaseURLService) {

            var url = apiBaseURLService.getAPIBaseURL() + '/Configurations/LDAP';
            
            function get() {
                return ajaxService.get(url);
            };

            function put(data) {
                return ajaxService.put(url, data);
            };

        return {
            get: get,
            put: put
        };

    }]);
})();