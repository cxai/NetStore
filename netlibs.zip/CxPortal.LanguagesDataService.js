﻿(function () {
    "use strict";

    checkmarx.CxPortal.factory('CxPortal.LanguagesDataService', ['CxPortal.AjaxServiceWithNotification', 'apiBaseURLService',
        function (ajaxService, apiBaseURLService) {

            var localizationLanguagesUrl = apiBaseURLService.getAPIVirtualDirectory() + '/LocalizationLanguages';
            var localizationDefaultLanguageUrl = apiBaseURLService.getAPIVirtualDirectory() + '/LocalizationDefaultLanguage';

            function get() {
                return ajaxService.get(localizationLanguagesUrl);
            }

            function putDefaultLanguage(defaultLanguage) {
                return ajaxService.put(localizationDefaultLanguageUrl, defaultLanguage);
            }

            return {
                get: get,
                putDefaultLanguage: putDefaultLanguage
            };
        }]);
})();