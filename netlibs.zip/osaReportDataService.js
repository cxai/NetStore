﻿/// <reference path="../../../libs/angular/angular.js" />
/// <reference path="../../../app.js" />
/// <reference path="../services/projectStateValues.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.factory('osaReportDataService', [
        'ProjectState.OSAScansDataService',
        'osaAjaxService',
        'osaSummaryResultsDataService',
        'apiBaseURLService',
        '$q',
        'ProjectState.OSALastFinishedScan',
        function (osaScansDataService, osaAjaxService, osaSummaryResultsDataService, apiBaseURLService, $q, osaLastFinishedScan) {

            var _osaSummaryData = null;

            function getOSAData(projectId) {
                
                var deferred = $q.defer();

                osaScansDataService.get(projectId).then(function (scans) {

                    var osaSummaryData = osaLastFinishedScan.get(scans);

                    _osaSummaryData = osaSummaryData;
                    deferred.resolve(osaSummaryData);
                });

                return deferred.promise;
            }

            function getOSAHTMLData(projectId) {

                var deferred = $q.defer();

                getOSAData(projectId).then(function (osaSummaryData) {

                    var url = apiBaseURLService.getAPIVirtualDirectory() + '/osa/reports?scanId=' + osaSummaryData.id + '&reportFormat=html';

                    osaAjaxService.get(url).then(function (result) {

                        var model = {
                            osaSummaryData: _osaSummaryData,
                            osaHTML: result
                        };

                        deferred.resolve(model);
                    });
                });

                return deferred.promise;
            }

            function getOSAReportPDF(projectId) {

                return getOSAData(projectId).then(function (osaSummaryData) {

                    return osaAjaxService.get(
                            apiBaseURLService.getAPIVirtualDirectory() + '/osa/reports?scanId=' + osaSummaryData.id + '&reportFormat=pdf',
                            { responseType: 'arraybuffer' });
                });
            }

            return {
                getOSAHTMLData: getOSAHTMLData,
                getOSAReportPDF: getOSAReportPDF
            };
        }]);
})();