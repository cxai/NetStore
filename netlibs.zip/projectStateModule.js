﻿/// <reference path="../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState = angular.module('ProjectState', []);

})();