﻿/// <reference path="app.js" />

(function () {
    "use strict";

    checkmarx.Common = angular.module('Common', ['ngCookies', 'csrf-cross-domain', 'pascalprecht.translate', 'toastr']);

    checkmarx.Common.config(['$httpProvider', 'csrfCDProvider', function ($httpProvider, csrfCDProvider) {

        $httpProvider.defaults.withCredentials = true;
        csrfCDProvider.setHeaderName('CXCSRFToken');
        csrfCDProvider.setCookieName('CXCSRFToken');
    }]);

})();