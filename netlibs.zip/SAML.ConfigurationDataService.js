﻿(function () {
	"use strict";

	checkmarx.SAML.factory('SAML.ConfigurationDataService', ['ajaxService', 'apiBaseURLService', 'cxPortalRoles', 'cxPortalRolesPrivileges', function (ajaxService, apiBaseURLService, cxPortalRoles, cxPortalRolesPrivileges) {

	    var url = apiBaseURLService.getAPIBaseURL() + '/SamlIdentityProvider';
	    var downloadLink = apiBaseURLService.getAPIBaseURL() + '/SamlServiceProviderMetadata';
	    var extendedDownloadLink = apiBaseURLService.getAPIBaseURL() + '/SamlServiceProviderExtendedMetadata';

	    function getDownloadLink() {
	        return downloadLink
	    }

	    function getExtendedDownloadLink() {
	        return extendedDownloadLink
	    }

        function buildConfig() {

            return {
		        headers: {                
		            'Content-Type': undefined
                }
            };
       }

        function buildAllowedRoleActions(data, selectedRole) {
            var allowedRoleActions = [];
            if (selectedRole) {
                if (selectedRole == cxPortalRoles.reviewer) {
                    if (data.manualUserManagement.allowSeverityAndStatusChanges) {
                        allowedRoleActions.push(cxPortalRolesPrivileges.allowSeverityAndStatusChanges);
                    }
                } else {
                    if (data.manualUserManagement.allowNotExploitable) {
                        allowedRoleActions.push(cxPortalRolesPrivileges.allowNotExploitable);
                    }
                    if (data.manualUserManagement.allowProjectAndScanDelete) {
                        allowedRoleActions.push(cxPortalRolesPrivileges.allowProjectAndScanDelete);
                    }
                }
            }
            return allowedRoleActions.join();
        }


		function createData(configurationData) {
		    var formData = new FormData();

		    if (configurationData.idPCertificateFiles) {
		        formData.append("certificateFile", configurationData.idPCertificateFiles[0]);
		    }

		    formData.append("isEnabled", configurationData.isEnabled ? "true" : "false");

		    formData.append("name", configurationData.samlApiName ? configurationData.samlApiName : "");
		    formData.append("issuer", configurationData.identityProvider ? configurationData.identityProvider : "");
		    formData.append("loginURL", configurationData.loginURL ? configurationData.loginURL : "");
		    formData.append("logoutURL", configurationData.logoutURL ? configurationData.logoutURL : "");
		    formData.append("customErrorUrl", configurationData.errorURL ? configurationData.errorURL : "");
		    formData.append("clientSignatureRequired", configurationData.clientSignatureRequired ? "true": "false");

		    formData.append("isManualManagement", configurationData.userManagementMethod && configurationData.userManagementMethod.value == 1 ? "true" : "false");

		    if (configurationData.userManagementMethod && configurationData.userManagementMethod.value == 1) {
		        var selectedRole;

		        if (configurationData.manualUserManagement.role) {
		            selectedRole = configurationData.manualUserManagement.role.id;
		        }

		        formData.append("defaultTeamId", configurationData.manualUserManagement.defaultTeam.value ? configurationData.manualUserManagement.defaultTeam.value : "");
		        formData.append("defaultRole", selectedRole ? selectedRole : "");
		        formData.append("allowedRoleActions", buildAllowedRoleActions(configurationData, selectedRole));
		    }
		    

		    return formData;
		}

		function get() {

		    return ajaxService.get(url);
		}

		function post(configurationData) {

		    var data = createData(configurationData);
            return ajaxService.post(url, data, buildConfig());
		}

		function put(configurationData) {

		    var data = createData(configurationData);
            return ajaxService.put(url, data, buildConfig());
        }

		return {
		    getDownloadLink: getDownloadLink,
		    getExtendedDownloadLink: getExtendedDownloadLink,
            get: get,
            post: post,
            put: put
		};

	}]);
})();