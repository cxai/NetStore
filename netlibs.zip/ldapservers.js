﻿//Global Variables
var inputId = 0;
var ldapServers = [];
var currentLDAPServers = [];
var originalLDAPServers = [];
var ldapServersDataHash = {};
var domainsAvailable = [];

//CONST
var REVIEWER = "1"
var SCANNER = "0"
var ACTIVE_DIRECTORY = "1";

//Parsley Configuration
window.ParsleyConfig = { excluded: "input[type=button], input[type=submit], input[type=reset], input[type=hidden], [disabled], :hidden, .form-control-noparsley" };

//Parsley custom validatior
window.ParsleyValidator
  .addValidator('portValidator', function (value, requirement) {
      if (0 === value % (!isNaN(parseFloat(value)) && 0 <= ~~value)) {
          return true;
      } else {
          return false;
      }
  }, 32);

//Initilize
$(function () {

    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": true,
        "showDuration": "300",
        "hideDuration": "5000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    $('.form-horizontal').parsley();

    $("#accordion").accordion({
        active: false,
        collapsible: true,
        heightStyle: "content"
    });
    showSpinner();
    $.ajax({
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        type: 'POST',
        url: 'LDAPServers.aspx/GetServersData',
        success: function (response) {
            hideSpinner();
            if (response.d !== null) {
                originalLDAPServers = response.d.serverConfigs;
                getDomainsAvailableAndInitLDAPServers(originalLDAPServers, false);
            }
        },
        failure: function (response) {
            hideSpinner();
        }
    });

});

//Click buttons function: save, delete, clear, test ...
//***************************************************************************************************************

//Click on delete button
function deleteCB(event, hdnDeleted, hdnSUCCESSFULL_SERVER_DELETION, hdnSUCCESS) {

    var that = $(this);

    var dataAction = $(this).closest('h3').next().attr('data-action');

    swal({
        title: $('#hdnAreYouSure').val(),
        text: $('#hdnSERVER_CONFIGURATION_TEXT').val(),
        dangerMode: true,
        icon: "warning",
        buttons: {
            cancel: {
                text: $('#hdnCANCEL').val(),
                closeModal: true,
                visible: true
            },
            confirm: {
                text: $('#hdnYES_DELETE').val(),
                closeModal: false,
                visible: true
            }
        }

        }).then(
        function (isConfirm) {
            $('.sweet-alert.showSweetAlert:visible button.confirm').removeAttr('disabled');
            if (isConfirm) {
                showSpinner();
                if (dataAction == "Insert") {
                    deleteAccordionItem(that);
                    swal({
                        title: $("#hdnDeleted").val(),
                        text: $("#hdnSUCCESSFULL_SERVER_DELETION").val(),
                        icon: "success"
                    }).then(function () {
                        $(document).trigger('sweetalert-modal-closed');
                    });
                    hideSpinner();
                }
                else {
                    $('.sweet-alert.showSweetAlert:visible button.confirm').attr('disabled', 'disabled');
                    $.ajax({
                        type: "POST",
                        url: "LDAPServers.aspx/DeleteServer",
                        data: JSON.stringify({
                            serverList: getServerObjectDataForDeletion(that)
                        }),
                        contentType: 'application/json; charset=utf-8',
                        dataType: 'json',
                        success: function (response) {
                            if (response.d !== null) {
                                if (response.d == true) {
                                    deleteAccordionItem(that);
                                    swal({
                                        title: $("#hdnDeleted").val(),
                                        text: $("#hdnSUCCESSFULL_SERVER_DELETION").val(),
                                        icon: "success"
                                    }).then(function () {
                                        $(document).trigger('sweetalert-modal-closed');
                                    });
                                }
                                else {
                                    $(document).trigger('sweetalert-modal-closed');
                                    toastr.error($("#hdnDELETE_LDAP_SERVER_FAILED").val());
                                }
                                $('button.confirm').removeAttr('disabled', 'disabled');
                                hideSpinner();
                            }
                        },
                        failure: function (response) {
                            $('button.confirm').removeAttr('disabled', 'disabled');
                            toastr.error("General Error");
                            hideSpinner();
                        }
                    });
                }
            }
            else {
                $(document).trigger('sweetalert-modal-closed');
                hideSpinner();
            }
        });

    preventEvents(event);
    return false;
};

//Click on cancel button when the uer dne server
function clearCB(event) {
    var h3 = $(this).parent().parent().parent().parent().prev();
    var form = $(this).parent().parent().parent().parent().find('form');

    $(this).closest('.server').prev().children().eq(1).text($("#hdnNEW_SERVER").val());
    form.find('[data-name="Name"]').val("");

    form.find('[data-name="LdapSSO"]').prop('checked', false);
    form.find('[data-name="DirectoryType"]').val("");
    form.find('[data-name="HostName"]').val("");
    form.find('[data-name="Port"]').val("");

    form.find('[data-name="UseSSL"]').prop('checked', false);
    form.find('[data-name="VerifySslCertificate"]').prop('checked', false);
    form.find('input[data-name="VerifySslCertificate"]').attr("disabled", true);

    form.find('[data-name="UserName"]').val("");
    form.find('[data-name="Password"]').val("");
    form.find('[data-name="BaseDn"]').val("");
    form.find('[data-name="AdditionalUserDn"]').val("");

    form.find('[data-name="UserObjectSchema"]').val("");
    form.find('[data-name="UserObjectFilter"]').val("");
    form.find('[data-name="UserNameAttribute"]').val("");
    form.find('[data-name="UserRDNAttribute"]').val("");
    form.find('[data-name="UserFirstNameAttribute"]').val("");
    form.find('[data-name="UserLastNameAttribute"]').val("");
    form.find('[data-name="UserEmailAttribute"]').val("");

    var id = getServerId($(this));
    setNonActiveDirectoryValues(id);
    showWarningIfSsoAndSync(false, false, id);
    clearSynchronizationSectionFields(form);

    form.parent().find('.cancelButton').css("background-color", "white");
    form.parsley().destroy();
};

//Help function for clearCB function
function clearSynchronizationSectionFields(form) {

    form.find('input[data-name="Enabled"]').removeAttr("disabled");
    form.find('[data-name="Enabled"]').prop('checked', false);
    setInputValues(form.find('[data-name="Enabled"]'), form, form.find('.rowEnbaledSynchronization'));

    form.find('[data-name="AdditionalGroupDN"]').val("");
    form.find('[data-name="GroupObjectClass"]').val("");
    form.find('[data-name="GroupObjectFilter"]').val("");
    form.find('[data-name="GroupIDAttribute"]').val("");
    form.find('[data-name="GroupNameAttribute"]').val("");
    form.find('[data-name="GroupMembersAttribute"]').val("");
    form.find('[data-name="UserMembershipAttribute"]').val("");

    form.find('[data-name="DefaultRoleId"]').val("");
    setRoleAttributeAccordingTo(form.find('[data-name="DefaultRoleId"]').val(), form, false);

    form.find('[data-name="AdvancedRoleMappingEnabled"]').prop('checked', false);
    clearAdvancedRoleMapping(form);
};

//Click on cancel button when the server exists
function cancelCB(event) {

    var h3 = $(this).parent().parent().parent().parent().prev();
    var form = $(this).parent().parent().parent().parent().find('form');

    $(this).closest('.server').prev().children().eq(1).text(ldapServersDataHash[h3.attr('data-id')].Name);
    form.find('[data-name="Name"]').val(ldapServersDataHash[h3.attr('data-id')].Name);

    form.find('[data-name="DirectoryType"]').val(form.find('[data-name="DirectoryType"] option').eq(ldapServersDataHash[h3.attr('data-id')].DirectoryType).text());

    var id = getServerId($(this));
    if (ldapServersDataHash[h3.attr('data-id')].DirectoryType == ACTIVE_DIRECTORY) {
        setActiveDirectoryValues(id);
    }
    else {
        setNonActiveDirectoryValues(id);
    }


    form.find('[data-name="HostName"]').val(ldapServersDataHash[h3.attr('data-id')].HostName);
    form.find('[data-name="Port"]').val(ldapServersDataHash[h3.attr('data-id')].Port);

    if (ldapServersDataHash[h3.attr('data-id')].UseSSL == true) {
        form.find('[data-name="UseSSL"]').prop('checked', true);
        form.find('input[data-name="VerifySslCertificate"]').removeAttr("disabled");
    }
    else {
        form.find('[data-name="UseSSL"]').prop('checked', false);
        form.find('input[data-name="VerifySslCertificate"]').attr("disabled", true);
    }

    ldapServersDataHash[h3.attr('data-id')].VerifySslCertificate ? form.find('[data-name="VerifySslCertificate"]').prop('checked', true) : form.find('[data-name="VerifySslCertificate"]').prop('checked', false);

    form.find('[data-name="UserName"]').val(ldapServersDataHash[h3.attr('data-id')].UserName);
    form.find('[data-name="Password"]').val(ldapServersDataHash[h3.attr('data-id')].Password);
    form.find('[data-name="BaseDn"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].BaseDn).text());
    form.find('[data-name="AdditionalUserDn"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].AdditionalUserDn).text());


    form.find('[data-name="UserObjectSchema"]').val(ldapServersDataHash[h3.attr('data-id')].UserObjectClass);
    form.find('[data-name="UserObjectFilter"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].UserObjectFilter).text());
    form.find('[data-name="UserNameAttribute"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].UsernameAttribute).text());
    form.find('[data-name="UserRDNAttribute"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].UserRdnAttribute).text());
    form.find('[data-name="UserFirstNameAttribute"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].FirstNameAttribute).text());
    form.find('[data-name="UserLastNameAttribute"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].LastNameAttribute).text());
    form.find('[data-name="UserEmailAttribute"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].EmailAttribute).text());

    if (ldapServersDataHash[h3.attr('data-id')].Enabled == true) {
        form.find('[data-name="Enabled"]').prop('checked', true);
    }
    else {
        form.find('input[data-name="Enabled"]').removeAttr("disabled");
        form.find('[data-name="Enabled"]').prop('checked', false);
    }
    setInputValues(form.find('[data-name="Enabled"]'), form, form.find('.rowEnbaledSynchronization'));
    showWarningIfSsoAndSync(ldapServersDataHash[h3.attr('data-id')].isMappedToDomain, ldapServersDataHash[h3.attr('data-id')].Enabled, id);

    form.find('[data-name="AdditionalGroupDN"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].AdditionalGroupDN).text());
    form.find('[data-name="GroupObjectClass"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].GroupObjectClass).text());
    form.find('[data-name="GroupObjectFilter"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].GroupObjectFilter).text());
    form.find('[data-name="GroupIDAttribute"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].GroupIDAttribute).text());
    form.find('[data-name="GroupNameAttribute"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].GroupNameAttribute).text());
    form.find('[data-name="GroupMembersAttribute"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].GroupMembersAttribute).text());
    form.find('[data-name="UserMembershipAttribute"]').val($('<div/>').html(ldapServersDataHash[h3.attr('data-id')].UserMembershipAttribute).text());

    form.find('[data-name="DefaultRoleId"]').val(ldapServersDataHash[h3.attr('data-id')].DefaultRoleId);
    setRoleAttributeAccordingTo(ldapServersDataHash[h3.attr('data-id')].DefaultRoleId, form, false);

    if (ldapServersDataHash[h3.attr('data-id')].AdvancedRoleMappingEnabled == true) {
        form.find('[data-name="AdvancedRoleMappingEnabled"]').prop('checked', true);
        enableAdvancedRoleMappingTextBoxs(form);
    }
    else {
        form.find('[data-name="AdvancedRoleMappingEnabled"]').prop('checked', false);
        disableAdvancedRoleMappingTextBoxs(form);
    }
    ldapServersDataHash[h3.attr('data-id')].AdvancedRoleMappingEnabled ? form.find('[data-name="AdvancedRoleMappingEnabled"]').prop('checked', true) : form.find('[data-name="AdvancedRoleMappingEnabled"]').prop('checked', false);

    form.find('[data-name="ReviewerWithoutRoleAttributesGroupDnList"]').val(ldapServersDataHash[h3.attr('data-id')].ReviewerWithoutRoleAttributesGroupDnList);
    form.find('[data-name="ReviewerWithSeverityStatusChangeGroupDnList"]').val(ldapServersDataHash[h3.attr('data-id')].ReviewerWithSeverityStatusChangeGroupDnList);

    form.find('[data-name="ScannerWithoutRoleAttributesGroupDnList"]').val(ldapServersDataHash[h3.attr('data-id')].ScannerWithoutRoleAttributesGroupDnList);
    form.find('[data-name="ScannerWithNotExploitableGroupDnList"]').val(ldapServersDataHash[h3.attr('data-id')].ScannerWithNotExploitableGroupDnList);
    form.find('[data-name="ScannerWithDeleteGroupDnList"]').val(ldapServersDataHash[h3.attr('data-id')].ScannerWithDeleteGroupDnList);
    form.find('[data-name="ScannerWithNotExploitableAndDeleteGroupDnList"]').val(ldapServersDataHash[h3.attr('data-id')].ScannerWithNotExploitableAndDeleteGroupDnList);

    form.find('[data-name="Name"]').focus();
};

//Click on save button
function saveCB(event) {

    var that = $(this);
    var isValidate = true;

    var h3 = $(this).parent().parent().parent().parent().prev();
    var server = $(this).parent().parent().parent().parent();
    var form = server.find('form')
    form.each(function () {
        var form = $(this);
        if (form.attr('class').indexOf('form-authentication') > -1) {
            isValidate &= checkSpecificFormValidation(form);
        }
    });
    changeBorderColor(server.find('form'), isValidate);
    var dataAction = server.attr('data-action');

    if (isValidate == true) {
        showSpinner();
        var returnData = [];
        var id = h3.attr('data-id');
        var currentServer = form;//h3.next();
        var isChanged = false;
        if (!!currentServer) {
            if (dataAction === 'None') {
                var serverObject = new Object();
                $(currentServer).find('input:text, input:password, input:file,input:radio, input:checkbox, select, textarea')
                            .each(function () {
                                addServerElementToServerObject(serverObject, $(this));
                            });

                serverObject.Action = '2'; //Update
                serverObject.Id = id;
                returnData.push(serverObject);
            }
            else if (dataAction === 'Insert') {

                var serverObject = new Object();
                serverObject.Action = '1'; //Insert
                serverObject.serverType = '1'; //LDAP Server
                $(currentServer).find('input:text, input:password, input:file,input:radio, input:checkbox, select, textarea')
                        .each(function () {
                            addServerElementToServerObject(serverObject, $(this));
                        });
                serverObject.Id = 0;
                returnData.push(serverObject);
            }

        }

        if (returnData.length > 0) {
            form.parent().find(".saveButton").attr("disabled", true);
            $.ajax({
                type: "POST",
                url: "LDAPServers.aspx/SaveServersData",
                data: JSON.stringify({
                    serverList: returnData
                }),
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function (response) {
                    hideSpinner();
                    if (response.d !== null) {
                        if (response.d.IsSuccesfull === true) {
                            toastr.success('Server configuration was successfully saved');
                            server.attr('data-action', 'None');
                            h3.attr('data-id', response.d.serverConfigs[0].Id);
                            if (form.find('[data-name="Enabled"]').is(':checked') == false) {
                                clearSynchronizationSectionFields(form);
                            }
                            getDomainsAvailableAndInitLDAPServers(getCurrentLDAPServers(), true);
                        }
                        else if (response.d.IsSuccesfull === false) {
                            toastr.error(response.d.ErrorMessage); //Add failure message
                        }
                        form.parent().find(".saveButton").removeAttr("disabled");

                    }
                },
                failure: function (response) {
                    form.parent().find(".saveButton").removeAttr("disabled");
                    toastr.info("General Error");
                    hideSpinner();
                }
            });
        }
        else {
            toastr.info("Saved canceled <br/> There wasn't data change on the form");
            hideSpinner();
        }
    }

    preventEvents(event);
    return false;
};

function testCB(event) {

    var that = $(this).parent().parent().parent().parent(); 

    var isValidate = true;
    that.find('form').each(function () {
        var form = $(this);
        if (form.attr('class').indexOf('form-authentication') > -1 || (form.attr('class').indexOf('form-synchronization') > -1 && form.find('.enabledCheckBox').is(':checked'))) {
            isValidate &= checkSpecificFormValidation(form);
        }
    });
    changeBorderColor(that.find('form'), isValidate);
    if (isValidate == true) {
        showSpinner();

        $.ajax({
            type: "POST",
            url: "LDAPServers.aspx/TestConnection",
            data: JSON.stringify({
                serverList: getServerObjectData('3', that)
            }),
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            success: function (response) {
                hideSpinner();
                if (response.d !== null) {
                    if (response.d.IsSuccesfull === true) {
                        toastr.success($("#hdnSERVER_CONNECTION_VERIFIED_SUCCESSFULLY").val());
                    }
                    else if (response.d.IsSuccesfull === false) {
                        toastr.error(response.d.ErrorMessage); //Add failure message
                    }
                }
            },
            failure: function (response) {
                toastr.info("General Error");
                hideSpinner();
            }
        });
    }
    preventEvents(event);
    return false;
};

//End Click buttons function: save, delete, clear, test ...
//************************************************************************************************************************************


function getDomainsAvailableAndInitLDAPServers(LDAPServers, reload) {

    var GetDomainsDetailsUrl = Core.REST.getRestBaseUrl() + Core.REST.restUrlPrefix + 'activeDirectoryDomains';
    var ajaxParams = {
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        url: GetDomainsDetailsUrl,
        success: function (response) {
            if (response !== null) {
                domainsAvailable = response;
                if (reload) {
                    reloadDomains(LDAPServers);
                }
                else {
                    renderServers(LDAPServers);
                }
            }
        },
        error: function (response) {
            if (!reload) {
                renderServers(LDAPServers);
            }
        }
    };
    Core.web.ajax.get(ajaxParams);
};

function renderServers(originalLDAPServers) {
    if (!!originalLDAPServers && originalLDAPServers.length > 0) {
        buildLDAPServers(originalLDAPServers);
    }
    else {
        addNewLDAPServer();
        $("#accordion").accordion("option", "active", 0);
    }
};

function showDomainsInUseMesaage(domainsContainsDomainInUse) {
    if (domainsContainsDomainInUse) {
        $('.domain-in-use-message').show();
    }
    else {
        $('.domain-in-use-message').hide();
    }
};

function setDomainsInSelectObject(inputId, mappedDomain) {
    var selectedElm = '#select-domain-for-sso-' + inputId;
    var $base = $(selectedElm);
    var domainsContainsDomainInUse = false;
    var isInUseNotByMe = false;

    $base.append("<option id='sso-enabled-dd-title-" + inputId + "' value='' style='font-weight:bold !important;'>" + $("#hdnDOMAIN").val() + "</option>");
    $.each(domainsAvailable, function (index, domain) {
        isInUseNotByMe = (domain.isMappedToLdap || domain.hasDomainUsers) && mappedDomain != domain.names.netbiosName;
        domainsContainsDomainInUse = isInUseNotByMe ? true: domainsContainsDomainInUse;
        $base.append("<option class='sso-enabled-dd' " +(mappedDomain == domain.names.netbiosName ? "selected ": "") +(isInUseNotByMe ? "disabled " : "") + "full-name='" + domain.names.fullyQualifiedName + "' value='" +domain.names.netbiosName + "'>" +domain.names.netbiosName +(isInUseNotByMe ? "*" : "") + "</option>");
        });
    showDomainsInUseMesaage(domainsContainsDomainInUse);
};

function showWarningIfSsoAndSync(isMappedToDomain, syncSettingsEnabled, inputId) {
    if (isMappedToDomain && syncSettingsEnabled) {
        $("#sso-sync-warning-message-" + inputId).show();
    }
    else {
        $("#sso-sync-warning-message-" + inputId).hide();
    }
    };

function removeSelectOptions(id) {
    $('#select-domain-for-sso-' + id).empty();
};

function reloadDomains(currentLDAPServers) {
    for (var i = 0; i < inputId; i++) {
        if (currentLDAPServers[i] != null) {
            removeSelectOptions(i);
            setDomainsInSelectObject(i, currentLDAPServers[i].SSOEnabled ? currentLDAPServers[i].DomainNetbiosName : "");
        }
    }
};

function getServerObjectDataForDeletion(deleteButton) {
    var accordionElement = deleteButton.closest('h3'),
        currentServer = getServerObjectData('3', accordionElement.next())[0],
        serverId = accordionElement.attr('data-id'),
        originalServer = originalLDAPServers.filter(function (server) { return server.Id == serverId; })[0];

    if (!originalServer) {
        currentServer.id = serverId;
        originalServer = currentServer;
    }

    if (serverId > 0) {
        if (originalServer) {
            var result = {};
            for (var prop in originalServer) {
                if (Object.prototype.hasOwnProperty.call(originalServer, prop)) {
                    result[prop] = originalServer[prop];
                }
            }
            for (var prop in currentServer) {
                if (Object.prototype.hasOwnProperty.call(currentServer, prop)) {
                    if (result[prop] === undefined || result[prop] === null || result[prop] === '') {
                        result[prop] = currentServer[prop];
                    }
                }
            }
            result.Action = '3'; // Delete
            result.serverType = '1'; //LDAP Server
            return [result];
        }
    }
    else {
        return currentServer;
    }
};

function getServerObjectData(action, that) {
    var returnData = [];
    var server = new Object();
    server.Action = action;
    server.serverType = '1'; //LDAP Server
    that.find('input:text, input:password, input:file,input:radio, input:checkbox, select, textarea')
            .each(function () {
                addServerElementToServerObject(server, $(this));
            });

    returnData.push(server);

    return returnData;
};

function addServerElementToServerObject(serverObject, that) {
    var propertyName = that.data("name");
    if (that.is(':checkbox')) {
        serverObject[propertyName] = that.is(':checked');        
    }
    else {
        serverObject[propertyName] = that.val();
        if ($(":selected", that).attr('full-name')) {
            serverObject["DomainFullyQualifiedName"] = $(":selected", that).attr('full-name');
        }
    }
};

function checkSpecificFormValidation(form) {
    //Check form by parsley
    var isValidate = true;
    if (form.parsley().validate() === false) {
        isValidate = false;
    }
    return isValidate;
};

function changeBorderColor(form, isValidate) {
    if (isValidate) {
        form.closest('.ui-accordion-content').prev().css({ 'border': '1px solid #d3d3d3' });
    }
    else {
        form.closest('.ui-accordion-content').prev().css({ 'border-color': 'red', 'border-width': '1px' });
    }
};

function deleteAccordionItem(that) {
    var head = that.closest('h3');
    var parent = head.next();
    var toRemove = parent.add(head);
    toRemove.fadeOut('slow', function () { toRemove.remove(); });
};

function preventEvents(event) {
    event.stopImmediatePropagation();
    event.preventDefault();
    event.stopPropagation();
};

function showSpinner() {
    $('.spinner').fadeIn('fast');
    $('#backgroundScreen').fadeIn('fast');
};

function hideSpinner() {
    $('.spinner').stop().fadeOut('fast');
    $('#backgroundScreen').stop().fadeOut('fast');
};

//Function for save the data to local array
function setServerData(arrayData) {
    serverDataArray =[];

    serverDataArray.Name = arrayData.Name;
    serverDataArray.DirectoryType = arrayData.DirectoryType;
    serverDataArray.HostName = arrayData.HostName;
    serverDataArray.Port = arrayData.Port;
    serverDataArray.UseSSL = arrayData.UseSSL;
    serverDataArray.SSOEnabled = arrayData.DomainMapSettings.IsMappedToDomain;
    serverDataArray.DomainNetbiosName = arrayData.DomainMapSettings.DomainNetbiosName;
    serverDataArray.DomainFullyQualifiedName = arrayData.DomainMapSettings.DomainFullyQualifiedName;
    serverDataArray.VerifySslCertificate = arrayData.VerifySslCertificate;
    serverDataArray.UserName = arrayData.Username;
    serverDataArray.Password = arrayData.Password;
    serverDataArray.BaseDn = arrayData.BaseDn;
    serverDataArray.AdditionalUserDn = arrayData.AdditionalUserDn;
    serverDataArray.UserObjectClass = arrayData.UserObjectClass;
    serverDataArray.UserObjectFilter = arrayData.UserObjectFilter;
    serverDataArray.UsernameAttribute = arrayData.UsernameAttribute;
    serverDataArray.UserRdnAttribute = arrayData.UserRdnAttribute;
    serverDataArray.FirstNameAttribute = arrayData.FirstNameAttribute;
    serverDataArray.LastNameAttribute = arrayData.LastNameAttribute;
    serverDataArray.EmailAttribute = arrayData.EmailAttribute;
    serverDataArray.AdditionalGroupDN = arrayData.SyncSettings.AdditionalGroupDN;
    serverDataArray.GroupObjectClass = arrayData.SyncSettings.GroupObjectClass;
    serverDataArray.GroupObjectFilter = arrayData.SyncSettings.GroupObjectFilter;
    serverDataArray.GroupIDAttribute = arrayData.SyncSettings.GroupIdAttribute;
    serverDataArray.GroupNameAttribute = arrayData.SyncSettings.GroupNameAttribute;
    serverDataArray.GroupMembersAttribute = arrayData.SyncSettings.GroupMembersAttribute;
    serverDataArray.UserMembershipAttribute = arrayData.SyncSettings.UserMembershipAttribute;

    serverDataArray.Enabled = arrayData.SyncSettings.Enabled;
    serverDataArray.DefaultRoleId = arrayData.SyncSettings.LdapRoleMapping.DefaultRoleId;
    serverDataArray.DefaultRoleApplyNotExploitable = arrayData.SyncSettings.LdapRoleMapping.WsLdapAdvancedRoleMapping.DefaultRoleApplyNotExploitable;
    serverDataArray.DefaultRoleDeleteProjectsAndScans = arrayData.SyncSettings.LdapRoleMapping.DefaultRoleDeleteProjectsAndScans;
    serverDataArray.DefaultRoleAllowStatusSeverityChanges = arrayData.SyncSettings.LdapRoleMapping.DefaultRoleAllowStatusSeverityChanges;

    serverDataArray.AdvancedRoleMappingEnabled = arrayData.SyncSettings.LdapRoleMapping.AdvancedRoleMappingEnabled;
    serverDataArray.ScannerWithoutRoleAttributesGroupDnList = arrayData.SyncSettings.LdapRoleMapping.WsLdapAdvancedRoleMapping.ScannerWithoutRoleAttributesGroupDnList;
    serverDataArray.ScannerWithNotExploitableGroupDnList = arrayData.SyncSettings.LdapRoleMapping.WsLdapAdvancedRoleMapping.ScannerWithNotExploitableGroupDnList;
    serverDataArray.ScannerWithDeleteGroupDnList = arrayData.SyncSettings.LdapRoleMapping.WsLdapAdvancedRoleMapping.ScannerWithDeleteGroupDnList;
    serverDataArray.ScannerWithNotExploitableAndDeleteGroupDnList = arrayData.SyncSettings.LdapRoleMapping.WsLdapAdvancedRoleMapping.ScannerWithNotExploitableAndDeleteGroupDnList;
    serverDataArray.ReviewerWithoutRoleAttributesGroupDnList = arrayData.SyncSettings.LdapRoleMapping.WsLdapAdvancedRoleMapping.ReviewerWithoutRoleAttributesGroupDnList;
    serverDataArray.ReviewerWithSeverityStatusChangeGroupDnList = arrayData.SyncSettings.LdapRoleMapping.WsLdapAdvancedRoleMapping.ReviewerWithSeverityStatusChangeGroupDnList;
    serverDataArray.Enabled = arrayData.SyncSettings.Enabled;

    return serverDataArray;
};

//Building the LDAP Servers that exists in the DB
//****************************************************************************
function buildLDAPServers(serversList) {
    var accordion = $('#accordion');
    for (var i = 0; i < serversList.length; i++) {
        var serverDataArray = setServerData(serversList[i]);
        ldapServersDataHash[serversList[i].Id] = serverDataArray;
        var div = ldapServer.getServerDiv(inputId, serversList[i]);
        var elem = $(div);

        serversList[i].SyncSettings.Enabled == true ? (elem.find('.enabledCheckBox').prop('checked', true) && elem.find('.rowEnbaledSynchronization').show()) : (elem.find('.enabledCheckBox').prop('checked', false) && elem.find('.rowEnbaledSynchronization').hide());
        serversList[i].SyncSettings.LdapRoleMapping.AdvancedRoleMappingEnabled == true ? elem.find('#advancedRoleMapping_cb').prop('checked', true): elem.find('#advancedRoleMapping_cb').prop('checked', false);

        serversList[i].UseSSL == true ? elem.find('#primary_cb').prop('checked', true) : elem.find('#primary_cb').prop('checked', false);
        serversList[i].DomainMapSettings.IsMappedToDomain == true ? elem.find('.sso-enabled-cb').prop('checked', true) : elem.find('.sso-enabled-cb').prop('checked', false);
        serversList[i].VerifySslCertificate == true ? elem.find('#secondary_CB').prop('checked', true) : elem.find('#secondary_CB').prop('checked', false);

        setInputValues(elem.find('.enabledCheckBox'), elem.find('.enabledCheckBox').closest("form"), elem.find('.rowEnbaledSynchronization'));

        accordion.append(elem);

        setDomainsInSelectObject(inputId, serversList[i].DomainMapSettings.DomainNetbiosName);
        enableSSOIfActiveDirectory(serversList, i, inputId, elem);
        showWarningIfSsoAndSync(serversList[i].DomainMapSettings.IsMappedToDomain, serversList[i].SyncSettings.Enabled, inputId);
        setRoleAttributeAccordingTo(serversList[i].SyncSettings.Enabled == true ? serversList[i].SyncSettings.LdapRoleMapping.DefaultRoleId : '', elem, false);
        ldapServer.setTranslations(serversList, elem, i);

        $(elem).find('.deleteAction button').click(deleteCB);
        $(elem).find('.saveAction button').click(saveCB);
        $(elem).find('.cancelAction button').click(cancelCB);
        $(elem).find('.connectionAction button').click(testCB);

        inputId++;
    }
    accordion.accordion('destroy').accordion({
        active: false,
        collapsible: true,
        heightStyle: "content"
    });

};
//****************************************************************************

function enableSSOIfActiveDirectory(serversList, i, inputId, elem) {
    var checkboxId = "#sso-enabled-cb-" + inputId;
    var tooltipId = "#custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP" +inputId;
    var disabledTooltipId = "#custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP_DISABLED" + inputId;

    if (serversList[i].DirectoryType == ACTIVE_DIRECTORY) {
        elem.find(checkboxId).removeAttr("disabled");
        elem.find(disabledTooltipId).hide();
    }
    else {
        elem.find(tooltipId).hide();
    }
};

function setRoleAttributeAccordingTo(role, elem, isChangeEvent) {
    if (role == SCANNER) {
        $(elem).find("#allowSeverityStatusChanges").hide();
        $(elem).find("#permissionToChangeNotExploitable").show();
        $(elem).find("#allowDeleteProjectScan").show();
    }
    else if (role == REVIEWER) {
        if (!isChangeEvent) {
            //set default
            $(elem).find('[data-name="DefaultRoleApplyNotExploitable"]').prop('checked', true);
        }
        $(elem).find("#allowSeverityStatusChanges").show();
        $(elem).find("#permissionToChangeNotExploitable").hide();
        $(elem).find("#allowDeleteProjectScan").hide();
    }
    else {
        //default (clear, set default)
        $(elem).find('[data-name="DefaultRoleApplyNotExploitable"]').prop('checked', true);

        $(elem).find("#allowSeverityStatusChanges").hide();
        $(elem).find("#permissionToChangeNotExploitable").show();
        $(elem).find("#allowDeleteProjectScan").show();
    }
};

function checkAllValidationForms(form) {
    if ($(form).parsley().validate() === false) {
        $(form).closest('.server').prev().css({ 'border-color': 'red', 'border-width': '1px' });
        return false;
    }
    else {
        $(form).closest('.server').prev().css({ 'border': '1px solid #d3d3d3' });
        return true;
    }
};

function getCurrentLDAPServers() {
//notice some values can be null if servers were deleted
    var currentLDAPServers = [];
    var count = 0;
    var thisServer;
    $(".server").each(function () {
        var server = new Array();
        thisServer = $(this);
        thisServer.find('input:text, input:password, input:file,input:radio, input:checkbox, select, textarea')
                .each(function () {
                    addServerElementToServerObject(server, $(this));
                });
        server.inputId = getServerId(thisServer);
        currentLDAPServers[server.inputId] = server;

    });
    return currentLDAPServers;
};

function getServerId(element) {
    var serverElement = element.closest('.server');
    return serverElement.attr('input-id');
};

function setActiveDirectoryValues(id) {
    var ssoCheckboxId = "#sso-enabled-cb-" + id;
    var tooltipId = "#custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP" + id;
    var disabledTooltipId = "#custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP_DISABLED" + id;

    $(ssoCheckboxId).removeAttr("disabled");
    $(tooltipId).show();
    $(disabledTooltipId).hide();
};

function setNonActiveDirectoryValues(id) {
    var ssoCheckboxId = "#sso-enabled-cb-" + id;
    var ssoDropdownId = "#select-domain-for-sso-" + id;
    var ssoDropdownTitleId = "#sso-enabled-dd-title-" + id;
    var tooltipId = "#custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP" + id;
    var disabledTooltipId = "#custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP_DISABLED" + id;

    $(ssoCheckboxId).attr("disabled", true);
    $(ssoCheckboxId).prop('checked', false);

    $(ssoDropdownTitleId).prop('selected', true);
    $(ssoDropdownId).attr("disabled", true);


    $(tooltipId).hide();
    $(disabledTooltipId).show();

    var ssoDropdown = $(ssoDropdownId);
    if (ssoDropdown.parsley().reset) {
        ssoDropdown.parsley().reset();
    }
};

function addNewLDAPServer() {
    var accordion = $('#accordion');
    var div = ldapServer.getServerDiv(inputId, null);
    var elem = $(div);
    accordion.append(elem);

    setDomainsInSelectObject(inputId, 0);
    ldapServer.setTranslations(null, elem, -1);

    //Values
    var ValueNewServer = $(elem).find('.headerItemNEW_SERVER').html();

    //Replace Values
    $(elem).find('.headerItemNEW_SERVER').html(ValueNewServer.replace('{{NEW_SERVER}}', $("#hdnNEW_SERVER").val()));

    $(elem).find('.rowEnbaledSynchronization').hide();
    $(elem).find("#custom-tooltip-innerLDAP_SSO_CHECKBOX_TOOLTIP" + inputId).hide();
    $(elem).find("#sso-sync-warning-message-" + inputId).hide();
    setRoleAttributeAccordingTo("", elem, false);
    setNonActiveDirectoryValues(getServerId(elem));

    $(elem).find('.deleteAction button').click(deleteCB);
    $(elem).find('.saveAction button').click(saveCB);
    $(elem).find('.connectionAction button').click(testCB);

    $(elem).find('.clearAction button').click(clearCB);

    inputId++;

    accordion.accordion('destroy').accordion({
        active: true,
        collapsible: true,
        heightStyle: "content"
    });
};


function setAdvancedRoleMapping(that, form) {
    if (!that.is(":checked")) {
        disableAdvancedRoleMappingTextBoxs(form);
    }
    else {
        enableAdvancedRoleMappingTextBoxs(form);
    }
};

function clearAdvancedRoleMapping(form) {
    disableAdvancedRoleMappingTextBoxs(form);
    clearAdvancedRoleMappingTextBoxs(form);    
};

function disableAdvancedRoleMappingTextBoxs(form) {
    form.find('input[data-name=ReviewerWithoutRoleAttributesGroupDnList]').attr("disabled", true);
    form.find('input[data-name=ReviewerWithSeverityStatusChangeGroupDnList]').attr("disabled", true);

    form.find('input[data-name=ScannerWithoutRoleAttributesGroupDnList]').attr("disabled", true);
    form.find('input[data-name=ScannerWithNotExploitableGroupDnList]').attr("disabled", true);
    form.find('input[data-name=ScannerWithDeleteGroupDnList]').attr("disabled", true);
    form.find('input[data-name=ScannerWithNotExploitableAndDeleteGroupDnList]').attr("disabled", true);
};

function clearAdvancedRoleMappingTextBoxs(form) {
    form.find('input[data-name=ReviewerWithoutRoleAttributesGroupDnList]').val("");
    form.find('input[data-name=ReviewerWithSeverityStatusChangeGroupDnList]').val("");

    form.find('input[data-name=ScannerWithoutRoleAttributesGroupDnList]').val("");
    form.find('input[data-name=ScannerWithNotExploitableGroupDnList]').val("");
    form.find('input[data-name=ScannerWithDeleteGroupDnList]').val("");
    form.find('input[data-name=ScannerWithNotExploitableAndDeleteGroupDnList]').val("");
};

function enableAdvancedRoleMappingTextBoxs(form) {
    form.find('input[data-name=ReviewerWithoutRoleAttributesGroupDnList]').removeAttr("disabled");
    form.find('input[data-name=ReviewerWithSeverityStatusChangeGroupDnList]').removeAttr("disabled");

    form.find('input[data-name=ScannerWithoutRoleAttributesGroupDnList]').removeAttr("disabled");
    form.find('input[data-name=ScannerWithNotExploitableGroupDnList]').removeAttr("disabled");
    form.find('input[data-name=ScannerWithDeleteGroupDnList]').removeAttr("disabled");
    form.find('input[data-name=ScannerWithNotExploitableAndDeleteGroupDnList]').removeAttr("disabled");
};

 /***************************************** Event Listeners **********************************************/

//Add new Server - Event
//****************************************************************************
$('#addNewLDAPServer').click(function () {
    var isValidate = true;
    $('div[data-action="Insert"]').children().each(function () {
        var form = $(this);

        if (form.attr('class').indexOf('form-authentication') > -1) {
            isValidate &= checkSpecificFormValidation(form);
        }
    });
    changeBorderColor($('div[data-action="Insert"]').find('form'), isValidate);
    if (isValidate == true) {
        addNewLDAPServer();
        var index = $('.server').length;
        $("#accordion").accordion("option", "active", index - 1);
    }
});
//****************************************************************************

$('body').on('change', '.form-control', function () {
    var isValidate = $(this).parsley().validate();
    changeBorderColor($(this).closest('.form-horizontal'), isValidate);
});

$('body').on('change', '.defaultRoleId', function () {
    var that = $(this);
    var div = that.closest('.server');
    setRoleAttributeAccordingTo(that.val(), div, true);
});

     //Change event on Directory type select dropdown 
$('body').on('change', '.directoryTypeSelection', function () {
    var that = $(this);
    var div = that.closest('.server');
    switch (that.val()) {
        case "OpenLDAP":

            $(div).find('[data-name="UserObjectSchema"]').val("inetorgperson");
            $(div).find('[data-name="UserObjectFilter"]').val("(objectclass=inetorgperson)");
            $(div).find('[data-name="UserNameAttribute"]').val("cn");
            $(div).find('[data-name="UserRDNAttribute"]').val("cn");
            $(div).find('[data-name="UserFirstNameAttribute"]').val("givenName");
            $(div).find('[data-name="UserLastNameAttribute"]').val("sn");
            $(div).find('[data-name="UserEmailAttribute"]').val("mail");
            $(div).find(".label-form-UserName").html($("#hdnUSER_DN").val());
            $(div).find('[data-name="UserName"]').next().find('.custom-tooltip-inner').html($("#hdnLDAP_USERDN_TOOLTIP").val());

            $(div).find('[data-name="GroupObjectClass"]').val("groupOfUniqueNames");
            $(div).find('[data-name="GroupObjectFilter"]').val("(objectClass=groupOfUniqueNames)");
            $(div).find('[data-name="GroupIDAttribute"]').val("cn");
            $(div).find('[data-name="GroupNameAttribute"]').val("cn");
            $(div).find('[data-name="GroupMembersAttribute"]').val("member");
            $(div).find('[data-name="UserMembershipAttribute"]').val("");

            //LDAP_USERDN_TOOLTIP

            break;
        case "ActiveDirectory":
            $(div).find('[data-name="UserObjectSchema"]').val("user");
            $(div).find('[data-name="UserObjectFilter"]').val("(&(objectCategory=Person)(sAMAccountName=*))");
            $(div).find('[data-name="UserNameAttribute"]').val("sAMAccountName");
            $(div).find('[data-name="UserRDNAttribute"]').val("cn");
            $(div).find('[data-name="UserFirstNameAttribute"]').val("givenName");
            $(div).find('[data-name="UserLastNameAttribute"]').val("sn");
            $(div).find('[data-name="UserEmailAttribute"]').val("mail");
            $(div).find(".label-form-UserName").html($("#hdnUSER_NAME").val());
            $(div).find('[data-name="UserName"]').next().find('.custom-tooltip-inner').html($("#hdnLDAP_USER_NAME_TOOLTIP").val());

            $(div).find('[data-name="GroupObjectClass"]').val("group");
            $(div).find('[data-name="GroupObjectFilter"]').val("(objectCategory=Group)");
            $(div).find('[data-name="GroupIDAttribute"]').val("cn");
            $(div).find('[data-name="GroupNameAttribute"]').val("name");
            $(div).find('[data-name="GroupMembersAttribute"]').val("member");
            $(div).find('[data-name="UserMembershipAttribute"]').val("memberOf");

            break;
        case "CustomLDAPServer":
            $(div).find('[data-name="UserObjectSchema"]').val("");
            $(div).find('[data-name="UserObjectFilter"]').val("");
            $(div).find('[data-name="UserNameAttribute"]').val("");
            $(div).find('[data-name="UserRDNAttribute"]').val("");
            $(div).find('[data-name="UserFirstNameAttribute"]').val("");
            $(div).find('[data-name="UserLastNameAttribute"]').val("");
            $(div).find('[data-name="UserEmailAttribute"]').val("");
            $(div).find(".label-form-UserName").html($("#hdnUSER_NAME").val());
            $(div).find('[data-name="UserName"]').next().find('.custom-tooltip-inner').html($("#hdnLDAP_USER_NAME_TOOLTIP").val());

            $(div).find('[data-name="GroupObjectClass"]').val("");
            $(div).find('[data-name="GroupObjectFilter"]').val("");
            $(div).find('[data-name="GroupIDAttribute"]').val("");
            $(div).find('[data-name="GroupNameAttribute"]').val("");
            $(div).find('[data-name="GroupMembersAttribute"]').val("");
            $(div).find('[data-name="UserMembershipAttribute"]').val("");

            break;

    }
    var form = that.closest('.server').prev().next().children();

});

//click event on the LDAP SSO - enable domain dropdown
$('body').on('click', '.sso-enabled-cb', function () {
    var id = getServerId($(this));
    var ssoDropdownId = "#select-domain-for-sso-" + id;
    var ssoDropdownTitleId = "#sso-enabled-dd-title-" + id;
    var syncSettingsEnabled = $('#enabled-cb-' + id).is(":checked");
    var mappedDomainEnabled = $(this).is(":checked");

    if (!mappedDomainEnabled) {
        $(ssoDropdownTitleId).prop('selected', true);
        $(ssoDropdownId).attr("disabled", true);
        if ($(ssoDropdownId).parsley().reset) {
            $(ssoDropdownId).parsley().reset();
        }
    } else {
        $(ssoDropdownId).removeAttr("disabled");
    }
    showWarningIfSsoAndSync(mappedDomainEnabled, syncSettingsEnabled, id);
});

//click event on the directoryType dropdown option - enable sso 
$('body').on('click', '.directoryTypeSelection', function () {
    var id = getServerId($(this));    
    if ($(this).val() == "ActiveDirectory") {
        setActiveDirectoryValues(id);
    } else {        
        setNonActiveDirectoryValues(id);
    }
});

$('body').on('click', '.enabledCheckBox', function () {
    var id = getServerId($(this));
    var isMappedToDomain = $("#sso-enabled-cb-" + id).is(":checked");
    var syncSettingsEnabled = $(this).is(":checked");
    showWarningIfSsoAndSync(isMappedToDomain, syncSettingsEnabled, id);
});

//click event on the check boxes
$('body').on('click', '#primary_cb', function () {
    if (!$(this).is(":checked")) {
        $(".secondary_CB").attr("disabled", true);
        $(".secondary_CB").prop('checked', false);
    } else {
        $(".secondary_CB").removeAttr("disabled");
    }
});

//click on Advanced Role Mapping check box
$('body').on('click', '#advancedRoleMapping_cb', function () {
    var form = $(this).closest("form");
    
    //if the check box is not checked
    setAdvancedRoleMapping($(this), form);
});

//click event on Enbaled Check Box
$('body').on('click', '.enabledCheckBox', function () {
    var form = $(this).closest("form");
    var rowEnbaledSynchronizationDIV = form.find('.rowEnbaledSynchronization');
    setInputValues($(this), form, rowEnbaledSynchronizationDIV);
    var directoryTypeSelection = form.find('.directoryTypeSelection');

    var div = form.closest('.server');
    if ($(this).is(":checked")) {
        switch (directoryTypeSelection.val()) {
            case "OpenLDAP":

                $(div).find('[data-name="GroupObjectClass"]').val("groupOfUniqueNames");
                $(div).find('[data-name="GroupObjectFilter"]').val("(objectClass=groupOfUniqueNames)");
                $(div).find('[data-name="GroupIDAttribute"]').val("cn");
                $(div).find('[data-name="GroupNameAttribute"]').val("cn");
                $(div).find('[data-name="GroupMembersAttribute"]').val("member");
                $(div).find('[data-name="UserMembershipAttribute"]').val("");

                //LDAP_USERDN_TOOLTIP

                break;
            case "ActiveDirectory":

                $(div).find('[data-name="GroupObjectClass"]').val("group");
                $(div).find('[data-name="GroupObjectFilter"]').val("(objectCategory=Group)");
                $(div).find('[data-name="GroupIDAttribute"]').val("cn");
                $(div).find('[data-name="GroupNameAttribute"]').val("name");
                $(div).find('[data-name="GroupMembersAttribute"]').val("member");
                $(div).find('[data-name="UserMembershipAttribute"]').val("memberOf");

                break;
            case "CustomLDAPServer":

                $(div).find('[data-name="GroupObjectClass"]').val("");
                $(div).find('[data-name="GroupObjectFilter"]').val("");
                $(div).find('[data-name="GroupIDAttribute"]').val("");
                $(div).find('[data-name="GroupNameAttribute"]').val("");
                $(div).find('[data-name="GroupMembersAttribute"]').val("");
                $(div).find('[data-name="UserMembershipAttribute"]').val("");

                break;

        }
    }
});

//disable or enable fields for Enbaled Synchronization
function setInputValues(that, form, enableDIV) {
    //if not checked
    if (!that.is(":checked")) {
        form.find('.rowEnbaledSynchronization').hide();
        enableDIV.each(function () {
            $(this).find(':input').attr("disabled", true);
        });
        //enabled the Enabled check box              
        form.parsley().destroy();
    }
    //if checked
    else {
        form.find('.rowEnbaledSynchronization').show();
        enableDIV.each(function () {
            $(this).find(':input').removeAttr("disabled");
            var advancedRoleMapping_cb = $(this).find('#advancedRoleMapping_cb')

            setAdvancedRoleMapping(advancedRoleMapping_cb, enableDIV);
        });
    }
};

//change the value in the name input
$('body').on('input', '.nameInput', function () {
    var value = $(this).val();
    if (value === "") {
        $(this).closest('.server').prev().children().eq(1).text(hdnEMPTY_SERVER_NAME.value);
    }
    else {
        $(this).closest('.server').prev().children().eq(1).text(value);
    }
});