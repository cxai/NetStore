﻿
    function openInfoAlert(title,callback) {
        swal({
            title: title,
            html: true,
        }).then(function () {
            callback();
            $(document).trigger('sweetalert-modal-closed');
        });
    }

    function openConfirmation(title,type,object, callback) {
        swal({
            title: title, //The title of the modal. It can either be added to the object under the key "title" or passed as the first parameter of the function.

            text: object.text, //A description for the modal. It can either be added to the object under the key "text" or passed as the second parameter of the function.

            type: type, //The type of the modal. SweetAlert comes with 4 built-in types which will show a corresponding icon animation: "warning", "error", "success" and "info". You can also set it as "input" to get a prompt modal. It can either be put in the object under the key "type" or passed as the third parameter of the function.

            closeOnEsc: true, //If set to true, the user can dismiss the modal by pressing the Escape key.

            className: object.customClass, //A custom CSS class for the modal. It can be added to the object under the key "customClass".

            allowOutsideClick: false, //If set to true, the user can dismiss the modal by clicking outside it.

            buttons: {
                cancel: {
                    text:object.cancelButtonText,
                    closeModal: object.closeOnCancel,
                    visible:true
                },
                confirm: {
                    text:object.confirmButtonText,
                    closeModal: object.closeOnConfirm,
                    visible: true
                }
            },

            dangerMode: true,

            icon: object.imageUrl, //Add a customized icon for the modal. Should contain a string with the path to the image.

            timer: object.timer, //Auto close timer of the modal. Set in ms (milliseconds).

            html: object.html, //If set to true, will not escape title and text parameters. (Set to false if you're worried about XSS attacks.)

            inputType: object.inputType, //Change the type of the input field when using type: "input" (this can be useful if you want users to type in their password for example).

            inputPlaceholder: object.inputPlaceholder, //When using the input-type, you can specify a placeholder to help the user.

            inputValue: object.inputValue, //Specify a default text value that you want your input to show when using type: "input"

            showLoaderOnConfirm: object.showLoaderOnConfirm //Set to true to disable the buttons and show that something is loading.
        }).then(function () {
            callback();
            $(document).trigger('sweetalert-modal-closed');
        });
    }

    window.openInfoAlert = openInfoAlert;
    window.openConfirmation = openConfirmation;