﻿(function () {
    'use strict';

    checkmarx.CxAcademy.factory('AppSecCoach.AcademyLessonsRepositoryFactory',
        ['AppSecCoach.SettingsDataService',
        'AppSecCoach.AcademyLessonsDataService',
        'AppSecCoach.AcademyLessonsLocalDataService',
        '$q',
        'CxPortal.LicenseEnvironmentDataService',
        function (
            appSecCoachSettingsDataService,
            appSecCoachAcademyLessonsDataService,
            appSecCoachAcademyLessonsLocalDataService,
            $q,
            licenseEnvironmentDataService) {

            var _dataService = null;

            function getAcademyLessonsRepository() {
                
                var deferred = $q.defer();
                if (_dataService) {
                    deferred.resolve(_dataService);
                }
                else {
                    loadAcademyLessonsRepository().then(function (setting) {
                        deferred.resolve(_dataService);
                    });
                }

                return deferred.promise;
            }

            function loadAcademyLessonsRepository() {

                _dataService = appSecCoachAcademyLessonsLocalDataService;

                return appSecCoachSettingsDataService.getAppSecCoachSetting().then(function (settings) {

                    var isFullVersionEnabled = false;
                    if (settings.codebashingIsEnabled && settings.codebashingIsEnabled.toLowerCase() === "true") {
                        isFullVersionEnabled = true;
                    }
                    else if (settings.isTermsConfirmed.toLowerCase() === "true") {
                        isFullVersionEnabled = true;
                    }
                   

                    if (isFullVersionEnabled) {

                        return licenseEnvironmentDataService.get().then(function (licenseData) {

                            if (licenseData.data.environmentId) {
                                _dataService = appSecCoachAcademyLessonsDataService;
                            }

                        }).catch(function (ex) {
                            _dataService = appSecCoachAcademyLessonsLocalDataService;
                        });
                    }
                });
            }

            return {
                getAcademyLessonsRepository: getAcademyLessonsRepository
            };
        }]);
})();