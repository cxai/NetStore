﻿(function () {
	"use strict";

	checkmarx.ProjectState.factory('ProjectState.OSAAnalyzerService', [
		'$rootScope',
        'httpStatusCodes',
		'osaAnalyseDataService',
        '$interval',
        '$q',
        '$timeout',
        function ($rootScope, httpStatusCodes, osaAnalyseDataService, $interval, $q, $timeout) {

            function analyze(formData) {

                return osaAnalyseDataService.analyse(formData);
        	}

        	function uploadFile(formData) {
        		return osaAnalyseDataService.uploadFile(formData);
        	}

        	function getOSAQueueScanList(projectId) {

        		return osaAnalyseDataService.getOSAQueueScanList(projectId);
        	}

        	function getOSAScanList(projectId) {

        	    return osaAnalyseDataService.getOSAScanList(projectId);
        	}

        	function getOSAScanStatus(guid) {

        	    return osaAnalyseDataService.getOSAScanStatus(guid);
        	}

        	return {
        		analyze: analyze,
        		uploadFile: uploadFile,
        		getOSAQueueScanList: getOSAQueueScanList,
        		getOSAScanStatus: getOSAScanStatus,
        		getOSAScanList: getOSAScanList
        	};
        }]);

})();