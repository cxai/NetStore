﻿(function () {
    'use strict';

    checkmarx.CxAcademy.factory('AppSecCoach.LessonsRequestDataService',
        ['CxPortal.AjaxServiceWithNotification',
        'apiBaseURLService',
        function (
            ajaxServiceWithNotification,
            apiBaseURLService) {

            function getLessonRequestDataByQueryId(queryId) {
                var url = apiBaseURLService.getAPIVirtualDirectory() + '/Queries/' + queryId + '/AppSecCoachLessonsRequestData';
                return ajaxServiceWithNotification.get(url);
            }

            function getLessonsRequestData() {
                var url = apiBaseURLService.getAPIVirtualDirectory() + '/AppSecCoachLessonsRequestData';
                return ajaxServiceWithNotification.get(url);
            }

            function getLessonsQueriesRequestData() {
                var url = apiBaseURLService.getAPIVirtualDirectory() + '/AppSecCoachMappedQueriesRequestData';
                return ajaxServiceWithNotification.get(url);
            }

            return {
                getLessonRequestDataByQueryId: getLessonRequestDataByQueryId,
                getLessonsRequestData: getLessonsRequestData,
                getLessonsQueriesRequestData: getLessonsQueriesRequestData
            };
        }]);
})();