﻿(function () {
    "use strict";

    checkmarx.Common.factory('Common.ClearInputFileService', [function () {

        function clear(element) {

            if (element.val() == '') {
                return;
            }
            // Fix for IE ver < 11, that does not clear file inputs
            // Requires a sequence of steps to prevent IE crashing but
            // still allow clearing of the file input.
            if (/MSIE/.test(navigator.userAgent)) {
                var $frm1 = element.closest('form');
                if ($frm1.length) { // check if the input is already wrapped in a form
                    element.wrap('<form>');
                    var $frm2 = element.closest('form'), // the wrapper form
                        $tmpEl = $(document.createElement('div')); // a temporary placeholder element
                    $frm2.before($tmpEl).after($frm1).trigger('reset');
                    element.unwrap().appendTo($tmpEl).unwrap();
                } else { // no parent form exists - just wrap a form element
                    element.wrap('<form>').closest('form').trigger('reset').unwrap();
                }
            } else { // normal reset behavior for other sane browsers
                element.val('');
            }
        }

        return {
            clear: clear
        };

    }]);

})();