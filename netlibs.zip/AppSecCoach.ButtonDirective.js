﻿(function () {
    "use strict";

    checkmarx.CxAcademy.directive('appSecCoachButton', [
        'AppSecCoach.DialogIDs',
        'AppSecCoach.OpenLessonLogic',
        function (appSecCoachDialogIDs, openLessonLogic) {

        return {
            restrict: 'A',
            template: '<div class="app-sec-button-open-dialog" ng-click="openLesson()">'
                        + '<div>'
                            + '<img src="app/cxAcademy/images/app-sec-coach-icon.png" /> Codebashing'
                        + '</div>'
                    + '</div>',
            scope: {
                linkData: '='
            },
            link: function (scope, element, attr) {

                scope.appSecCoachLicenseDialogId = appSecCoachDialogIDs.appSecCoachLicenseDialog;
                scope.appSecCoachLessonIsNotAvailableDialogId = appSecCoachDialogIDs.appSecCoachLessonIsNotAvailableDialog;

                scope.openLesson = function () {

                    openLessonLogic.open(scope.linkData);
                };
            }
        };
    }]);
})();