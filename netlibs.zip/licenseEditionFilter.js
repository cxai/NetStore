﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxPortal.filter('licenseEditionFilter', [
        function () {

            var defaultValue = 'SDLC';

            return function (edition) {

                switch (edition) {
                    case 0: return defaultValue;
                    case 1: return 'SecurityGate';
                    default: return defaultValue;
                }
            };
        }]);

})();