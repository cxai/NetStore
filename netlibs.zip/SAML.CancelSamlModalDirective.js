﻿
(function () {
    "use strict";

    checkmarx.SAML.directive('cancelSamlModal', [function () {

        return {
            template: '<div class="cancel-modal-container">'
                        + '<div class="are-you-sure">{{ "ARE_YOU_SURE_SAML_CANCEL" | translate}}</div>'
                        + '<div class="no-rollback">{{ "NO_ROLLBACK_LATER" | translate}}</div>'                        
                        + '<button class="yes-btn-cancel" ng-click="yes()">{{ "YES_DISCARD_CHANGES" | translate }} </button>'
                        + '<button class="no-btn-cancel" ng-click="no()">{{ "NO_BACK_TO_EDIT" | translate }} </button>'
                    + '</div>',
            controller: ['$scope', '$rootScope', function ($scope, $rootScope) {

                $scope.no = function () {
                    this.close();
                }

                $scope.yes = function(){
                    $rootScope.$broadcast('yes-cancel-saml-modal');
                    this.close();
                }
            }]
            
        };

    }]);

})();