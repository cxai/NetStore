﻿(function () {
    "use strict";

    checkmarx.CxAcademy.value('AppSecCoach.LinkType', {
        none: 0,
        linkToLesson: 1,
        generalLink: 2
    });

    checkmarx.CxAcademy.value('AppSecCoach.DialogIDs', {
        appSecCoachLicenseDialog: 'appSecCoachLicenseDialog',
        appSecCoachLessonIsNotAvailableDialog: 'appSecCoachLessonIsNotAvailableDialog'
    });

    checkmarx.CxAcademy.value('linkParameters', {
        currentPage: 'utm_medium',
        organizationName: 'utm_campaign',
        source: 'utm_source',
        constSource: 'CB',
        baseUrl: 'https://academy.checkmarx.net/'
    });

    checkmarx.CxAcademy.value('AppSecCoach.LocalStorageKeys', {
        availableLessons: 'availableLessons'
    });

})();