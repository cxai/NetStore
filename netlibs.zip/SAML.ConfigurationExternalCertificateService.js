﻿(function () {
    "use strict";

    checkmarx.SAML.factory('SAML.ConfigurationExternalCertificateService', ['ajaxService', 'apiBaseURLService',
        function (ajaxService, apiBaseURLService) {

        var url = apiBaseURLService.getAPIBaseURL() + '/ServiceProviderCertificate';

        function buildConfig() {

            return {
                headers: {
                    'Content-Type': undefined
                }
            };
        };

        function get() {

            return ajaxService.get(url);
        };

        function post(data) {

            return ajaxService.post(url, data, buildConfig())
        };

        return {
            post: post,
            get: get
        };

    }]);
})();