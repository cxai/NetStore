﻿/// <reference path="../../app.js" />
/// <reference path="../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.CxAcademy.controller('AppSecCoach.ButtonController',
        ['$rootScope', '$scope', 'AppSecCoach.DialogIDs',
        function ($rootScope, $scope, appSecCoachDialogIDs) {

            $scope.dialogId = appSecCoachDialogIDs.appSecCoachLicenseDialog;

            $scope.openDialog = function () {
                $rootScope.$broadcast('dialog-open-' + $scope.dialogId);
            };

        }]);
})();