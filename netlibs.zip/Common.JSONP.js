﻿/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.Common.provider('Common.JSONP', [function () {

        this.$get = ['$http', 'Common.QueryString','$sce', function ($http, queryString,$sce) {

            function get(url) {

                return $http.jsonp($sce.trustAsResourceUrl(url));
            }

            return {
                get: get
            }
        }];
    }]);

})();