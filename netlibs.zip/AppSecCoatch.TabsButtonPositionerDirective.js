﻿(function () {
    "use strict";

    checkmarx.CxAcademy.directive('appSecCoachTabButtonPositioner', function () {

        return {
            restrict: 'E',
            template: '<div app-sec-coach-button class="app-sec-coach-button viewer-tab" link-data="linkData"></div>',
            scope: {
                linkData: '='
            },
            link: function (scope, element, attr) {

                function positionAppSecCoachButtonInTheViewTab() {

                    $("app-sec-coach-tab-button-positioner").appendTo("#codeTabs div");

                    var ul = $('#codeTabs ul');

                    if (ul) {
                        element.css('left', ul.width() + 'px');
                        element.css('left', $('#descriptionDiv').height() + 'px');
                    }
                }

                positionAppSecCoachButtonInTheViewTab();
            }
        };
    });
})();