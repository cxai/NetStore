﻿/// <reference path="app.js" />

(function () {
	"use strict";

	checkmarx.Queries.directive('importCustomQueryDescriptionDialog',
        [function () {

            return {
                template: '<dialog dialog-setup="dialogSetup" ng-show="false">'
                        + '<import-query-description-popup-form mode="mode"></import-query-description-popup-form>'
                        + '</dialog>',
                scope: {},
                controller: ['$scope', function ($scope) {

            			$scope.dialogSetup = {
            				modal: true,
            				width: 391,
            				resizable: false,
            			    shouldCloseByOverlayClick: false,
            				show: {
            					effect: "fade", duration: 300
            				},
                            hide: {
            					effect: "fade", duration: 200
            				}
            			};
            		}]
            	};
            }]);
})();