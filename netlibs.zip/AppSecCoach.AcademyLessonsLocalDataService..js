﻿(function () {
    'use strict';

    checkmarx.CxAcademy.factory('AppSecCoach.AcademyLessonsLocalDataService',
        ['AppSecCoach.AcademyLessonsRepository',
        '$q',
        function (academyLessonsRepository, $q) {

            function getAcademyLessons() {
                var deferred = $q.defer();
                deferred.resolve(academyLessonsRepository);
                return deferred.promise;
            }

            return {
                getAcademyLessons: getAcademyLessons
            };
        }]);
})();