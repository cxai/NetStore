﻿/// <reference path="../../../app.js" />
/// <reference path="../../../libs/angular/angular.js" />

(function () {
    "use strict";

    checkmarx.ProjectState.directive('vulnerabilitiesDoughnutChart', ['$translate', 'chartColumnDataNames', 
        function ($translate, chartColumnDataNames) {

        return {
            template: '<div class="pie-container"></div>',
            scope: {
                data: '='
            },
            link: function ($scope, $element) {

                if (!$scope.data) {
                    console.log("vulnerabilitiesDoughnutChart -> Chart data is empty");
                    return;
                }

                var chartData = $scope.data;
                var mainColor = chartData.mainColor;
                var tooltip = getTooltip(chartData);

                $element.children(".pie-container").attr("id", chartData.containerId);

                var mainChart = new Highcharts.Chart({
                    chart: {
                        renderTo: getContainer(),
                        plotBackgroundColor: null,
                        plotShadow: false,
                        type: chartData.generalData.type,
                        margin: [0, 0, 0, 0],
                        spacingTop: 0,
                        spacingBottom: 0,
                        spacingLeft: 0,
                        spacingRight: 0,
                        events: {
                            redraw: function (c) {

                                $('#' + chartData.containerId + ' image').remove();
                                $('#' + chartData.containerId + ' text').remove();

                                chartData.generalData.events.onChartLoading(c.currentTarget, chartData.imageUrl, chartData.text, chartData.textCss);
                            }
                        }
                    },
                    defs: {
                        patterns: [{
                            'id': 'custom-pattern-' + chartData.chartName,
                            'path': {
                                d: 'M 0 0 L 10 10 M 9 -1 L 11 1 M -1 9 L 1 11',
                                stroke: chartData.mainColor,
                                strokeWidth: 3
                            }
                        }]
                    },
                    credits: {
                        enabled: false
                    },
                    exporting: {
                        enabled: false
                    },
                    title: {
                        text: ''
                    },
                    tooltip: tooltip,
                    plotOptions: {
                        pie: {
                            allowPointSelect: true,
                            cursor: 'default',
                            animation: true,
                            size: '97%'
                        }
                    },
                    series: [{
                        id: chartData.chartName,
                        type: 'pie',
                        name: chartData.chartName,
                        allowPointSelect: false,
                        slicedOffset: 0,
                        center: ["50%", "50%"],
                        cursor: 'default',
                        innerSize: '80%',
                        borderWidth: 0,
                        showInLegend: false,
                        dataLabels: {
                            enabled: false
                        },
                        data: chartData.data,
                        shadow: chartData.shadow,
                        states: {
                            hover: {
                                enabled: false
                            }
                        }
                    }]
                }, function (chart) {
                    /* on complete */

                    if (chartData.generalData.events.onChartLoading) {
                        chartData.generalData.events.onChartLoading(chart, chartData.imageUrl, chartData.text, chartData.textCss);
                    }
                });

                function getContainer() {

                    return $element.children().first()[0];
                }

                function isDataIsZeroResults(chartData) {
    
                    if (chartData.data && chartData.data.length == 1 && chartData.data[0].y == 1) {
                        return {
                            enabled: false
                        };
                    }

                    return;
                }

                function getTooltip(chartData) {

                    if (chartData.generalData.tooltip) {

                        return chartData.generalData.tooltip;
                    }
                    else if (isDataIsZeroResults(chartData)) {

                        return {
                            useHTML: true,
                            hideDelay: 100,
                            formatter: function () {

                                return $translate.instant(chartColumnDataNames.New) + " 0";
                            }
                        };
                    }

                    var tooltip = chartData.generalData.tooltip || {
                        useHTML: true,
                        hideDelay: 100,
                        formatter: function () {

                            // no reccurent
                            if (this.point.color.toLowerCase() == chartData.mainColor.toLowerCase()) {
                                return $translate.instant(chartColumnDataNames.New) + " " + this.y;
                            }

                            return $translate.instant(chartColumnDataNames.Recurrent) + " " + this.y;
                        }
                    };

                    return tooltip;
                }
            }
        };
    }]);
})();