﻿(function () {
    "use strict";

    checkmarx.Common.factory('Common.QueryString', [function () {

        function isQueriStringParamExists(url, param) {
            return new RegExp("[?&]" + param + "=", "i").test(url);
        };

        function addQueryStringParameter(url, param, value, replaceIfExists) {

            if (typeof (replaceIfExists) !== "boolean") {
                replaceIfExists = true;
            }

            if (replaceIfExists && isQueriStringParamExists(url, param)) {

                var regex = new RegExp("([?|&])" + param + "=.*?(&|#|$)(.*)", "i");

                if (typeof value !== 'undefined' && value !== null)

                    return url.replace(regex, '$1' + param + "=" + value + '$2$3');
                else {

                    return url.replace(regex, '$1$3').replace(/(&|\?)$/, '');
                }
            }
            else {

                if (typeof value !== 'undefined' && value !== null) {

                    var separator = url.indexOf('?') !== -1 ? '&' : '?', hash = url.split('#');

                    url = hash[0] + separator + param + '=' + value;

                    if (hash[1]) url += '#' + hash[1];

                    return url;
                }
                else {
                    return url;
                }
            }
        }

        function getParameterByName(name, url) {

            if (!url) {
                url = window.location.href;
            }

            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)");
            var results = regex.exec(url);

            if (!results) {
                return null;
            }

            if (!results[2]) {
                return '';
            }

            return decodeURIComponent(results[2].replace(/\+/g, " "));
        }

        return {
            getParameterByName: getParameterByName,
            addQueryStringParameter: addQueryStringParameter
        };

    }]);
})();